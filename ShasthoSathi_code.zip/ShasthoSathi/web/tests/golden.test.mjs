// The web core vs the Python reference (same golden files as the Kotlin core: scripts/15_core_golden.py, 17_ocr_proxy.py).
//   node tests/golden.test.mjs        (exit code 1 on any difference)
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { runGolden } from "../js/core/golden.js";

const dir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../mobile/android/core/src/test/resources/golden");
const res = await runGolden((name) => fs.readFileSync(path.join(dir, name), "utf8"));
let ok = true;
for (const [k, v] of Object.entries(res)) {
  console.log(`${k.padEnd(7)} ${v.n} cases: ${v.fails.length ? v.fails.length + " differences" : "identical"}`);
  v.fails.slice(0, 5).forEach((f) => console.log("   " + f));
  ok = ok && !v.fails.length;
}
console.log(ok ? "ALL IDENTICAL" : "DIFFERENCES FOUND");
process.exit(ok ? 0 : 1);
