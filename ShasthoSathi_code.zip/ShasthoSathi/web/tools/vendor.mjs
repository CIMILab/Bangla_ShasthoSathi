// Copies the runtime libraries and data into web/ so the site needs no CDN or third-party request.
//   npm install && npm run vendor
import fs from "node:fs";
import path from "node:path";
const R = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const cp = (from, to) => { fs.mkdirSync(path.dirname(path.join(R, to)), { recursive: true }); fs.copyFileSync(path.join(R, from), path.join(R, to)); };
const nm = "node_modules/";
for (const f of ["ort.wasm.min.mjs", "ort-wasm-simd-threaded.wasm", "ort-wasm-simd-threaded.mjs"]) cp(nm + "onnxruntime-web/dist/" + f, "vendor/ort/" + f);
for (const f of ["tesseract.esm.min.js", "worker.min.js"]) cp(nm + "tesseract.js/dist/" + f, "vendor/tesseract/" + f);
for (const f of ["tesseract-core-simd-lstm.wasm.js", "tesseract-core-lstm.wasm.js", "tesseract-core-simd-lstm.wasm", "tesseract-core-lstm.wasm",
                 "tesseract-core-simd-lstm.js", "tesseract-core-lstm.js"]) cp(nm + "tesseract.js-core/" + f, "vendor/tesseract/" + f);
cp(nm + "@huggingface/tokenizers/dist/tokenizers.min.mjs", "vendor/tokenizers.min.mjs");
const app = "../mobile/android/app/src/main/assets/";
for (const f of ["ben.traineddata", "eng.traineddata"]) cp(app + "tessdata/" + f, "tessdata/" + f);
cp(app + "samples.json", "data/samples.json");
cp(app + "pipeline_config.json", "data/pipeline_config.json");
for (const f of ["core_golden.jsonl", "gate_golden.jsonl", "tagger_golden.jsonl", "group_golden.jsonl", "ocr_golden.jsonl"])
  cp("../mobile/android/core/src/test/resources/golden/" + f, "data/golden/" + f);
cp("../mobile/brand/logo.svg", "img/logo.svg");
cp(nm + "@fontsource/noto-sans-bengali/files/noto-sans-bengali-bengali-400-normal.woff2", "fonts/noto-sans-bengali-400.woff2");
cp(nm + "@fontsource/noto-sans-bengali/files/noto-sans-bengali-bengali-600-normal.woff2", "fonts/noto-sans-bengali-600.woff2");
console.log("vendored into", R);
