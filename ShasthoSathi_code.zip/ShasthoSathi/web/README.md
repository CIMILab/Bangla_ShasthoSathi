# ShasthoSathi — web app

The phone app's pipeline, in the browser. **Everything runs inside the browser tab**: reading the photo (Tesseract.js),
hiding personal details (format rules + optional ONNX privacy models), lab flags and the explanation. The report is
never uploaded; the page's Content-Security-Policy only allows requests to its own site, and it has no analytics,
CDN or remote fonts.

## Features
- Scan (phone camera), upload or drag-and-drop a photo, paste text, or try an invented sample.
- Mandatory "check the text against the photo" step before analysis.
- Summary with an interactive donut (click a slice → filtered results), range gauges, tap-for-detail panels with
  "correct this value" (the flag is recomputed by the rules).
- Explanation from the checked template (Bengali or English), with a source label and a feedback question.
- Privacy tab: original and protected text **side by side**; click a hidden part to show it again, or select any text
  and press "Hide selection".
- **My reports**: saved reports, encrypted in this browser with a passphrase (PBKDF2-SHA256 → AES-GCM, WebCrypto).
  Pseudonymised: the original text and the patient's name are never stored; a keyed hash (HMAC) of the name groups
  reports of the same person. **Trends** per test across reports, with the report's normal range as a band.
- **Doctor-visit summary**: printable / save-as-PDF page with results outside and within range, questions to ask,
  and your notes — no personal details.
- Two complete interface languages (Bengali / English), light and dark theme, phone to desktop layouts.
- Settings → **Self-test**: runs the 2,327 golden cases in the browser and confirms the results are identical to the
  Python reference.

## Run it on your computer
ES modules do not load from `file://`, so serve the folder:
```
cd web
python -m http.server 8080        # Windows: py -m http.server 8080
```
Open http://localhost:8080. (Any static server works.)

## Optional privacy models (~800 MB)
Format rules already hide phone numbers, IDs, dates, labelled names and doctors. The models also find names written
inside sentences.
1. On Hellbender: `python scripts/20_web_golden.py` (writes `tok_golden.json` and `model_golden.json` into
   `mobile/assets/ner`, `pii_bn`, `pii_en` so the browser can check itself against Python).
2. Download the `mobile/assets` folder to your laptop (OnDemand → Files → Download, or `scp -r`).
3. In the web app: Settings → Stronger privacy → **Load from a folder on this computer** → choose that folder.
   The models are cached in the browser (IndexedDB) and re-activated on the next visit. The settings page shows the
   tokenizer and label checks against Python.
If you host the site yourself, you can instead put the folders under `web/models/` and use **Load from this website**.

## Host it (GitLab Pages)
Copy `web/gitlab-ci.example.yml` to the repository root as `.gitlab-ci.yml`. Pages serves the static files; the
server never sees a report. Without models the site is about 35 MB.

## Develop
```
npm install          # dev only: libraries to vendor
npm run vendor       # copies onnxruntime-web, tesseract.js (+core, wasm), tokenizers.js, Noto Sans Bengali,
                     # tessdata (ben, eng), samples, golden files into the site
npm test             # web core vs the Python golden files (Node)
python ../tools/gen_js.py   # regenerate js/core/generated.js from src/shastho/*.py
```
Layout: `js/core/` (pure JS port of the Python/Kotlin core, golden-tested), `js/ocr.js`, `js/models.js`,
`js/vault.js`, `js/app.js` (UI), `js/i18n.js` (two string sets), `css/app.css`.
