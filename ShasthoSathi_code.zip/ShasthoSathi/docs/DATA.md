# Data sources

| # | Dataset | Use in project | Access | Status |
|---|---|---|---|---|
| 1 | Bangla-HealthNER — Khan et al., *Findings of EMNLP 2023* — github.com/alvi-khan/Bangla-HealthNER | Real Bengali health text; gold Symptom, Health Condition, Medicine, Dosage, Specialist, Age, Medical Procedure | Open, CC BY-NC-SA 4.0 | Downloaded; profiled (results/healthner_profile.json) |
| 2 | PMC-Patients — huggingface.co/datasets/zhengyun21/PMC-Patients | Real English case-report summaries; surrogate identifiers inserted to test leakage | Open, CC BY-NC-SA 4.0 | Script ready (00_download_data.sh) |
| 3 | ADE Corpus v2 — huggingface.co/datasets/ade-benchmark-corpus/ade_corpus_v2 | English drug + dosage spans | Open | Script ready |
| 4 | Handwritten prescription word images — IEEE 2024 (doc 10499631); Kaggle mirror mamun1113 | OCR of handwritten medicine names | Open (Kaggle login) | Manual download |
| 5 | Prescription images — Mendeley Data DOI 10.17632/k62rfd23kz | End-to-end OCR on full pages | Open, check license | Manual download |
| 6 | DGDA registered drug list — info.dgda.gov.bd; copy: Mendeley DOI 10.17632/zhtvkny53n | Brand → generic lexicon; verifies the 14 brands in synth.py | Government register | Manual download |
| 7 | Synthetic set — `scripts/01_make_synthetic.py` | 300 docs with gold PII, medicines, lab flags | Created here | Done (seed 42) |

## Bangla-HealthNER file format

`Dataset/{train,valid,test}.json` — a list of `{"text": str, "labels": [BIO tag per whitespace token]}`.
Split sizes: 25,426 / 3,178 / 3,179 documents.

## Synthetic set v1 (seed 42)

100 English lab reports (455 lab rows: 255 normal, 103 low, 97 high), 100 code-mixed
prescriptions, 40 English prescriptions, 60 Bangla notes. 1,890 gold PII spans,
566 medicine mentions.

Known limitations: template text is cleaner than real reports; dose patterns are
sampled without clinical logic (e.g., montelukast at noon); brand→generic pairs
must be checked against the DGDA register.
