# Running on Hellbender from the terminal (no notebook)

Long jobs die with the notebook kernel. Run them from the terminal instead: as a **batch job** (best) or
inside **tmux** on an interactive GPU node. Every step writes logs to `logs/` and results to `results/` / `runs/`,
and E4 skips configs that already finished, so you can re-run after any crash.

## 0. Once per terminal

```bash
cd /path/to/ShasthoSathi
source environment/env.sh            # activates openmed, sets caches, detects online/offline
python -m pytest -q tests            # 14 passed
bash run/download_models.sh          # once, needs internet: E4 backbones
```

## A. Batch job (recommended — keeps running after you log out)

```bash
sinfo -s                                   # once: check the GPU partition name; edit slurm/*.sbatch if it is not "gpu"
sbatch slurm/week7.sbatch                  # E3 + all E4 configs + summary, one job (≤ 6 h)
# or, faster if several GPUs are free: one job per E4 config
bash run/e3.sh                             # E3 (~10 min) on an interactive GPU node, or wrap it in sbatch
sbatch --array=1-6 slurm/e4_array.sbatch   # six E4 jobs in parallel
```

Watch it:

```bash
squeue -u $USER                            # is it queued / running?
tail -f logs/shastho-w7-<jobid>.out        # overall progress (Ctrl+C stops watching, not the job)
tail -f logs/e4_xlm-roberta-base-full-s42.log   # one training run
nvidia-smi                                  # on the node, if you are logged in there
```

## B. Interactive GPU node (e.g. g018) with tmux

```bash
tmux new -s shastho                         # a terminal that survives disconnects
source environment/env.sh
bash run/all_week7.sh 2>&1 | tee logs/week7_$(date +%F_%H%M).log
# detach: Ctrl+B then D     |  come back later:  tmux attach -t shastho
```

If tmux is missing: `nohup bash run/all_week7.sh > logs/week7.log 2>&1 &` then `tail -f logs/week7.log`.

## Pieces you can run on their own

| Command | What it does |
|---|---|
| `bash run/e3.sh` | E3 hybrid de-identification |
| `bash run/e4.sh` | all E4 configs in `configs/e4.txt` (skips finished ones) |
| `bash run/e4.sh 3` | only line 3 of `configs/e4.txt` |
| `SEEDS="42 13 7" bash run/e4.sh 1` | line 1 with three seeds (mean ± sd) |
| `python scripts/99_summarize.py` | prints the E3/E4 tables, writes `results/bundle_week7.json` and `results/week7_summary.md` |

To add or remove E4 experiments, edit `configs/e4.txt` (one line = one run).

## What to send back

`results/bundle_week7.json` (or paste the output of `python scripts/99_summarize.py`).
If something fails, send the last 30 lines of the matching file in `logs/`.
