# Results log

All numbers from Hellbender, NVIDIA H100 80GB, torch 2.14.0+cu130, transformers 4.57.6, openmed 2.5.0.
Raw file: `results/week6/bundle_week6.json`.

## E0 — Script of medical entities in Bangla-HealthNER (test, 3,179 posts)

| Entity | Total | Latin | Bangla | Mixed/other |
|---|---|---|---|---|
| Medicine | 1,852 | 1,121 (60.5%) | 697 (37.6%) | 34 |
| Health Condition | 786 | 222 (28.2%) | 551 (70.1%) | 13 |
| Dosage | 747 | 175 (23.4%) | 381 (51.0%) | 191 |
| Symptom | 3,528 | 690 (19.6%) | 2,811 (79.7%) | 27 |

## E1 — PII leakage, OpenMed PII models (synthetic v1, 300 docs)

| Route @ threshold | Span leak [95% CI] | Docs ≥1 leak | Clinical over-redaction | ms/doc |
|---|---|---|---|---|
| English model @0.5 | 0.236 [0.213, 0.258] | 0.79 | 0.068 | 31 |
| Bengali model @0.5 | 0.288 [0.272, 0.305] | 0.93 | 0.141 | 43 |
| Routed by script @0.3 | 0.095 [0.084, 0.107] | 0.53 | 0.163 | 50 |
| **Routed by script @0.5** | **0.122 [0.110, 0.134]** | **0.62** | **0.079** | 43 |
| Routed by script @0.7 | 0.199 [0.185, 0.212] | 0.85 | 0.040 | 47 |

Routed @0.5, leak by type: FACILITY 0.408, ID 0.450, ADDRESS 0.297, NAME 0.017, PHONE 0.013, DOCTOR 0, DATE 0, NID 0.
English model on Bangla notes leaks 0.53–0.71 of spans; Bengali model 0.11–0.24.
Caveat: threshold chosen on the same set (fixed in E3 with a dev/held-out split).

## E2 — OpenMed clinical NER recall (overlap match)

| Model | Synthetic brand recall (mixed Rx / EN Rx / BN notes) | Predictions outside any drug | HealthNER Medicine recall: Latin / Bangla / all |
|---|---|---|---|
| PharmaDetect SuperMedical 125M | 1.000 / 1.000 / 0.567 | 40 / 580 | 0.703 / 0.000 / 0.435 |
| PharmaDetect SuperClinical 434M | 0.964 / 0.993 / 0.317 | 5 / 516 | 0.748 / 0.093 / 0.498 |
| DiseaseDetect SuperClinical 434M (Health Condition) | — | — | 0.694 / 0.192 / 0.340 |

Median latency on H100: 17–56 ms per document.

## E3 — Hybrid de-identification (thresholds chosen on dev = synthetic v1; model/hybrid @0.5)

| Set | Mode | Span leak [95% CI] | Leak w/o facility | Docs ≥1 leak | Clinical over-redaction |
|---|---|---|---|---|---|
| Held-out synthetic (300) | rules only | 0.536 [0.531, 0.541] | 0.619 | 1.00 | 0.000 |
| | OpenMed | 0.103 [0.090, 0.116] | 0.071 | 0.52 | 0.084 |
| | **Hybrid** | **0.006 [0.003, 0.011]** | 0.007 | **0.03** | 0.084 |
| Real text + fake PII (400) | rules only | 0.600 | 0.750 | 1.00 | 0.000 |
| | OpenMed | 0.055 [0.047, 0.065] | 0.003 | 0.28 | **0.369** |
| | **Hybrid** | **0.002 [0.001, 0.004]** | 0.003 | **0.01** | **0.369** |

Hybrid − OpenMed: −0.097 [−0.110, −0.084] (held-out), −0.053 [−0.062, −0.045] (real).
McNemar on "document has any leak": 148 vs 0 discordant docs (held-out), 107 vs 0 (real).
Rules add no over-redaction; the 0.369 on real text comes from the OpenMed PII models removing
37% of gold Medicine/Dosage spans in real Bangla posts (synthetic dev showed only 0.084).

## E4 — Fine-tuning on Bangla-HealthNER (test split, seed 42, exact-span entity F1)

| Model | Micro F1 | P | R | Macro F1 | Medicine F1 | Medicine R (Bangla script) | Medicine R (Latin) | Dosage F1 | Trainable / total params | Train min |
|---|---|---|---|---|---|---|---|---|---|---|
| XLM-RoBERTa-base, full | **57.80** | 54.4 | 61.6 | 62.70 | 0.835 | 0.815 | 0.884 | 0.439 | 277M / 277M | 3.9 |
| OpenMed Bengali PII (mDeBERTa), full | 57.76 | 53.4 | 62.9 | **63.14** | **0.836** | 0.815 | **0.890** | 0.447 | 278M / 278M | 5.4 |
| BanglishBERT, full | 57.41 | 53.9 | 61.4 | 62.33 | 0.827 | 0.811 | 0.876 | **0.461** | 110M / 110M | 3.7 |
| BanglaBERT, full | 55.75 | 51.5 | 60.7 | 60.65 | 0.818 | **0.834** | 0.873 | 0.431 | 110M / 110M | 3.7 |
| OpenMed Bengali PII, LoRA r=16 | 51.05 | 46.7 | 56.3 | 57.01 | 0.788 | 0.780 | 0.846 | 0.367 | 0.6M / 278M | 5.2 |
| XLM-RoBERTa-base, LoRA r=16 | 49.93 | 45.9 | 54.8 | 55.95 | 0.785 | 0.756 | 0.843 | 0.368 | 0.6M / 277M | 3.8 |

Published reference: BanglishBERT 56.13 ± 0.75 (Khan et al., 2023).

### E4 — three seeds (7, 13, 42), mean ± SD, ×100 (`scripts/98_seed_summary.py`)

| Config | Seeds | Micro F1 | Macro F1 | Medicine F1 | Medicine R (Bangla script) | Dosage F1 |
|---|---|---|---|---|---|---|
| OpenMed Bengali PII (mDeBERTa, 278M), full | 3 | **58.71 ± 0.84** | **64.00 ± 0.74** | 83.97 ± 0.53 | 81.83 ± 0.36 | 44.91 ± 1.09 |
| XLM-RoBERTa-base (277M), full | 3 | 58.67 ± 0.75 | 63.58 ± 0.77 | **84.23 ± 0.83** | **82.31 ± 0.86** | 45.18 ± 1.89 |
| BanglishBERT (110M), full | 3 | 57.81 ± 0.40 | 62.99 ± 0.74 | 83.03 ± 0.33 | 80.77 ± 0.50 | **45.29 ± 1.43** |
| BanglaBERT (110M), full | 1 | 55.75 | 60.65 | 81.83 | 83.36 | 43.13 |
| OpenMed Bengali PII, LoRA r=16 | 1 | 51.05 | 57.01 | 78.85 | 78.05 | 36.71 |
| XLM-RoBERTa-base, LoRA r=16 | 1 | 49.93 | 55.95 | 78.54 | 75.61 | 36.82 |

Findings:
* The top three full fine-tuned models are tied within one SD (Welch t-test, BanglishBERT vs XLM-R: t ≈ 1.8, n = 3 each, not significant).
* All three sit 1.7–2.6 points above the published 56.13 ± 0.75. Setup details (learning rate, epochs, best-epoch selection on validation) may explain part of this, so we report "matches or exceeds", not a new state of the art.
* BanglishBERT is within 0.9 points of the best at 40% of the size and has the lowest seed variance: chosen as the on-device model (E5).
* LoRA (query/value, r = 16, 0.6M trainable) loses 7–9 points against full fine-tuning at this data size.
* Dosage (~45 F1) and Symptom remain the weakest types; dose patterns are handled by deterministic rules (`rules.py`) in the app.
Bangla-script Medicine recall rises from 0.000–0.093 (English OpenMed NER, E2, overlap match) to 0.76–0.83 (exact match).

## E5 — INT8 ONNX export of BanglishBERT (banglishbert-full-s42), full test split (3,179 docs)

CPU, 4 threads, batch 1 (one document at a time, like a phone). Hellbender CPU node, onnxruntime.

| Version | Size | Micro F1 | Medicine F1 | Median ms / doc |
|---|---|---|---|---|
| PyTorch FP32 | ~420 MB | 57.41 | 82.70 | 53.2 |
| ONNX FP32 | 420 MB | 57.41 | 82.70 | 33.4 |
| ONNX INT8 (dynamic, weights) | **106 MB** | 57.32 | 82.50 | **19.5** |

* INT8 is 4.0× smaller and 2.7× faster than PyTorch, with a 0.09-point F1 loss; 99.12% of word tags unchanged.
* ONNX FP32 matches PyTorch exactly (export is lossless).
* Server-CPU latency; phone latency is measured in E7 (expect several times slower on a low-cost phone CPU).

## E3b — Clinical-entity protection (BanglishBERT tagger keeps Medicine / Dosage), results/exp3b_protect_banglishbert-full-s42.json

The fine-tuned E4 tagger's Medicine/Dosage spans are cut out of OpenMed's PII spans; rule spans are never cut.
Thresholds chosen on dev (leak minimal with over-redaction ≤ 0.10): hybrid 0.5, hybrid+protect 0.3.

| Split | Mode (threshold) | PII span leak [95% CI] | Docs with any leak | Clinical over-redaction |
|---|---|---|---|---|
| Held-out synthetic | hybrid (0.5) | 0.006 [0.003, 0.011] | 0.03 | 0.084 |
| Held-out synthetic | hybrid + protect (0.5) | 0.006 (paired diff +0.000, McNemar 0 vs 0) | 0.03 | 0.000 |
| Held-out synthetic | **hybrid + protect (0.3, chosen on dev)** | **0.000** [0.000, 0.000] | **0.00** | **0.001** |
| Real text | hybrid (0.5) | 0.002 [0.001, 0.004] | 0.01 | 0.369 |
| Real text | hybrid + protect (0.5) | 0.002 (paired diff +0.000, McNemar 0 vs 0) | 0.01 | 0.062 |
| Real text | **hybrid + protect (0.3, chosen on dev)** | **0.000** [0.000, 0.000] | **0.00** | **0.069** |

* At the same threshold, protection cuts clinical over-redaction on real text from 36.9% to 6.2% with no added leak (no document leaks with protection that did not leak without it).
* Because medicines are now safe, the dev rule can pick a more aggressive PII threshold (0.3); this removes the remaining leaks while over-redaction stays ≤ 7%.
* "0.000" means no leaked span was observed; the report should give a rule-of-three upper bound (≈ 3 / number of gold PII spans in the split).
* Caveat: the tagger was trained on the Bangla-HealthNER train split and the real-text set uses test-split posts (same domain), so the real-text gain is in-domain.

## E6 — Small LLM explanations of lab reports (100 held-out synthetic reports × EN/BN × 2 prompts, 4-bit NF4)

`free` = LLM reads the de-identified report; `grounded` = rules compute every HIGH/LOW/NORMAL flag and the
LLM only rewrites this fact sheet. Automatic keyword-based proxies (results/e6_summary.md); hand rating pending.

English (% of abnormal results; % of outputs):

| Model | Abnormal correct (free → grounded) | Abnormal WRONG direction (free → grounded) | Blocked by number check (free → grounded) | Misattributed number (free → grounded) | Doctor advice (grounded) |
|---|---|---|---|---|---|
| **Qwen3-1.7B** | 75.1 → **100.0** | 23.9 → **0.0** | 2 → **0** | 2 → **0** | 100 |
| Qwen2.5-1.5B-Instruct | 27.9 → 95.0 | 26.4 → 3.0 | 1 → 0 | 3 → 1 | 25 |
| Phi-3.5-mini-instruct (3.8B) | 81.6 → 92.0 | 17.4 → 0.5 | 31 → 11 | 28 → 7 | 83 |
| Qwen2.5-0.5B-Instruct | 24.9 → 71.1 | 42.3 → 11.4 | 37 → 10 | 30 → 7 | 29 |

* Free explanations flip high/low for 17–42% of abnormal results in every model: an LLM must not decide abnormality.
* The rule-computed fact sheet removes almost all direction errors; Qwen3-1.7B (4-bit) is perfect on these proxies → English explainer.
* The number check is conservative: it also blocks harmless general numbers (e.g., Phi-3.5 "average over the past 2-3 months"); the cost is a fall-back to the template, never a wrong number shown.
* It cannot catch a report's own numbers used in the wrong role (e.g., "Haemoglobin is usually between 10.2 and 15.5", 10.2 being the patient's value); the misattribution check catches only numbers moved between tests.

Bangla: **no model produced usable Bangla explanations.** 55–99% of abnormal results are not mentioned, 12–63% of
outputs loop (e.g., one word repeated to the token limit), and readable outputs copy the English fact sheet with
wrong or invented terms (e.g., "Hematocrit" for haemoglobin, a non-word for HIGH). The app therefore shows the
deterministic Bangla template (always correct by construction) for Bangla users; small-model Bangla generation is future work.

### E6 re-run with a 1,024-token limit (results/e6_mn1024_table.txt)

Bangla uses ~1 token per character (median 305 characters vs 909 for English at the same 320-token cap), so the
first run cut Bangla answers short. With 1,024 tokens:
* English is unchanged (robust): Qwen3-1.7B grounded 100.0% abnormal correct, 0% wrong, 0 blocked, 0 misattributed;
  Qwen2.5-1.5B grounded 96.0 / 3.0; Phi-3.5 grounded 94.0 / 1.0; Qwen2.5-0.5B grounded 77.6 / 8.5.
* Bangla does NOT recover; more room mostly means more looping: 66–100% of Bangla outputs loop
  (Qwen2.5-0.5B 100%, Qwen2.5-1.5B grounded 98%, Qwen3 74–77%, Phi-3.5 grounded 87%); abnormal correct 0–22%.
  The Bangla failure is a model limitation, not a truncation artefact.

### E6b — LLM-as-judge, rubric v1 (holistic verdict), Qwen2.5-14B-Instruct 4-bit, 320-token run

Validation against the independent 60-row rating (Claude): statuses_correct kappa = 0.00 (82% raw agreement, but the
judge scored almost every output as wrong, including outputs that are fully correct), safe kappa = 0.52.
Rubric v1 is therefore not used for results. Rubric v2: the judge extracts the status each test is given (without
seeing the answer key); code scores it.

### E6b — LLM-as-judge, rubric v2 (per-test extraction, code scoring), Qwen2.5-14B-Instruct 4-bit

Validation on the 60-row independently rated sample (320-token run): **statuses_correct kappa = 0.80 (93% agree),
safe kappa = 0.66 (83% agree)** → v2 accepted (v1 holistic: kappa 0.00 / 0.52, rejected). n = 60 is small; the
kappa confidence interval is wide. The independent rating is an LLM rating (Claude), disclosed as such.

Final judged results, 1,024-token run (% of 100 outputs per cell; "correct" = every stated status right AND every
abnormal result mentioned, a stricter per-output measure than the per-result keyword proxy):

| Model | EN free: correct / safe | EN grounded: correct / safe | BN free: correct / safe | BN grounded: correct / safe | BN clarity (1–5, grounded) |
|---|---|---|---|---|---|
| Qwen3-1.7B | 16 / 53 | **95 / 61** | 8 / 46 | 50 / 50 | 2.91 |
| Phi-3.5-mini (3.8B) | 55 / 52 | **98 / 68** | 25 / 66 | 18 / 81 | 2.01 |
| Qwen2.5-1.5B | 6 / 12 | 59 / 23 | 8 / 14 | 31 / 24 | 2.27 |
| Qwen2.5-0.5B | 4 / 11 | 22 / 17 | 5 / 67 | 3 / 54 | 1.79 |

Findings:
* The rule-computed fact sheet is the single biggest effect: English correctness 4–55% → 22–98%.
* Correct statuses are not enough for safety. Even with the fact sheet, the best models add a misleading
  interpretation in about a third of outputs (judge "misleading" 31–37 per 100 for Qwen3 / Phi; e.g. "low HbA1c
  means better sugar control"); Qwen2.5-1.5B also recommends supplements (treatment 15/100). Next design step:
  forbid interpretation in the prompt, or show only the template plus a fixed, pre-written sentence per status.
* Bangla: no model is usable. Best case (Qwen3 grounded) is 50% correct, 50% safe, clarity 2.9/5.
* The 320- and 1,024-token runs give the same English picture (Qwen3 grounded 95 / 95).

## E6c — strict "no interpretation" prompt vs template (1,024 tokens, judge v2, % of 100 outputs)

| System | EN correct / safe / clarity | BN correct / safe / clarity | BN blocked by number check | BN looping |
|---|---|---|---|---|
| Qwen3-1.7B, fact sheet (E6) | 95 / 60 / 4.90 | 50 / 49 / 2.93 | – | 74% |
| **Qwen3-1.7B, strict** | **97 / 96 / 4.98** | 71 / 78 / 4.21 | 13% | 18% |
| Phi-3.5-mini, fact sheet (E6) | 98 / 71 / 4.94 | 18 / 82 / 1.99 | – | 87% |
| Phi-3.5-mini, strict | 96 / 94 / 4.93 | 35 / 66 / 3.27 | 27% | 36% |
| **Template (no LLM)** | 99 / 98 / 4.97 | **100 / 99 / 5.00** | 0% | 0% |

* Forbidding interpretation removes almost all misleading claims in English (Qwen3: 38 → 4 per 100) with no loss of
  correctness: safe 60% → 96%.
* In Bangla the strict prompt helps a lot (Qwen3 50 → 71% correct, looping 74% → 18%) but is still far below the template.
* The template scores 99–100% correct / 98–99% safe with the judge, although it is correct by construction: the
  1–2% gap is an estimate of the judge's own error rate.
* Keyword proxy under-reads Bangla (Qwen3 BN strict: 16.9% abnormal correct by keywords vs 71% by the judge) because
  models spell test names in many ways; the validated judge is the primary measure.
* System decision: English = Qwen3-1.7B strict + number check (template fallback); Bengali = template, pending the
  native-speaker check (E6d). Template Bengali labels were revised before E6d (e.g. "শ্বেত" → "শ্বেত রক্তকণিকা").

## E6d — Native-speaker check of Bengali explanations (blinded, 30 reports × 2 systems, one native rater = author)

| System | Statuses correct | Clear (1–5) | Natural Bengali (1–5) | Safe |
|---|---|---|---|---|
| **Template** | **100%** | **5.00** | **5.00** | 100% |
| Qwen3-1.7B strict (E6c) | 60% | 2.27 | 1.03 | 100% |

* Paired on the same 30 reports: the template was rated clearer AND more natural on all 30 (sign test p < 0.001 for both).
* Native rater vs LLM judge (same 60 outputs): 82% agreement on correctness, 87% on safety.
* The LLM judge strongly over-rates Bengali fluency: it gave Qwen3's Bengali 4.21/5 for clarity, the native rater
  2.27/5 (clarity) and 1.03/5 (naturalness); judged correctness 71% vs 60% native. Judge Bengali clarity scores
  are therefore not reported as evidence; only human ratings are used for Bengali quality.
* Caveats: one rater who is also the author; the template has a recognisable fixed pattern, so blinding is partial.
* Decision confirmed: Bengali output = deterministic template.

## System demo run (scripts/11_pipeline.py, 8 held-out reports, all stages on: rules + OpenMed PII (0.3) + BanglishBERT protection + Qwen3-1.7B strict)

* English explanation passed the number + coverage gate on 8/8 reports (source = LLM); Bengali = template.
* Personal-detail spans removed per report: 12–16 (rules: ID, phone, facility, address; OpenMed: names, dates, other).
* Over-redaction found in the first demo run ("SGPT (ALT) 1 [PII]/L [PII]" in report 0000) → pipeline v1.1 never
  redacts parsed lab rows; re-run confirmed "SGPT (ALT) 1 U/L 7-45" is kept.
* With the strict prompt, Qwen3's English output is close to a copy of the fact sheet (8/8 passed both checks,
  2–10 s per report on an H100): once constrained enough to be safe, the LLM adds little over the template.

## E7a — Phone export and privacy check of the phone version (results/e7a_mobile.json)

Assets: BanglishBERT tagger INT8 106 MB; OpenMed PII bn INT8 322 MB; OpenMed PII en INT8 164 MB (DeBERTa-style, 106 labels);
616 MB shipped in total. Tokenizer files match the Hugging Face tokenizers on every test word; ONNX FP32 logits match
PyTorch (max diff < 1e-5); INT8 argmax agreement 0.985 (en).

Held-out synthetic, 300 reports, word-level phone pipeline (E7a leak rule: any visible non-space character):

| System | Leak % | Lab-value damage % | Medicine damage % | Over-redaction % |
|---|---|---|---|---|
| Research pipeline (openmed package, PyTorch, 0.3) | 0.00 | 0.0 | 0.0 | 8.15 |
| Phone, FP32, 0.3 | 4.18 | 0.0 | 0.0 | 5.40 |
| Phone, INT8, 0.3 | 16.54 | 0.0 | 0.0 | 4.16 |
| Rules only (v1) | 52.85 | 0.0 | 0.0 | 0.00 |

INT8 leaks by type: NAME 27.7%, DOCTOR 36.5%, DATE 28.0%; all rule-covered types 0%. Latency on Hellbender CPU
(4 threads): INT8 219 ms median per report, FP32 303 ms.
Reading: two separate losses, (1) word-level decoding vs openmed's decoding (0 -> 4.2) and (2) dynamic INT8
quantization of the PII models (4.2 -> 16.5). Not shippable as is. E7b tunes quantization, aggregation, threshold and
adds header rules (date, name field, doctor title), chosen on dev only, and adds a "free" set where names sit inside
sentences without any label, so rule gains cannot hide model losses.

## E7b — Phone privacy settings (results/e7b_mobile_tune.json)

Run 1 chose settings that hid 58% of all non-personal text (selection only limited medicine/lab damage) - rejected.
Run 2 (limit: other text hidden <= 0.10) chose bn=int8, en=int8, mean, 0.2 + v2 header rules: 0.0% leak and 4.2%
text hidden on held-out synthetic, but on the "free" set (unlabelled names inside real sentences, 400 texts):

| PII models (model alone) | dev leak | test leak | real leak | free leak |
|---|---|---|---|---|
| FP32, mean, 0.1 | 0.179 | 0.161 | 0.236 | **0.007** |
| INT8 (plain dynamic), mean, 0.2 | 0.558 | 0.496 | 0.546 | **0.507** |
| INT8 per-channel / MatMul-only | 1.000 | 1.000 | 1.000 | 1.000 (predict nothing) |

Header rules make the synthetic and injected sets look solved (they use the same field labels), so the free set is
the honest privacy test: plain INT8 loses half the unlabelled names. Run 3 adds reduce_range quantization, a
per-language variant choice (with size cost), a disjoint free_dev set for selection, and leak by language.

E7b run 3 (reduce_range variants, per-language choice, free_dev selection set; model alone unless noted):

| PII models | MB | free_dev leak | free leak | free/pmc (EN) | free/hn (BN) |
|---|---|---|---|---|---|
| FP32 both | 1602 | 0.033 | 0.007 | 0.015 | **0.000** |
| INT8 plain both | 486 | 0.527 | 0.507 | 0.015 | **1.000** |
| INT8 reduce_range both | 486 | 0.357 | 0.330 | 0.405 | 0.255 |
| bn INT8 rr + en INT8 plain | 486 | 0.190 | 0.135 | 0.015 | 0.255 |
| chosen: bn INT8 rr + en FP32 (<= 1000 MB) | 862 | 0.185 | 0.135 | 0.015 | 0.255 |

Finding: plain INT8 is harmless for the English model on free text (0.015 = FP32) but destroys the Bengali model
(XLM-R-based, 279M): every unlabelled Bengali name is missed. reduce_range recovers part (25.5% missed). The Bengali
model is the core of the product, so run 3's setting is not acceptable. E7c keeps sensitive parts in FP32
(embedding-only INT8; INT8 with attention MatMuls excluded) and sets a 700 MB budget for the two PII models
(declared after run 3, from the target of ~800 MB total assets).

E7c (partial quantization; settings chosen on dev + free_dev, PII models <= 700 MB):

| PII models (model alone) | MB | free_dev leak | free leak | free/pmc (EN) | free/hn (BN) | test/bn |
|---|---|---|---|---|---|---|
| FP32 both | 1602 | 0.033 | 0.007 | 0.015 | 0.000 | 0.033 |
| INT8 embedding table only, both | 770 | 0.033 | 0.007 | 0.015 | 0.000 | 0.033 |
| INT8 except attention (plain / rr) | 526 | 0.525 / 0.268 | 0.510 / 0.280 | 0.020 / 0.420 | 1.000 / 0.140 | 1.000 / 0.378 |
| **chosen: bn INT8-embedding + en INT8-except-attention** | **689** | 0.035 | **0.010** | 0.020 | **0.000** | 0.033 |

With v2 header rules (shipped): leak 0.000 on dev, test and real; 0.010 on free; other text hidden 1-6%;
medicine/lab values hidden <= 3.1%.
Finding: the damage from INT8 comes from dynamically quantized matrix multiplications (activations), not from the
weights of the 250k-token embedding table. Quantizing only the embedding table (a lookup, no activation quantization)
gives FP32 accuracy at half the size. For the Bengali XLM-R model any activation quantization breaks unlabelled-name
detection; the English model tolerates it. Budget (700 MB) was set after run 3.
Final phone setting on 300 held-out reports: leak 0.0%, lab/medicine damage 0%, other text hidden 5.1% (research
pipeline 8.2%); 181 ms median per report on 4 Hellbender CPU threads (FP32 same settings 207 ms). Golden files for the
app regenerated with this setting (mobile/golden/golden.jsonl, 300 reports; gate_cases.jsonl, 400 LLM outputs).

## E8 (desktop proxy) — reading the printed test sheets with Tesseract (results/e8_ocr_proxy.json)

Not the phone result. 30 printable sheets (mobile/eval/E8_printable.pdf: 15 lab reports, 8 mixed prescriptions,
7 Bengali notes) rendered at ~150 dpi; Tesseract 5.3.4 with the same "fast" ben/eng models the app ships, PSM 6;
privacy = rules only (v1 + v2), as in app v0.2. Metrics in src/shastho/ocr_eval.py (mirrored in Kotlin, golden-tested).

| condition | model | CER | lab rows exact | flags correct | details leaked | s/page |
|---|---|---|---|---|---|---|
| clean | ben+eng | 0.016 | 65.2% | 81.8% | 8.4% | 2.0 |
| clean | eng only | 0.259 (Bengali notes 0.765) | 65.2% | 81.8% | 2.5% | 1.3 |
| tilted 3° | ben+eng | 0.025 | 48.5% | 71.2% | 15.3% | 1.7 |
| half resolution | ben+eng | 0.027 | 42.4% | 75.8% | 12.4% | 1.5 |
| dark + blur + noise (simulated) | ben+eng | 1.8 (garbage) | 0% | 0% | 3.5% | 44 |

Readings:
- Bengali needs the Bengali model: English-only Tesseract turns Bengali notes into noise (CER 0.77).
- Low CER does not mean usable rows: clean lab reports have CER 0.008, yet only 65% of rows are exact, because of
  single-character errors in exactly the parts that matter: "x10^9/L" -> "x1049/L" (unit), "25-OH" -> "25-0H"
  (O read as zero, so the test name no longer matches). Values themselves were mostly right (flags 82%).
- OCR noise breaks the privacy rules: "Dr." -> "pr.", "ডা." -> "ভা."/"GT.", the leading 0 of a phone number
  dropped ("1528-823588"), "MADHUMATI. CLINIC", and a doctor's name pushed to the next line by the page width.
  Each defeats a format rule. This is the strongest argument that the privacy models (app v0.3) are needed on top of
  rules for photographed input. OCR-tolerant label rules ("Mobile:", "Reported by", "চিকিৎসক:") and a test-name
  dictionary repair would fix most of these, but they are designed after seeing these sheets, so they must be reported
  as post-hoc and checked on other data.
- The simulated dark/noisy condition is far harsher than a real photo (it adds per-pixel noise) and makes Tesseract
  take ~45 s per page; the app therefore stops Tesseract after 30 s. Real dim photos are measured on the phone (E8).
- Leak metric is token-level: a shared surname visible elsewhere counts as a leak (conservative).
