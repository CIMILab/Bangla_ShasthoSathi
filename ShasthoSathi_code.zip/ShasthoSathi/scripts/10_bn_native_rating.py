"""Native-speaker check of Bengali explanations (E6d).

Make a blinded rating sheet: the same 30 held-out reports explained twice in Bengali, once by the deterministic
template and once by Qwen3-1.7B with the strict prompt (E6c). The 60 items are shuffled and the system is hidden;
the key is written to a separate file. After rating, --score compares the two systems and checks agreement with
the LLM judge.

    python scripts/10_bn_native_rating.py --make            # writes the sheet + key
    python scripts/10_bn_native_rating.py --score results/e6_rating/bn_native_rating_samrat.csv
"""
import argparse, csv, json, pathlib, random, statistics, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from shastho.rules import flag_value

ap = argparse.ArgumentParser()
ap.add_argument("--make", action="store_true")
ap.add_argument("--score", default=None, help="filled rating sheet")
ap.add_argument("--e6c", default="results/e6c")
ap.add_argument("--judge", default="results/e6_judge/Qwen__Qwen2.5-14B-Instruct__e6c__v2.jsonl")
ap.add_argument("--data", default="data/synthetic/synth_heldout.jsonl")
ap.add_argument("--n", type=int, default=30)
ap.add_argument("--seed", type=int, default=2026)
ap.add_argument("--sheet", default="results/e6_rating/bn_native_rating.csv")
ap.add_argument("--key", default="results/e6_rating/bn_native_key.csv")
a = ap.parse_args()
docs = {d["doc_id"]: d for d in map(json.loads, open(a.data, encoding="utf-8"))}
fmt = lambda x: f"{x:g}"
COLS = ["rater_statuses_correct(0/1)", "rater_clear(1-5)", "rater_natural_bangla(1-5)", "rater_safe(0/1)"]


def facts(d):
    return "\n".join(f"{l['name']}: {fmt(l['value'])} {l['unit']} (normal {fmt(l['low'])}-{fmt(l['high'])}) -> "
                     f"{flag_value(l['value'], l['low'], l['high']).upper()}" for l in d["labs"])


if a.make:
    load = lambda f: {r["doc_id"]: r for r in map(json.loads, open(f, encoding="utf-8")) if r["lang"] == "bn"}
    tmpl = load(f"{a.e6c}/template__none.jsonl")
    qwen = load(f"{a.e6c}/Qwen__Qwen3-1.7B__4bit.jsonl")
    ids = sorted(set(tmpl) & set(qwen))
    rr = random.Random(a.seed)
    pick = rr.sample(ids, min(a.n, len(ids)))
    items = [(d, "template", tmpl[d]["output"]) for d in pick] + [(d, "qwen3_strict", qwen[d]["output"]) for d in pick]
    rr.shuffle(items)
    pathlib.Path(a.sheet).parent.mkdir(parents=True, exist_ok=True)
    with open(a.sheet, "w", newline="", encoding="utf-8-sig") as f, open(a.key, "w", newline="", encoding="utf-8") as k:
        w = csv.writer(f); kw = csv.writer(k)
        w.writerow(["item", "facts (answer key)", "bengali_explanation"] + COLS + ["notes"])
        kw.writerow(["item", "doc_id", "system"])
        for i, (d, sysname, out) in enumerate(items, 1):
            w.writerow([i, facts(docs[d]), out, "", "", "", "", ""])
            kw.writerow([i, d, sysname])
    print(f"wrote {a.sheet} ({len(items)} items, system hidden) and {a.key} (do not open until rating is done)")

if a.score:
    key = {r["item"]: r for r in csv.DictReader(open(a.key, encoding="utf-8"))}
    rows = list(csv.DictReader(open(a.score, encoding="utf-8-sig")))
    by = {"template": [], "qwen3_strict": []}
    for r in rows:
        if not r[COLS[0]].strip():
            continue
        s = key[r["item"]]["system"]
        by[s].append({"doc": key[r["item"]]["doc_id"], "correct": int(r[COLS[0]]), "clear": int(r[COLS[1]]),
                      "natural": int(r[COLS[2]]), "safe": int(r[COLS[3]])})
    print("| system | n | statuses correct % | clear (mean) | natural Bangla (mean) | safe % |\n|---|---|---|---|---|---|")
    for s, v in by.items():
        if v:
            print(f"| {s} | {len(v)} | {100*statistics.mean(x['correct'] for x in v):.1f} | "
                  f"{statistics.mean(x['clear'] for x in v):.2f} | {statistics.mean(x['natural'] for x in v):.2f} | "
                  f"{100*statistics.mean(x['safe'] for x in v):.1f} |")
    # paired comparison on the same reports (sign test on clarity / naturalness)
    T = {x["doc"]: x for x in by["template"]}; Q = {x["doc"]: x for x in by["qwen3_strict"]}
    common = sorted(set(T) & set(Q))
    from math import comb
    for field in ("clear", "natural"):
        wins = sum(Q[d][field] > T[d][field] for d in common); loss = sum(Q[d][field] < T[d][field] for d in common)
        n = wins + loss
        p = min(1.0, 2 * sum(comb(n, i) for i in range(0, min(wins, loss) + 1)) / 2 ** n) if n else 1.0
        print(f"paired {field}: Qwen3 better {wins}, template better {loss}, ties {len(common)-n}, sign-test p={p:.3f}")
    # agreement with the LLM judge on the same outputs
    if pathlib.Path(a.judge).exists():
        J = {(j["doc_id"], "template" if j["model"] == "template" else "qwen3_strict"): j
             for j in map(json.loads, open(a.judge, encoding="utf-8")) if j["lang"] == "bn" and j.get("parse_ok")}
        for field in ("correct", "safe"):
            jf = "statuses_correct" if field == "correct" else "safe"
            pairs = [(x[field], J[(x["doc"], s)][jf]) for s, v in by.items() for x in v if (x["doc"], s) in J]
            agree = sum(p == q for p, q in pairs) / len(pairs) if pairs else float("nan")
            print(f"native rater vs LLM judge [{field}]: agree {100*agree:.0f}% (n={len(pairs)})")
