"""Experiment 6: can a small LLM explain a lab report without inventing numbers or flipping high/low?

For each held-out synthetic lab report (personal details already removed):
  * free      : the LLM reads the report and explains it
  * grounded  : deterministic rules first compute every high/low/normal flag (rules.flag_value);
                the LLM only rewrites this fact sheet in plain language
Every output then goes through the number check (rules.unsupported_numbers). An output that
contains a number not present in the report is blocked and replaced by a fixed template, so
the user never sees an invented number; E6 reports how often that happens.

Automatic metrics (per model x language x condition):
  unsupported-number rate, abnormal results stated with the correct direction / the wrong
  direction / not mentioned, normal results called abnormal, Bangla-script share (Bangla
  outputs), doctor advice, words, tokens per second. A random sample goes to a CSV for manual rating.

    python scripts/08_llm_explain.py --models Qwen/Qwen2.5-1.5B-Instruct --quant 4bit
    python scripts/08_llm_explain.py --summarize            # merge results/e6/*.jsonl into tables
"""
import argparse, collections, csv, glob, json, pathlib, random, re, statistics, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from shastho.rules import flag_value, unsupported_numbers, numbers_in, _canon

ap = argparse.ArgumentParser()
ap.add_argument("--models", nargs="+", default=["Qwen/Qwen2.5-1.5B-Instruct"])
ap.add_argument("--quant", choices=["4bit", "bf16"], default="4bit")
ap.add_argument("--data", default="data/synthetic/synth_heldout.jsonl")
ap.add_argument("--n-docs", type=int, default=100)
ap.add_argument("--langs", nargs="+", default=["en", "bn"])
ap.add_argument("--conditions", nargs="+", default=["free", "grounded"])
ap.add_argument("--batch", type=int, default=16)
ap.add_argument("--max-new", type=int, default=320)
ap.add_argument("--out-dir", default="results/e6")
ap.add_argument("--summarize", action="store_true")
ap.add_argument("--template-only", action="store_true", help="E6c: write the deterministic template as a baseline 'model'")
ap.add_argument("--review-n", type=int, default=60, help="outputs sampled for manual rating")
a = ap.parse_args()
OUT = pathlib.Path(a.out_dir); OUT.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- vocabulary for the automatic checks
ALIASES = {  # test -> words that identify it in English or Bangla output
    "Haemoglobin": ["haemoglobin", "hemoglobin", "হিমোগ্লোবিন", "হ্যামোগ্লোবিন"],
    "WBC Count": ["wbc", "white blood", "white cell", "শ্বেত", "ডব্লিউবিসি"],
    "Platelet Count": ["platelet", "প্লাটিলেট", "প্লেটলেট", "প্লেটেলেট", "অণুচক্রিকা"],
    "Fasting Blood Sugar": ["fasting blood sugar", "fasting sugar", "blood sugar", "glucose", "সুগার", "শর্করা", "গ্লুকোজ"],
    "HbA1c": ["hba1c", "a1c", "এইচবিএ১সি", "এইচবিএওয়ানসি"],
    "S. Creatinine": ["creatinine", "ক্রিয়েটিনিন", "ক্রিয়াটিনিন", "ক্রিয়েটিনিন"],
    "SGPT (ALT)": ["sgpt", "alt", "liver enzyme", "এসজিপিটি", "লিভার"],
    "Serum Uric Acid": ["uric", "ইউরিক"],
    "TSH": ["tsh", "thyroid", "টিএসএইচ", "থাইরয়েড", "থাইরয়েড"],
    "Total Cholesterol": ["cholesterol", "কোলেস্টেরল", "কোলেস্টেরল"],
    "Triglyceride": ["triglyceride", "ট্রাইগ্লিসারাইড"],
    "Vitamin D (25-OH)": ["vitamin d", "ভিটামিন ডি", "ভিটামিন-ডি"],
}
BN_NAME = {k: next((x for x in v if re.search("[ঀ-৿]", x)), k) for k, v in ALIASES.items()}
DIR = {"high": ["high", "elevated", "above", "raised", "increased", "বেশি", "উচ্চ", "বেড়ে", "বাড়তি"],
       "low": ["low", "below", "decreased", "reduced", "deficien", "কম", "নিম্ন", "কমে", "ঘাটতি"],
       "normal": ["normal", "within", "নরমাল", "নোরমাল", "স্বাভাবিক", "ঠিক আছে", "সীমার মধ্যে"]}
DOCTOR = ["doctor", "physician", "ডাক্তার", "চিকিৎসক"]
def _rx(w, whole_short=True):
    """Latin words must start at a word boundary ('low' matches 'lower' but not 'follow'); short
    aliases (alt, tsh, wbc) must also end at one ('alt' does not match 'health'). Bangla: substring."""
    if re.search("[ঀ-৿]", w):
        return re.compile(re.escape(w))
    return re.compile(r"\b" + re.escape(w) + (r"\b" if whole_short and len(w) <= 4 else ""))


ALIAS_RX = {k: [_rx(w) for w in v] for k, v in ALIASES.items()}
DIR_RX = {k: [_rx(w, whole_short=False) for w in v] for k, v in DIR.items()}
SEG = re.compile(r"(?<![0-9০-৯])\.(?![0-9০-৯])|[\n।!?;]")
LIST_MARK = re.compile(r"(?m)^\s*(?:[-*•]|\(?[0-9০-৯]{1,2}[.)])\s+")


UNIT_NUMS = {_canon("25"), _canon("9"), _canon("10")}   # from "25-OH" and "x10^9/L", not results


def redact(d):
    t = d["text"]
    for g in sorted(d["pii"], key=lambda g: -g["start"]):
        t = t[:g["start"]] + f"[{g['type']}]" + t[g["end"]:]
    return t


def fmt(x):
    return f"{x:g}"


def facts(d):
    word = {"high": "HIGH (above the normal range)", "low": "LOW (below the normal range)", "normal": "NORMAL"}
    return "\n".join(f"- {l['name']}: {fmt(l['value'])} {l['unit']} (normal range {fmt(l['low'])}-{fmt(l['high'])}) -> "
                     f"{word[flag_value(l['value'], l['low'], l['high'])]}" for l in d["labs"])


BN_LABEL = {  # patient-facing Bengali test names for the template (no digits, so the number check stays exact)
    "Haemoglobin": "হিমোগ্লোবিন", "WBC Count": "শ্বেত রক্তকণিকা", "Platelet Count": "প্লাটিলেট (অণুচক্রিকা)",
    "Fasting Blood Sugar": "খালি পেটে রক্তের শর্করা", "HbA1c": "গড় রক্তের শর্করা (HbA1c)",
    "S. Creatinine": "ক্রিয়েটিনিন (কিডনির পরীক্ষা)", "SGPT (ALT)": "এসজিপিটি (লিভারের এনজাইম)",
    "Serum Uric Acid": "ইউরিক অ্যাসিড", "TSH": "টিএসএইচ (থাইরয়েড হরমোন)", "Total Cholesterol": "মোট কোলেস্টেরল",
    "Triglyceride": "ট্রাইগ্লিসারাইড", "Vitamin D (25-OH)": "ভিটামিন ডি",
}


def template(d, lang):
    """Deterministic fallback shown when an LLM output fails the number check."""
    if lang == "bn":
        st = {"high": "স্বাভাবিকের চেয়ে বেশি", "low": "স্বাভাবিকের চেয়ে কম", "normal": "স্বাভাবিক সীমার মধ্যে"}
        rows = [f"{BN_LABEL[l['name']]} — {l['name']}: {fmt(l['value'])} {l['unit']} — {st[flag_value(l['value'], l['low'], l['high'])]} "
                f"(স্বাভাবিক সীমা {fmt(l['low'])}-{fmt(l['high'])})।" for l in d["labs"]]
        return "\n".join(rows + ["এই রিপোর্টটি আপনার ডাক্তারকে দেখান।"])
    st = {"high": "higher than normal", "low": "lower than normal", "normal": "within the normal range"}
    rows = [f"{l['name']}: {fmt(l['value'])} {l['unit']} is {st[flag_value(l['value'], l['low'], l['high'])]} "
            f"(normal range {fmt(l['low'])}-{fmt(l['high'])})." for l in d["labs"]]
    return "\n".join(rows + ["Please show this report to your doctor."])


SYSTEM = ("You are a careful health assistant for patients in Bangladesh. You explain lab reports in plain, "
          "friendly language. You never give a diagnosis, never suggest medicines and never invent numbers.")
LANG = {"en": "English", "bn": "Bangla (Bengali script)"}


STRICT = ("Rules: write exactly one short sentence per test, in the order given, with the test name, the value and "
          "whether it is high, low or normal, exactly as in the facts. Do not explain causes. Do not say what a result "
          "means for health or whether it is good or bad. Do not name any disease. Do not suggest food, lifestyle, "
          "medicines, supplements or more tests. Do not add any number that is not in the facts. After the sentences, "
          "write one final sentence telling the patient to show this report to their doctor.")


def prompt(d, lang, cond):
    if cond == "strict":   # E6c: fact sheet + no interpretation
        return (f"These facts were checked by the app:\n{facts(d)}\n\nRewrite them for the patient in simple "
                f"{LANG[lang]}.\n{STRICT}")
    if cond == "free":
        return (f"Here is a lab report:\n\n{redact(d)}\n\nExplain these results to the patient in simple {LANG[lang]}. "
                f"For each test, say whether it is high, low or normal. Keep it under 150 words. "
                f"End by advising the patient to talk to their doctor.")
    return (f"These facts were checked by the app. Use only these facts and do not add any other numbers:\n{facts(d)}\n\n"
            f"Write a short explanation of these results for the patient in simple {LANG[lang]} (under 150 words). "
            f"Keep every HIGH/LOW/NORMAL status exactly as given. End by advising the patient to talk to their doctor.")


def judge(d, lang, out):
    """Automatic proxy metrics for one output."""
    clean = LIST_MARK.sub("", out.replace("**", ""))
    source = redact(d) + "\n" + facts(d)
    bad_nums = unsupported_numbers(clean, source)
    segs = [s.lower() for s in SEG.split(clean) if s.strip()]
    res = collections.Counter()
    for l in d["labs"]:
        gold = flag_value(l["value"], l["low"], l["high"])
        hit = [s for s in segs if any(rx.search(s) for rx in ALIAS_RX[l["name"]])]
        said = {k for k, rxs in DIR_RX.items() if any(rx.search(s) for s in hit for rx in rxs)}
        kind = "abn" if gold != "normal" else "norm"
        res[f"{kind}_total"] += 1
        if not hit:
            res[f"{kind}_omitted"] += 1
        elif gold in said:
            res[f"{kind}_correct"] += 1
        elif said:
            res[f"{kind}_wrong"] += 1
        else:
            res[f"{kind}_nostatus"] += 1
    # misattributed numbers: a number in a sentence about ONE test that is not that test's value or range
    # a sentence that names no test belongs to the last test named on the same line
    # ("**Creatinine** - This is ... It's usually between 0.89 and 4.0 mg")
    mis = 0
    for line in clean.lower().split("\n"):
        cur = None
        for sg in SEG.split(line):
            named = [l for l in d["labs"] if any(rx.search(sg) for rx in ALIAS_RX[l["name"]])]
            cur = named[0] if len(named) == 1 else (None if named else cur)
            if cur is not None:
                ok = {_canon(fmt(x)) for x in (cur["value"], cur["low"], cur["high"])}
                mis += sum(_canon(n) not in ok for n in numbers_in(sg) if _canon(n) not in UNIT_NUMS)
    # repetition: share of repeated word 3-grams (degenerate looping text scores high)
    w = out.split(); tri = list(zip(w, w[1:], w[2:]))
    repetition = 1 - len(set(tri)) / len(tri) if tri else 0.0
    letters = [c for c in out if c.isalpha()]
    return {"unsupported": bad_nums, "misattributed": mis, "repetition": repetition, "status": dict(res),
            "bangla_share": sum("ঀ" <= c <= "৿" for c in letters) / max(len(letters), 1),
            "doctor_advice": any(w in out.lower() for w in DOCTOR), "words": len(out.split())}


docs = [d for d in map(json.loads, open(a.data, encoding="utf-8")) if d["labs"]][: a.n_docs]

# ---------------------------------------------------------------- generation
if a.template_only and not a.summarize:   # E6c baseline: no LLM at all
    with open(OUT / "template__none.jsonl", "w", encoding="utf-8") as f:
        for d in docs:
            for lang in a.langs:
                out = template(d, lang)
                f.write(json.dumps({"model": "template", "quant": "none", "doc_id": d["doc_id"], "lang": lang,
                                    "cond": "template", "output": out, "blocked": False, "shown": out,
                                    **judge(d, lang, out), "batch_tok_per_s": 0.0, "peak_gpu_gb": None},
                                   ensure_ascii=False) + "\n")
    print("wrote", OUT / "template__none.jsonl")
elif not a.summarize:
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    for name in a.models:
        safe = name.replace("/", "__") + f"__{a.quant}"
        path = OUT / f"{safe}.jsonl"
        if path.exists():
            print("[skip] already done:", path); continue
        quant_used = a.quant
        kw = dict(torch_dtype=torch.bfloat16, device_map="auto")
        if a.quant == "4bit":
            try:
                from transformers import BitsAndBytesConfig
                import bitsandbytes  # noqa: F401
                kw["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                                                bnb_4bit_compute_dtype=torch.bfloat16)
            except Exception as e:
                print("bitsandbytes not available, falling back to bf16:", repr(e)[:120]); quant_used = "bf16"
        t0 = time.time()
        tok = AutoTokenizer.from_pretrained(name)
        tok.padding_side = "left"
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token
        model = AutoModelForCausalLM.from_pretrained(name, **kw).eval()
        print(f"loaded {name} ({quant_used}) in {time.time()-t0:.0f}s | "
              f"{model.get_memory_footprint()/2**30:.2f} GB", flush=True)
        jobs = [(d, lang, cond) for d in docs for lang in a.langs for cond in a.conditions]
        rows = []
        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()
        for i in range(0, len(jobs), a.batch):
            chunk = jobs[i:i + a.batch]
            texts = []
            for d, lang, cond in chunk:
                msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt(d, lang, cond)}]
                try:
                    texts.append(tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True,
                                                         enable_thinking=False))
                except Exception:   # templates without a system role
                    msgs = [{"role": "user", "content": SYSTEM + "\n\n" + msgs[1]["content"]}]
                    texts.append(tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True))
            enc = tok(texts, return_tensors="pt", padding=True, add_special_tokens=False).to(model.device)
            t1 = time.time()
            with torch.inference_mode():
                gen = model.generate(**enc, max_new_tokens=a.max_new, do_sample=False, pad_token_id=tok.pad_token_id)
            dt = time.time() - t1
            new = gen[:, enc["input_ids"].shape[1]:]
            n_new = int((new != tok.pad_token_id).sum())
            for (d, lang, cond), ids in zip(chunk, new):
                out = tok.decode(ids, skip_special_tokens=True).strip()
                out = re.sub(r"<think>.*?</think>", "", out, flags=re.S).strip()
                j = judge(d, lang, out)
                shown = out if not j["unsupported"] else template(d, lang)
                rows.append({"model": name, "quant": quant_used, "doc_id": d["doc_id"], "lang": lang, "cond": cond,
                             "output": out, "blocked": bool(j["unsupported"]), "shown": shown, **j,
                             "batch_tok_per_s": n_new / dt})
            print(f"  {name}: {min(i + a.batch, len(jobs))}/{len(jobs)}  ({n_new/dt:.0f} new tok/s in batch)", flush=True)
        peak = torch.cuda.max_memory_allocated() / 2**30 if torch.cuda.is_available() else None
        with open(path, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps({**r, "peak_gpu_gb": peak}, ensure_ascii=False) + "\n")
        print("wrote", path, flush=True)
        del model; torch.cuda.empty_cache() if torch.cuda.is_available() else None

# ---------------------------------------------------------------- summary over every model run so far
rows = [json.loads(l) for f in sorted(glob.glob(str(OUT / "*.jsonl"))) for l in open(f, encoding="utf-8")]
if not rows:
    sys.exit("no outputs in " + str(OUT))
_byid = {d["doc_id"]: d for d in docs}
for r in rows:   # re-score from the saved text, so fixes to the word lists apply without re-generating
    if r["doc_id"] in _byid:
        j = judge(_byid[r["doc_id"]], r["lang"], r["output"]); r.update(j); r["blocked"] = bool(j["unsupported"])
groups = collections.defaultdict(list)
for r in rows:
    groups[(r["model"].split("/")[-1] + ("" if r["quant"] == "4bit" else f" ({r['quant']})"), r["lang"], r["cond"])].append(r)


def rate(rs, k_num, k_den):
    num = sum(r["status"].get(k_num, 0) for r in rs); den = sum(r["status"].get(k_den, 0) for r in rs)
    return num / den if den else None


table = []
for (m, lang, cond), rs in sorted(groups.items()):
    table.append({"model": m, "lang": lang, "cond": cond, "n": len(rs),
                  "unsupported_number_rate": statistics.mean(bool(r["unsupported"]) for r in rs),
                  "abnormal_correct": rate(rs, "abn_correct", "abn_total"),
                  "abnormal_wrong": rate(rs, "abn_wrong", "abn_total"),
                  "abnormal_omitted": rate(rs, "abn_omitted", "abn_total"),
                  "normal_called_abnormal": rate(rs, "norm_wrong", "norm_total"),
                  "misattributed_rate": statistics.mean(r.get("misattributed", 0) > 0 for r in rs),
                  "degenerate_rate": statistics.mean(r.get("repetition", 0) > 0.35 for r in rs),
                  "bangla_share": statistics.mean(r["bangla_share"] for r in rs),
                  "doctor_advice": statistics.mean(r["doctor_advice"] for r in rs),
                  "words_median": statistics.median(r["words"] for r in rs),
                  "tok_per_s_batch": statistics.median(r["batch_tok_per_s"] for r in rs),
                  "peak_gpu_gb": rs[0].get("peak_gpu_gb")})
pct = lambda x: "-" if x is None else f"{100 * x:.1f}"
hdr = ["model", "lang", "cond", "n", "unsupported #", "misattrib #", "looping", "abn correct", "abn WRONG", "abn omitted", "normal→abn",
       "Bangla share", "doctor", "words"]
lines = ["| " + " | ".join(hdr) + " |", "|" + "---|" * len(hdr)]
for t in table:
    lines.append("| " + " | ".join([t["model"], t["lang"], t["cond"], str(t["n"]), pct(t["unsupported_number_rate"]),
                                    pct(t["misattributed_rate"]), pct(t["degenerate_rate"]), pct(t["abnormal_correct"]), pct(t["abnormal_wrong"]), pct(t["abnormal_omitted"]),
                                    pct(t["normal_called_abnormal"]), pct(t["bangla_share"]), pct(t["doctor_advice"]),
                                    f"{t['words_median']:.0f}"]) + " |")
md = "\n".join(lines)
print(md)
print("\nAll rates in %. 'unsupported #' = outputs blocked by the number check (the user sees the template instead).")
PFX = str(OUT.parent / OUT.name)   # results/e6 -> results/e6_summary.md ; results/e6_mn1024 -> results/e6_mn1024_summary.md
json.dump(table, open(PFX + "_summary.json", "w"), indent=1)
pathlib.Path(PFX + "_summary.md").write_text(md + "\n", encoding="utf-8")

rr = random.Random(0); sample = rr.sample(rows, min(a.review_n, len(rows)))
with open(PFX + "_review_sample.csv", "w", newline="", encoding="utf-8-sig") as f:
    w = csv.writer(f)
    w.writerow(["model", "doc_id", "lang", "cond", "facts", "output", "blocked",
                "rater_statuses_correct(0/1)", "rater_clear(1-5)", "rater_safe(0/1)", "notes"])
    byid = {d["doc_id"]: d for d in docs}
    for r in sample:
        w.writerow([r["model"], r["doc_id"], r["lang"], r["cond"], facts(byid[r["doc_id"]]) if r["doc_id"] in byid else "",
                    r["output"], r["blocked"], "", "", "", ""])
print(f"wrote {PFX}_summary.md, {PFX}_summary.json, {PFX}_review_sample.csv")
