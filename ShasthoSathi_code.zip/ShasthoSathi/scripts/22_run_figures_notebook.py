"""Run notebooks/03_make_figures.ipynb without Jupyter (headless, e.g. inside a Slurm job).
Executes the code cells in order in one namespace with SHOW = False. Figures go to results/figures/.

    python scripts/22_run_figures_notebook.py                 # all figures
    python scripts/22_run_figures_notebook.py --copy-to-paper # also refresh paper/final/figures/*.pdf
"""
import json, os, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
os.environ.setdefault("SHASTHO_ROOT", str(ROOT)); os.chdir(ROOT)
import matplotlib; matplotlib.use("Agg")
nb = json.load(open(ROOT / "notebooks/03_make_figures.ipynb", encoding="utf-8"))
ns = {"__name__": "__main__"}
for i, c in enumerate(x for x in nb["cells"] if x["cell_type"] == "code"):
    src = "".join(c["source"]).replace("SHOW = True", "SHOW = False")
    if "--copy-to-paper" in sys.argv:
        src = src.replace("COPY_TO_PAPER = False", "COPY_TO_PAPER = True")
    exec(compile(src, f"<cell {i}>", "exec"), ns)
