"""E7e: choose the phone's English PII variant so the phone computes what the server computes.

E7d showed that the English model with INT8 matrix multiplications (int8noattn) behaves differently on the phone's
ARM CPU: it missed 15.5% of unlabelled names in free text on the S23 vs 1.0% on the server (same texts, same code).
Models that quantize only the embedding table (int8emb) have no INT8 matrix multiplication and gave identical labels
on both (Bengali model). This script switches the English model to a variant, creating it if needed, and keeps a
backup of the E7c config.

    python scripts/25_phone_config.py --en int8emb
Then: python scripts/20_web_golden.py && python scripts/23_phone_bundle.py && python scripts/24_phone_leak_set.py
"""
import argparse, json, os, pathlib, shutil
ROOT = pathlib.Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument("--assets", default=os.environ.get("ASSETS", "mobile/assets"))
ap.add_argument("--en", default="int8emb")
ap.add_argument("--bn", default=None)
a = ap.parse_args()
A = ROOT / a.assets
cfg_p = A / "pipeline_config.json"
cfg = json.load(open(cfg_p))
backup = A / "pipeline_config_e7c.json"
if not backup.exists():
    shutil.copy2(cfg_p, backup); print("backup:", backup)

RECIPES = {"int8emb": dict(op_types_to_quantize=["Gather"])}
for lg, v in (("en", a.en), ("bn", a.bn)):
    if not v:
        continue
    out = A / f"pii_{lg}" / f"model_{v}.onnx"
    if not out.exists():
        if v not in RECIPES:
            raise SystemExit(f"{out} missing and no recipe for {v}")
        from onnxruntime.quantization import QuantType, quantize_dynamic
        quantize_dynamic(str(A / f"pii_{lg}" / "model_fp32.onnx"), str(out), weight_type=QuantType.QInt8, **RECIPES[v])
        print("made", out)
    cfg["pii_variant"][lg] = v

for lg in ("bn", "en"):
    sizes = {p.stem[6:]: round(p.stat().st_size / 2**20, 1) for p in sorted((A / f"pii_{lg}").glob("model_*.onnx"))}
    print(f"pii_{lg} variants (MB):", sizes)
mb = sum((A / f"pii_{lg}" / f"model_{cfg['pii_variant'][lg]}.onnx").stat().st_size for lg in ("bn", "en")) / 2**20
cfg["pii_mb"] = round(mb, 1)
cfg["chosen_on"] = (cfg.get("chosen_on", "") + f"; E7e: en={cfg['pii_variant']['en']} so phone (ARM) = server (no INT8 MatMul)").strip("; ")
json.dump(cfg, open(cfg_p, "w"), indent=1)
print("phone config:", cfg)
