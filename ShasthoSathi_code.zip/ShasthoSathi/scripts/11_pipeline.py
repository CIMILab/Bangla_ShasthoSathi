"""Run the full on-device pipeline on one report or on held-out demo reports.

    python scripts/11_pipeline.py --text-file my_report.txt --lang bn
    python scripts/11_pipeline.py --demo 8 --openmed --protect-model runs/banglishbert-full-s42/model \
        --llm Qwen/Qwen3-1.7B --device cuda          # writes results/demo/*.json (used by the demo app)
"""
import argparse, json, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from shastho.pipeline import Pipeline

ap = argparse.ArgumentParser()
ap.add_argument("--text-file")
ap.add_argument("--lang", choices=["bn", "en"], default="bn")
ap.add_argument("--demo", type=int, default=0, help="run N held-out synthetic reports in both languages")
ap.add_argument("--data", default="data/synthetic/synth_heldout.jsonl")
ap.add_argument("--out-dir", default="results/demo")
ap.add_argument("--device", default="cpu")
ap.add_argument("--openmed", action="store_true")
ap.add_argument("--protect-model", default=None)
ap.add_argument("--llm", default=None, help="English explainer, e.g. Qwen/Qwen3-1.7B")
a = ap.parse_args()

p = Pipeline(a.device, openmed=a.openmed, protect_model=a.protect_model, llm=a.llm)
if a.text_file:
    print(json.dumps(p.run(open(a.text_file, encoding="utf-8").read(), a.lang), ensure_ascii=False, indent=1))
if a.demo:
    out = pathlib.Path(a.out_dir); out.mkdir(parents=True, exist_ok=True)
    docs = [json.loads(l) for l in open(a.data, encoding="utf-8")]
    docs = [d for d in docs if d["labs"]][: a.demo]
    bundle = []
    for d in docs:
        rec = {"doc_id": d["doc_id"], "original_text": d["text"],
               "bn": p.run(d["text"], "bn"), "en": p.run(d["text"], "en")}
        bundle.append(rec)
        print(d["doc_id"], "| removed:", rec["bn"]["personal_details_removed"], "| abnormal:", rec["bn"]["abnormal"],
              "| EN source:", rec["en"]["explanation"]["source"])
    json.dump(bundle, open(out / "demo_bundle.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("wrote", out / "demo_bundle.json")
