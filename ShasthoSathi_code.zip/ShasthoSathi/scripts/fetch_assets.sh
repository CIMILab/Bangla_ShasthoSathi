#!/usr/bin/env bash
# Downloads the third-party files that are NOT stored in this repository:
#   1. Tesseract OCR language data (tessdata_fast: ben, eng) for the mobile app and the web app
#   2. Browser runtime libraries for the web app (onnxruntime-web, tesseract.js, tokenizers, Noto Sans Bengali)
# Model weights are never stored here: see "Models" in README.md.
#
#   bash scripts/fetch_assets.sh            # from the repository root; needs curl, and npm for step 2
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
TESS="$ROOT/mobile/android/app/src/main/assets/tessdata"
mkdir -p "$TESS"
for lang in ben eng; do
  if [ ! -s "$TESS/$lang.traineddata" ]; then
    echo "download tessdata_fast/$lang.traineddata"
    curl -fsSL -o "$TESS/$lang.traineddata" "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$lang.traineddata"
  fi
done
# expected: ben 4ded8631c91f5d70b5c01ab4d5a671c4, eng d1be414fbb296b3ad777bfca655e194e
command -v md5sum >/dev/null && md5sum "$TESS"/*.traineddata

if command -v npm >/dev/null; then
  cd "$ROOT/web" && npm install --no-audit --no-fund && npm run vendor
else
  echo "npm not found: skipped the web app libraries (install Node.js 18+, then: cd web && npm install && npm run vendor)"
fi
echo "done"
