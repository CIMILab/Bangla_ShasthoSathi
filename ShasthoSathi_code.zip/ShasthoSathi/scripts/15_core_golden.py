"""Golden files for the app's Kotlin core (mobile/android/core): the Python reference decides every answer.

Runs without models, so it works anywhere. Writes to mobile/android/core/src/test/resources/golden/:
  core_golden.jsonl    per text: rule spans (v1, v2), lab rows, parsed labs, rules-only redaction, templates, numbers
                       (held-out + dev synthetic reports, Bangla-HealthNER posts, hand-written edge cases)
  gate_golden.jsonl    LLM-style texts (faithful, extra number, bullets, missing test, Bengali) + the gate's decision
  tagger_golden.jsonl  windowing + word aggregation of the model wrapper with a fake model (checks the Kotlin port)
  group_golden.jsonl   entity grouping / subtract / trim on random inputs

    python scripts/15_core_golden.py
"""
import json, math, pathlib, random, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
import numpy as np
from shastho.explain import facts, gate, template
from shastho.mobile_ref import MobilePipeline, OnnxWordTagger, group, route
from shastho.pii_rules import rule_spans
from shastho.pipeline import Pipeline, _merge, _trim
from shastho.protect import subtract
from shastho.rules import numbers_in, parse_lab_lines

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / "mobile/android/core/src/test/resources/golden"; OUT.mkdir(parents=True, exist_ok=True)
load = lambda p: [json.loads(l) for l in open(p, encoding="utf-8")]

texts = []
for name, p in (("heldout", "data/synthetic/synth_heldout.jsonl"), ("dev", "data/synthetic/synth_v1.jsonl")):
    for d in load(ROOT / p)[:300]:
        texts.append((f"{name}:{d['doc_id']}", d["text"]))
hn = ROOT / "data/raw/Bangla-HealthNER/Dataset/test.json"
if hn.exists():
    for i, row in enumerate(json.load(open(hn, encoding="utf-8"))[:300]):
        texts.append((f"hn:{i}", " ".join(row["text"].split())))
EDGE = [
    "Patient: Rahim Uddin   Age: 45 M\r\nHaemoglobin   ১০.২ g/dL   ১২.০-১৫.৫\r\nTSH 7.1 mIU/L < 4.5\nVitamin D (25-OH) 21.9 ng/mL > 30",
    "রোগীর নাম: করিম মিয়া, বয়স ৬০\nতারিখ: ০৩/১১/২০২৫\nমোবাইল: ০১৭১২-৩৪৫৬৭৮\nচিকিৎসক: ডাঃ রফিকুল ইসলাম\nনাপা ৫০০ ১+০+১ খাবার পরে ৭ দিন",
    "Dr. A. K. Azad, MBBS\nSGPT (ALT)   1 U/L   7-45\nS. Creatinine   1,20 mg/dL   0.60-1.10\nHbA1c 7.4 % 4.0 - 5.6",
    "Seen on 12 March 2025 by Dr. Nasrin Akter at Surma Diagnostic Center, Zindabazar, Sylhet. NID 1234567890123.",
    "", "   \n\n", "Glucose 5 mmol/L", "Name: x", "A 45-year-old woman second line with nbsp 3.9-6.1",
]
texts += [(f"edge:{i}", t) for i, t in enumerate(EDGE)]

rules_only = MobilePipeline(use_models=False, rules_v2=True, assets="/nonexistent")
with open(OUT / "core_golden.jsonl", "w", encoding="utf-8") as f:
    for tid, t in texts:
        labs = [l.to_dict() for l in parse_lab_lines(t)]
        red, merged = rules_only.privacy(t)
        f.write(json.dumps({
            "id": tid, "text": t,
            "rules_v1": [[s, e, lab] for s, e, lab, _ in rule_spans(t, False)],
            "rules_v2": [[s, e, lab] for s, e, lab, _ in rule_spans(t, True)],
            "labs": labs, "lab_rows": [list(x) for x in Pipeline.lab_rows(t)],
            "merged_v2": [list(m) for m in merged], "redacted_v2": red,
            "template_bn": template(labs, "bn"), "template_en": template(labs, "en"), "facts": facts(labs),
            "numbers": numbers_in(t), "route": route(t),
        }, ensure_ascii=False) + "\n")

# ---------------------------------------------------------------- gate
r = random.Random(5)
with open(OUT / "gate_golden.jsonl", "w", encoding="utf-8") as f:
    n = 0
    for tid, t in texts:
        labs = [l.to_dict() for l in parse_lab_lines(t)]
        if not labs:
            continue
        base = template(labs, "en")
        variants = {"faithful": base, "bullets": "\n".join(f"- **{x}**" for x in base.split("\n")),
                    "numbered": "\n".join(f"{i+1}. {x}" for i, x in enumerate(base.split("\n"))),
                    "extra_number": base + "\nTake 2 tablets for 14 days.",
                    "missing_test": "\n".join(base.split("\n")[1:]),
                    "bengali": template(labs, "bn")}
        for k, v in variants.items():
            g = gate(v, labs, "en" if k != "bengali" else "bn")
            f.write(json.dumps({"id": f"{tid}|{k}", "labs": labs, "lang": "bn" if k == "bengali" else "en", "text": v,
                                "source": g["source"], "out": g["text"], "blocked": g["blocked_numbers"],
                                "missing": g.get("missing_tests", [])}, ensure_ascii=False) + "\n")
        n += 1
        if n >= 120:
            break

# ---------------------------------------------------------------- model wrapper with a fake model
LABELS = ["O", "B-NAME", "I-NAME", "B-DATE", "I-DATE"]


class FakeSess:   # logits depend on token id and position in the window, like a real model's would
    def run(self, _, feed):
        ids = feed["input_ids"][0]
        z = np.array([[math.sin(0.37 * t + 1.3 * k) * 3 + math.cos(0.11 * j) for k in range(len(LABELS))]
                      for j, t in enumerate(ids)], dtype=np.float32)
        return [z[None]]


def fake_tagger(L, stride):
    t = OnnxWordTagger.__new__(OnnxWordTagger)
    t.labels, t.cls, t.sep, t.L, t.stride, t.inputs, t.sess = LABELS, 1, 2, L - 2, stride, {"input_ids"}, FakeSess()
    t.word_pieces = lambda words: (sum([[3 + (ord(c) % 50) for c in w[:3]] for w in words], []),
                                   sum([[i] * len(w[:3]) for i, w in enumerate(words)], []))
    return t


with open(OUT / "tagger_golden.jsonl", "w", encoding="utf-8") as f:
    for k, (tid, t) in enumerate(texts[:40] + texts[-9:]):
        words = t.split()
        for L, stride in ((256, 64), (10, 3)):
            tg = fake_tagger(L, stride)
            out = {m: tg.word_labels_all(words, (m,))[m] for m in ("first", "mean", "max")}
            f.write(json.dumps({"id": tid, "words": words, "max_len": L, "stride": stride, "labels": LABELS,
                                **{m: [[a, b] for a, b in v] for m, v in out.items()}}, ensure_ascii=False) + "\n")

# ---------------------------------------------------------------- grouping, subtract, trim
r = random.Random(9)
with open(OUT / "group_golden.jsonl", "w", encoding="utf-8") as f:
    for i in range(300):
        n = r.randint(0, 12); pos, spans = 0, []
        for _ in range(n):
            pos += r.randint(1, 3); w = r.randint(1, 6); spans.append((pos, pos + w)); pos += w
        labs = [(r.choice(["O", "B-NAME", "I-NAME", "NAME", "B-DATE", "I-DATE", "Medicine", "B-Dosage"]),
                 round(r.random(), 3)) for _ in spans]
        th, types = r.choice([0.0, 0.1, 0.5]), r.choice([None, ["NAME"], ["Medicine", "Dosage"]])
        holes = [(a, a + r.randint(0, 5)) for a in (r.randint(0, pos + 2) for _ in range(r.randint(0, 3)))]
        text = "".join(r.choice("ab ,.:-।কখ\n") for _ in range(pos + 6))
        g = group(spans, labs, set(types) if types else None, th)
        f.write(json.dumps({"spans": spans, "labels": labs, "threshold": th, "types": types,
                            "group": [[s, e, t, sc] for s, e, t, sc in g], "holes": holes,
                            "subtract": [list(x) for x in subtract(spans, holes)], "text": text,
                            "trim": [list(x) for x in _trim(text, spans)],
                            "merge": [list(x) for x in _merge([(s, e, l[0]) for (s, e), l in zip(spans, labs)])]},
                           ensure_ascii=False) + "\n")
print("wrote", *sorted(p.name for p in OUT.iterdir()), "to", OUT, f"({len(texts)} texts)")
