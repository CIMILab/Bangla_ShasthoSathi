"""Golden files that let the WEB app check the real ONNX models against the Python reference (mobile_ref.py).
For each model folder in mobile/assets (ner, pii_bn, pii_en) writes:
  tok_golden.json   : 3,000 words -> token ids from the Python `tokenizers` library (the browser uses tokenizers.js)
  model_golden.json : 40 texts -> word labels + scores from OnnxWordTagger (the browser uses ONNX Runtime Web)
The web app's Settings page compares them when the models are loaded ("Checks against the Python reference").

    python scripts/20_web_golden.py              # CPU, ~2 min
"""
import json, pathlib, random, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from shastho.mobile_ref import OnnxWordTagger

import os
A = pathlib.Path(os.environ.get("ASSETS", ROOT / "mobile/assets"))
cfg = json.load(open(A / "pipeline_config.json")) if (A / "pipeline_config.json").exists() else \
      json.load(open(ROOT / "mobile/android/app/src/main/assets/pipeline_config.json"))
pv = cfg["pii_variant"] if isinstance(cfg["pii_variant"], dict) else {"bn": cfg["pii_variant"], "en": cfg["pii_variant"]}
variant = {"ner": cfg.get("ner_variant", "int8"), "pii_bn": pv["bn"], "pii_en": pv["en"]}

# texts: synthetic reports (golden), Bangla-HealthNER posts, and edge cases
# Any report texts will do (the golden files carry their own words); use the first source that exists.
CANDIDATES = [ROOT / "mobile/android/core/src/test/resources/golden/core_golden.jsonl",   # scripts/15_core_golden.py
              ROOT / "mobile/golden/golden.jsonl",                                       # scripts/13_mobile_golden.py
              *sorted((ROOT / "data").glob("synthetic*/*.jsonl")), *sorted((ROOT / "data").glob("**/heldout*.jsonl"))]
G = next((c for c in CANDIDATES if c.exists()), None)
if G is None:
    raise SystemExit("no report texts found; run  python scripts/15_core_golden.py  first")
texts = []
for l in open(G, encoding="utf-8"):
    if l.strip():
        row = json.loads(l); t = row.get("text") or row.get("report") or row.get("source_text")
        if isinstance(t, str) and t.strip():
            texts.append(t)
print(f"texts: {len(texts)} from {G.relative_to(ROOT)}")
if len(texts) < 40:
    raise SystemExit("fewer than 40 texts; run  python scripts/15_core_golden.py  first")
rng = random.Random(0)
sample = rng.sample(texts, 40)
words = sorted({w for t in texts for w in t.split()})
rng.shuffle(words)
words = words[:3000] + ["", "x10^9/L", "১২.৫", "ডা.", "Dr.", "Napa500", "1+0+1", "০+১+০", "(25-OH)", "ঠিকানা:", "émigré", "ক্ষ্‌", "‌"]

for name in ("ner", "pii_bn", "pii_en"):
    d = A / name
    if not (d / f"model_{variant[name]}.onnx").exists():
        print("skip", name, "(no", f"model_{variant[name]}.onnx)"); continue
    tg = OnnxWordTagger(d, threads=4, variant=variant[name])
    tok = [{"word": w, "ids": tg.tok.encode(w, add_special_tokens=False).ids} for w in words if w]
    json.dump(tok, open(d / "tok_golden.json", "w", encoding="utf-8"), ensure_ascii=False)
    mode = "first" if name == "ner" else cfg["agg"]
    gold = []
    for t in sample:
        ws = t.split()
        gold.append({"words": ws, mode: [[lab, round(float(s), 6)] for lab, s in tg.word_labels(ws, mode)]})
    json.dump(gold, open(d / "model_golden.json", "w", encoding="utf-8"), ensure_ascii=False)
    print(f"{name:7s} variant={variant[name]:11s} tok_golden={len(tok)} words  model_golden={len(gold)} texts ({mode})")
print("done. Copy the whole mobile/assets folder to your laptop and load it in the web app: Settings -> Stronger privacy.")
