"""E8 test set: 30 held-out synthetic reports to PRINT and photograph with the phone.

Writes
  mobile/android/app/src/main/assets/eval_set.json   ground truth the app compares each photo with (by E8 id)
  mobile/eval/E8_printable.pdf                       one report per A4 page, id in the corner (print this)
  mobile/eval/pages/E8-xx.png                        the same pages as images (desktop OCR proxy, 17_ocr_proxy.py)

Only invented people (held-out vocabulary), so photos can be taken and shared without any privacy issue.

    python scripts/16_ocr_eval_set.py --fonts <dir with the two woff2 fonts>
"""
import argparse, base64, html, json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

ap = argparse.ArgumentParser()
ap.add_argument("--fonts", required=True, help="folder with noto-sans-mono-latin-400-normal.woff2 and noto-sans-bengali-bengali-400-normal.woff2")
ap.add_argument("--data", default=str(ROOT / "data/synthetic/synth_heldout.jsonl"))
a = ap.parse_args()

docs = [json.loads(l) for l in open(a.data, encoding="utf-8")]
samples = {s["id"] for s in json.load(open(ROOT / "mobile/android/app/src/main/assets/samples.json", encoding="utf-8"))["samples"]}
pool = [d for d in docs if d["doc_id"] not in samples]
pick = ([d for d in pool if d["doc_type"] == "lab_report"][:15] + [d for d in pool if d["doc_type"] == "prescription" and d["lang"] == "mixed"][:8]
        + [d for d in pool if d["doc_type"] == "bn_note"][:7])
items = []
for i, d in enumerate(pick, start=1):
    items.append({"id": f"E8-{i:02d}", "doc_id": d["doc_id"], "type": d["doc_type"], "lang": d["lang"], "text": d["text"],
                  "pii": [p["text"] for p in d["pii"]],
                  "labs": [{k: l[k] for k in ("name", "value", "unit", "low", "high", "flag")} for l in d["labs"]]})
out = ROOT / "mobile/android/app/src/main/assets/eval_set.json"
json.dump({"note": "E8 OCR test set: synthetic held-out reports (invented people). Print mobile/eval/E8_printable.pdf.",
           "items": items}, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

F = pathlib.Path(a.fonts)
b64 = lambda p: base64.b64encode(p.read_bytes()).decode()
mono = next(F.rglob("noto-sans-mono-latin-400-normal.woff2")); beng = next(F.rglob("noto-sans-bengali-bengali-400-normal.woff2"))
css = f"""@font-face {{ font-family: Mono; src: url(data:font/woff2;base64,{b64(mono)}); }}
@font-face {{ font-family: Beng; src: url(data:font/woff2;base64,{b64(beng)}); }}
@page {{ size: A4; margin: 22mm 18mm; }}
body {{ margin: 0; }}
.page {{ page-break-after: always; position: relative; height: 250mm; }}
pre {{ font-family: Mono, Beng; font-size: 12.5pt; line-height: 1.55; white-space: pre-wrap; margin: 0; color: #111; }}
.id {{ position: absolute; right: 0; bottom: 0; font: 9pt Mono; color: #888; }}"""
pages = "".join(f'<div class="page"><pre>{html.escape(it["text"])}</pre><div class="id">{it["id"]}</div></div>' for it in items)
doc = f"<!doctype html><html><head><meta charset='utf-8'><style>{css}</style></head><body>{pages}</body></html>"

E = ROOT / "mobile/eval"; (E / "pages").mkdir(parents=True, exist_ok=True)
(E / "E8_printable.html").write_text(doc, encoding="utf-8")
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    pg.set_content(doc); pg.wait_for_timeout(500)
    pg.pdf(path=str(E / "E8_printable.pdf"), format="A4", print_background=True)
    # page images at ~200 dpi for the desktop OCR proxy
    pg2 = b.new_page(viewport={"width": 1240, "height": 1754}, device_scale_factor=1)
    for it in items:
        one = (f"<!doctype html><html><head><meta charset='utf-8'><style>{css} body{{margin:0;padding:150px 120px;background:#fff}}"
               f" pre{{font-size:26px}}</style></head><body><pre>{html.escape(it['text'])}</pre></body></html>")
        pg2.set_content(one); pg2.wait_for_timeout(200)
        pg2.screenshot(path=str(E / "pages" / f"{it['id']}.png"), full_page=False)
    b.close()
print(f"{len(items)} reports -> {out.relative_to(ROOT)}, mobile/eval/E8_printable.pdf, mobile/eval/pages/*.png")
