"""E8 desktop proxy: Tesseract (the same 'fast' ben/eng models the app ships) on the printable pages, clean and with
simulated photo problems. This is NOT the phone result (that comes from real photos on the S23); it checks the
pipeline end to end, picks Tesseract settings, and gives Kotlin golden cases for the E8 metrics.

    python scripts/17_ocr_proxy.py
"""
import collections, json, pathlib, sys, time
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import numpy as np
import pytesseract
from PIL import Image, ImageEnhance, ImageFilter
from shastho.mobile_ref import MobilePipeline
from shastho.ocr_eval import cer, lab_scores, leak_scores

TESS = str(ROOT / "mobile/android/app/src/main/assets/tessdata")
items = json.load(open(ROOT / "mobile/android/app/src/main/assets/eval_set.json", encoding="utf-8"))["items"]
rules = MobilePipeline(use_models=False, rules_v2=True, assets="/nonexistent")


def cond(im, c, rng):
    if c == "clean":
        return im
    if c == "tilt3":
        return im.rotate(3, expand=True, fillcolor="white", resample=Image.BICUBIC)
    if c == "dim_blur":
        im = ImageEnhance.Brightness(im).enhance(0.55).filter(ImageFilter.GaussianBlur(1.4))
        a = np.asarray(im).astype(np.float32) + rng.normal(0, 10, (im.height, im.width, 3))
        return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
    if c == "small":                                   # far away / low resolution
        return im.resize((im.width // 2, im.height // 2), Image.BILINEAR)
    raise ValueError(c)


rows, golden = [], []
rng = np.random.default_rng(0)
CONDS = ["clean", "tilt3", "dim_blur", "small"]
SETTINGS = [("ben+eng", 6), ("eng", 6)]
for it in items:
    base = Image.open(ROOT / f"mobile/eval/pages/{it['id']}.png").convert("RGB")
    print(it["id"], flush=True)
    for c in CONDS:
        im = cond(base, c, rng)
        for lang, psm in SETTINGS:
            t0 = time.perf_counter()
            try:      # a noisy photo can make Tesseract crawl; the app needs a time limit too
                hyp = pytesseract.image_to_string(im, lang=lang, config=f"--tessdata-dir {TESS} --psm {psm}", timeout=45)
            except RuntimeError:
                hyp = ""
            dt = time.perf_counter() - t0
            red, _ = rules.privacy(hyp)
            r = {"id": it["id"], "type": it["type"], "cond": c, "lang": lang, "psm": psm, "sec": dt,
                 "cer": cer(it["text"], hyp), **lab_scores(it["labs"], hyp), **leak_scores(it["pii"], red)}
            rows.append(r)
            if len(golden) < 400:
                golden.append({"ref": it["text"], "hyp": hyp, "labs": it["labs"], "pii_items": it["pii"], "redacted": red,
                               "cer": r["cer"], **lab_scores(it["labs"], hyp), **leak_scores(it["pii"], red)})

agg = collections.defaultdict(lambda: collections.Counter())
for r in rows:
    for k in (("all", r["cond"], r["lang"], r["psm"]), (r["type"], r["cond"], r["lang"], r["psm"])):
        a = agg[k]; a["n"] += 1; a["cer"] += r["cer"]; a["sec"] += r["sec"]
        for f in ("gold_rows", "rows_exact", "flags_correct", "spurious", "pii", "leaked"):
            a[f] += r[f]
print(f"{'docs':12s} {'condition':9s} {'model':8s} psm {'CER':>6s} {'rows ok':>8s} {'flags ok':>8s} {'spur':>5s} {'leak':>6s} {'s/page':>6s}")
for k in sorted(agg):
    a = agg[k]
    f = lambda x, y: f"{100 * a[x] / a[y]:7.1f}%" if a[y] else "     - "
    print(f"{k[0]:12s} {k[1]:9s} {k[2]:8s} {k[3]:3d} {a['cer'] / a['n']:6.3f} {f('rows_exact', 'gold_rows')} "
          f"{f('flags_correct', 'gold_rows')} {a['spurious']:5d} {f('leaked', 'pii')} {a['sec'] / a['n']:6.2f}")
(ROOT / "results").mkdir(exist_ok=True)
json.dump(rows, open(ROOT / "results/e8_ocr_proxy.json", "w"), ensure_ascii=False, indent=1)
G = ROOT / "mobile/android/core/src/test/resources/golden/ocr_golden.jsonl"
with open(G, "w", encoding="utf-8") as f:
    for g in golden:
        f.write(json.dumps(g, ensure_ascii=False) + "\n")
print("wrote results/e8_ocr_proxy.json and", G.relative_to(ROOT))
