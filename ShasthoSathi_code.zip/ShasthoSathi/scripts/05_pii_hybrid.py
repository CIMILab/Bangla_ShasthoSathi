"""Experiment 3: OpenMed + deterministic rules (hybrid) for PII removal.

Design (fixes the E1 caveat that the threshold was chosen on the test data):
  * dev   = synthetic v1 (dev vocabulary)               -> choose the confidence threshold
  * test  = synthetic held-out (new names/areas/clinics) -> report
  * real  = fake PII injected into REAL text: 200 PMC-Patients summaries (English)
            + 200 Bangla-HealthNER test posts (Bangla), held-out vocabulary -> report
Modes: model (OpenMed, routed by script), rules (src/shastho/pii_rules.py), hybrid (union).
Threshold rule: lowest dev leak with clinical over-redaction <= --max-over (default 0.10).
E3b (--protect-model): the fine-tuned HealthNER tagger (E4) marks Medicine/Dosage spans, which are cut out
of the MODEL's PII spans (rule spans are kept): modes model+protect, hybrid+protect.

    python scripts/05_pii_hybrid.py --device cuda
    python scripts/05_pii_hybrid.py --device cuda --protect-model runs/banglishbert-full-s42/model --out results/exp3b_protect.json
"""
import argparse, collections, json, pathlib, random, statistics, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from shastho.metrics import pii_leakage, over_redaction, bootstrap_ci, bio_to_spans
from shastho.pii_rules import rule_spans
from shastho.protect import ClinicalProtector, subtract
from shastho.synth import generate, inject_pii, use_vocab

ap = argparse.ArgumentParser()
ap.add_argument("--dev", default="data/synthetic/synth_v1.jsonl")
ap.add_argument("--test", default="data/synthetic/synth_heldout.jsonl")
ap.add_argument("--pmc", default="data/raw/pmc_patients_sample2000.jsonl")
ap.add_argument("--healthner", default="data/raw/Bangla-HealthNER/Dataset/test.json")
ap.add_argument("--n-real", type=int, default=200, help="docs per real-text source")
ap.add_argument("--thresholds", nargs="+", type=float, default=[0.3, 0.4, 0.5, 0.6, 0.7])
ap.add_argument("--max-over", type=float, default=0.10)
ap.add_argument("--device", default="cpu")
ap.add_argument("--no-model", action="store_true", help="rules only (debug without OpenMed)")
ap.add_argument("--protect-model", default=None, help="E3b: fine-tuned HealthNER model dir (runs/<tag>/model)")
ap.add_argument("--protect-types", nargs="+", default=["Medicine", "Dosage"])
ap.add_argument("--out", default="results/exp3_pii_hybrid.json")
a = ap.parse_args()

load = lambda p: [json.loads(l) for l in open(p, encoding="utf-8")]

# ---------------------------------------------------------------- data
if not pathlib.Path(a.test).exists():
    from shastho.synth import write_jsonl
    write_jsonl(generate(seed=7, vocab="heldout"), a.test)
sets = {"dev": load(a.dev), "test": load(a.test)}

real, r = [], random.Random(11)
use_vocab("heldout")
if pathlib.Path(a.pmc).exists():
    pmc = load(a.pmc)
    for i, row in enumerate(r.sample(pmc, min(a.n_real, len(pmc)))):
        body = (row.get("patient") or row.get("text") or "")[:1500]
        d = inject_pii(body, "en", r, f"pmc_{i:04d}").to_dict()
        d["protected"] = []
        real.append(d)
if pathlib.Path(a.healthner).exists():
    hn = json.load(open(a.healthner, encoding="utf-8"))
    for i, row in enumerate(r.sample(hn, min(a.n_real, len(hn)))):
        toks = row["text"].split(); body = " ".join(toks)
        d = inject_pii(body, "bn", r, f"hn_{i:04d}").to_dict()
        off = d["text"].index(body)
        d["protected"] = [(s + off, e + off) for s, e, lab in bio_to_spans(toks, row["labels"])
                          if lab in ("Medicine", "Dosage")]
        real.append(d)
use_vocab("dev")
if real:
    sets["real"] = real
print({k: len(v) for k, v in sets.items()}, flush=True)


def protected(d):
    if "protected" in d:
        return [tuple(x) for x in d["protected"]]
    return [tuple(m["brand_span"]) for m in d.get("meds", [])] + [tuple(l["value_span"]) for l in d.get("labs", [])]


# ---------------------------------------------------------------- predictions (cache model output once)
runner = None
if not a.no_model:
    from shastho.openmed_adapter import OpenMedRunner
    runner = OpenMedRunner(a.device)
    runner.pii_auto("warm up Rahima Begum 01712-345678", 0.5)
    runner.pii_auto("রহিমা বেগম ০১৭১২-৩৪৫৬৭৮", 0.5)

prot = ClinicalProtector(a.protect_model, a.device, a.protect_types) if a.protect_model else None
pred = {}  # (set, doc_id, mode, th) -> [(s,e)]
kept = {}  # (set, doc_id) -> protected spans predicted by the tagger
times = collections.defaultdict(list)
for name, docs in sets.items():
    for d in docs:
        rs = [(s, e) for s, e, *_ in rule_spans(d["text"])]
        t0 = time.perf_counter(); rule_spans(d["text"]); times["rules"].append(time.perf_counter() - t0)
        if prot:
            t0 = time.perf_counter(); kept[(name, d["doc_id"])] = prot.spans(d["text"])
            times["protect_tagger"].append(time.perf_counter() - t0)
        for th in a.thresholds:
            ms = []
            if runner:
                spans, dt, _ = runner.pii_auto(d["text"], th, "script")
                ms = [(s, e) for s, e, *_ in spans]
                times[f"model@{th}"].append(dt)
            pred[(name, d["doc_id"], "model", th)] = ms
            pred[(name, d["doc_id"], "rules", th)] = rs
            pred[(name, d["doc_id"], "hybrid", th)] = ms + rs
            if prot:
                ms_p = subtract(ms, kept[(name, d["doc_id"])])
                pred[(name, d["doc_id"], "model+protect", th)] = ms_p
                pred[(name, d["doc_id"], "hybrid+protect", th)] = ms_p + rs
    print("predicted", name, flush=True)


def evaluate(docs, name, mode, th):
    leaks, leaks_nofac, anyleak, per_type = [], [], [], collections.defaultdict(lambda: [0, 0])
    over = [0, 0]
    for d in docs:
        p = pred[(name, d["doc_id"], mode, th)]
        m = pii_leakage(d["pii"], p, d["text"])
        m2 = pii_leakage([g for g in d["pii"] if g["type"] != "FACILITY"], p, d["text"])
        leaks.append(m["span_leak_rate"]); leaks_nofac.append(m2["span_leak_rate"]); anyleak.append(m["doc_any_leak"])
        for t, v in m["per_type"].items():
            per_type[t][0] += v["leaked"]; per_type[t][1] += v["total"]
        o = over_redaction(protected(d), p); over[0] += o["redacted"]; over[1] += o["protected"]
    mean, lo, hi = bootstrap_ci(leaks)
    return {"span_leak_rate": mean, "ci95": [lo, hi], "leak_without_facility": statistics.mean(leaks_nofac),
            "docs_with_any_leak": statistics.mean(anyleak),
            "clinical_over_redaction": over[0] / over[1] if over[1] else None,
            "per_type_leak": {t: v[0] / v[1] for t, v in per_type.items()}, "_leaks": leaks, "_any": anyleak}


modes = ["rules"] + ([] if a.no_model else ["model", "hybrid"]) + (["model+protect", "hybrid+protect"] if prot and not a.no_model else [])
res = {n: {f"{m}@{th}": evaluate(sets[n], n, m, th) for m in modes for th in a.thresholds} for n in sets}

# ---------------------------------------------------------------- choose threshold on dev only
chosen = {}
for m in modes:
    ok = [(res["dev"][f"{m}@{th}"]["span_leak_rate"], th) for th in a.thresholds
          if (res["dev"][f"{m}@{th}"]["clinical_over_redaction"] or 0) <= a.max_over]
    chosen[m] = min(ok)[1] if ok else max(a.thresholds)


def paired(n, k1, k2, B=2000, seed=0):
    """Paired bootstrap CI for leak(k2) - leak(k1), and McNemar counts on 'any leak'."""
    x, y = res[n][k1]["_leaks"], res[n][k2]["_leaks"]
    rr = random.Random(seed); idx = range(len(x))
    diffs = sorted(statistics.mean(y[i] - x[i] for i in (rr.choice(idx) for _ in idx)) for _ in range(B))
    a1, a2 = res[n][k1]["_any"], res[n][k2]["_any"]
    b = sum(1 for u, v in zip(a1, a2) if u and not v); c = sum(1 for u, v in zip(a1, a2) if v and not u)
    return {"diff": statistics.mean(y) - statistics.mean(x), "ci95": [diffs[int(.025 * B)], diffs[int(.975 * B) - 1]],
            "mcnemar_b_only_first_leaks": b, "mcnemar_c_only_second_leaks": c}


summary = {"chosen_threshold": chosen, "report": {}}
for n in [s for s in ("test", "real") if s in sets]:
    summary["report"][n] = {m: {k: v for k, v in res[n][f"{m}@{chosen[m]}"].items() if not k.startswith("_")}
                            for m in modes}
    if "hybrid" in modes:
        summary["report"][n]["hybrid_minus_model"] = paired(n, f"model@{chosen['model']}", f"hybrid@{chosen['hybrid']}")
    if "hybrid+protect" in modes:   # same threshold as hybrid, so the only change is the protection step
        summary["report"][n]["protect_minus_hybrid"] = paired(n, f"hybrid@{chosen['hybrid']}", f"hybrid+protect@{chosen['hybrid']}")
        summary["report"][n]["hybrid+protect@hybrid_threshold"] = {
            k: v for k, v in res[n][f"hybrid+protect@{chosen['hybrid']}"].items() if not k.startswith("_")}
summary["median_ms_per_doc"] = {k: 1000 * statistics.median(v) for k, v in times.items()}

for n in summary["report"]:
    print(f"\n== {n}  (thresholds chosen on dev: {chosen})")
    for m in modes:
        v = summary["report"][n][m]
        print(f"  {m:14s} leak={v['span_leak_rate']:.3f} [{v['ci95'][0]:.3f},{v['ci95'][1]:.3f}]  "
              f"no-facility={v['leak_without_facility']:.3f}  anyleak={v['docs_with_any_leak']:.2f}  "
              f"over={v['clinical_over_redaction'] if v['clinical_over_redaction'] is None else round(v['clinical_over_redaction'],3)}")
    if "hybrid_minus_model" in summary["report"][n]:
        p = summary["report"][n]["hybrid_minus_model"]
        print(f"  hybrid - model: {p['diff']:+.3f} [{p['ci95'][0]:+.3f},{p['ci95'][1]:+.3f}]  "
              f"McNemar b={p['mcnemar_b_only_first_leaks']} c={p['mcnemar_c_only_second_leaks']}")
    if "protect_minus_hybrid" in summary["report"][n]:
        p = summary["report"][n]["protect_minus_hybrid"]; v = summary["report"][n]["hybrid+protect@hybrid_threshold"]
        h = summary["report"][n]["hybrid"]
        print(f"  E3b at hybrid threshold: over-redaction {h['clinical_over_redaction'] or 0:.3f} -> {v['clinical_over_redaction'] or 0:.3f} | "
              f"leak {p['diff']:+.3f} [{p['ci95'][0]:+.3f},{p['ci95'][1]:+.3f}]  "
              f"McNemar b={p['mcnemar_b_only_first_leaks']} c={p['mcnemar_c_only_second_leaks']}")
        print(f"  per-type leak hybrid+protect: { {t: round(x, 3) for t, x in v['per_type_leak'].items()} }")

full = {n: {k: {kk: vv for kk, vv in v.items() if not kk.startswith("_")} for k, v in res[n].items()} for n in res}
pathlib.Path(a.out).parent.mkdir(parents=True, exist_ok=True)
json.dump({"args": vars(a), "sizes": {k: len(v) for k, v in sets.items()}, "summary": summary, "all": full,
           "time": time.strftime("%Y-%m-%d %H:%M")}, open(a.out, "w"), indent=1, ensure_ascii=False)
print("wrote", a.out)
