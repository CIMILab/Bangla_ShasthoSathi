"""E7b: choose the phone's privacy settings on dev data only, and measure what compression costs.

E7a: the phone version leaked more than the research pipeline (FP32 4.2%, INT8 16.5% vs 0.0%).
E7b run 1 (this script, first version) showed the real problem on the "free" set (names inside real sentences,
no field label, so rules cannot help): FP32 PII models leak 0.7% of names, plain INT8 50.7%. Two INT8 recipes
(per-channel, MatMul-only) predicted nothing at all. This version adds

  * quantization with reduce_range=True (onnxruntime's fix for 8-bit saturation on x86 CPUs without VNNI;
    the phone's ARM kernels do not have that problem, so this is also closer to what the phone computes)
  * a separate choice per language model (e.g. Bengali INT8 + English FP32), with the size cost shown
  * a free_dev set (disjoint real texts), so settings are chosen on dev + free_dev and reported on test sets
  * leak by language (PMC English vs Bangla-HealthNER) for the key rows

Sets: dev = synth_v1 (300), free_dev = 400 real texts with an unlabelled name (disjoint from the test texts),
      test = held-out synthetic (300), real = E3's real text + injected identifiers (400), free = 400 unlabelled.
Choice (model alone, rules off): lowest mean leak on dev and free_dev, with medicine/lab values hidden <= 0.10,
other text hidden <= 0.10 on both, and PII models <= --max-mb. Then the v2 header rules are added on top.

    python scripts/14_mobile_tune.py --threads 4           # model outputs are cached in results/e7b_cache.pkl
"""
import argparse, collections, itertools, json, pathlib, pickle, random, re, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("--assets", default="mobile/assets")
ap.add_argument("--dev", default="data/synthetic/synth_v1.jsonl")
ap.add_argument("--test", default="data/synthetic/synth_heldout.jsonl")
ap.add_argument("--pmc", default="data/raw/pmc_patients_sample2000.jsonl")
ap.add_argument("--healthner", default="data/raw/Bangla-HealthNER/Dataset/test.json")
ap.add_argument("--n", type=int, default=300, help="docs per synthetic set")
ap.add_argument("--n-real", type=int, default=200, help="docs per real-text source (same as E3)")
ap.add_argument("--threads", type=int, default=4)
ap.add_argument("--variants", nargs="*", default=["fp32", "int8", "int8rr", "int8pcrr", "int8emb", "int8noattn", "int8noattnrr"])
ap.add_argument("--thresholds", type=float, nargs="*", default=[0.05, 0.1, 0.2, 0.3])
ap.add_argument("--max-over", type=float, default=0.10, help="max share of medicine / lab values hidden")
ap.add_argument("--max-text-over", type=float, default=0.10, help="max share of other (non-personal) text hidden")
ap.add_argument("--max-mb", type=float, default=700,
                help="max size of the two PII models together (700 MB -> about 800 MB of assets with the tagger)")
ap.add_argument("--cache", default="results/e7b_cache.pkl")
a = ap.parse_args()

from onnxruntime.quantization import QuantType, quantize_dynamic
from shastho.metrics import _content, bio_to_spans, bootstrap_ci, over_redaction, pii_leakage
from shastho.mobile_ref import OnnxWordTagger, WORD, group, route
from shastho.pii_rules import rule_spans
from shastho.pipeline import Pipeline, _merge, _trim
from shastho.protect import subtract
from shastho.synth import _name, inject_pii, use_vocab

A = pathlib.Path(a.assets)
LANGS = ("bn", "en")
# ---------------------------------------------------------------- 1. quantization variants
RECIPES = {"int8pc": dict(per_channel=True), "int8mm": dict(per_channel=True, op_types_to_quantize=["MatMul"]),
           "int8rr": dict(reduce_range=True), "int8pcrr": dict(per_channel=True, reduce_range=True),
           # E7c: keep the sensitive parts in FP32
           "int8emb": dict(op_types_to_quantize=["Gather"]),     # only the embedding table (most of the size)
           "int8noattn": dict(), "int8noattnrr": dict(reduce_range=True)}   # attention MatMuls stay FP32


def attention_nodes(path):
    import onnx
    g = onnx.load(str(path), load_external_data=False).graph
    return [n.name for n in g.node if n.op_type == "MatMul" and "attention" in n.name.lower()]

for lg in LANGS:
    for v in a.variants:
        out = A / f"pii_{lg}" / f"model_{v}.onnx"
        if v in RECIPES and not out.exists():
            t0 = time.time()
            src = A / f"pii_{lg}" / "model_fp32.onnx"
            kw = dict(RECIPES[v])
            if "noattn" in v:
                kw["nodes_to_exclude"] = attention_nodes(src)
                print(f"pii_{lg}: keeping {len(kw['nodes_to_exclude'])} attention MatMuls in FP32", flush=True)
            quantize_dynamic(str(src), str(out), weight_type=QuantType.QInt8, **kw)
            print(f"made pii_{lg}/{out.name} ({out.stat().st_size / 2**20:.0f} MB, {time.time()-t0:.0f}s)", flush=True)
MB = {lg: {v: round((A / f"pii_{lg}" / f"model_{v}.onnx").stat().st_size / 2**20, 1) for v in a.variants} for lg in LANGS}
print("PII model sizes, MB:", MB, flush=True)

# ---------------------------------------------------------------- 2. evaluation sets
load = lambda p, n=0: [json.loads(l) for l in open(p, encoding="utf-8")][: n or None]
sets = {"dev": load(a.dev, a.n), "test": load(a.test, a.n)}
for d in sets["dev"] + sets["test"]:
    d["protected"] = [tuple(m["brand_span"]) for m in d.get("meds", [])] + [tuple(l["value_span"]) for l in d["labs"]]

EN_SUBJ = re.compile(r"\b(?:[Tt]he patient|[Aa]n? \d{1,3}[- ]year[- ]old (?:man|woman|male|female|boy|girl|patient))\b")
BN_T = ["আমার বাবা {n} অনেক দিন ধরে অসুস্থ। ", "{n} গত সপ্তাহে ডাক্তার দেখিয়েছেন। ", "আমি {n}, আমার একটা প্রশ্ন আছে। ",
        "আমার মা {n} এর জন্য পরামর্শ চাই। "]


def make_free(bodies, seed, prefix):
    """The name goes inside a sentence, never after a field label."""
    rf, out = random.Random(seed), []
    for lang, did, body, prot in bodies:
        name = _name(rf, rf.choice("MF"), lang == "bn")
        if lang == "en":
            m = EN_SUBJ.search(body)
            if m:
                text, s = body[:m.start()] + name + body[m.end():], m.start()
            else:
                text, s = f"{name} was seen in the clinic. {body}", 0
            prot2 = []                                            # PMC texts have no clinical annotation
        else:
            pre = rf.choice(BN_T).format(n=name); s = pre.index(name); text = pre + body
            prot2 = [(ps + len(pre), pe + len(pre)) for ps, pe in prot]
        assert text[s:s + len(name)] == name
        out.append({"doc_id": prefix + did, "src": did.split("_")[0], "text": text, "labs": [], "protected": prot2,
                    "pii": [{"start": s, "end": s + len(name), "type": "NAME", "text": name}]})
    return out


r = random.Random(11)                                             # seed 11 = the exact E3 real-text set
real, bodies, bodies_dev = [], [], []
use_vocab("heldout")
if pathlib.Path(a.pmc).exists():
    pmc = load(a.pmc)
    picked = r.sample(range(len(pmc)), min(a.n_real, len(pmc)))
    for i, j in enumerate(picked):
        body = (pmc[j].get("patient") or pmc[j].get("text") or "")[:1500]
        d = inject_pii(body, "en", r, f"pmc_{i:04d}").to_dict(); d["protected"] = []; d["src"] = "pmc"
        real.append(d); bodies.append(("en", f"pmc_{i:04d}", body, []))
    ps = set(picked); rest = [j for j in range(len(pmc)) if j not in ps]
    for i, j in enumerate(random.Random(12).sample(rest, min(a.n_real, len(rest)))):
        bodies_dev.append(("en", f"pmc_{i:04d}", (pmc[j].get("patient") or pmc[j].get("text") or "")[:1500], []))
if pathlib.Path(a.healthner).exists():
    hn = json.load(open(a.healthner, encoding="utf-8"))
    picked = r.sample(range(len(hn)), min(a.n_real, len(hn)))
    for i, j in enumerate(picked):
        toks = hn[j]["text"].split(); body = " ".join(toks)
        d = inject_pii(body, "bn", r, f"hn_{i:04d}").to_dict(); d["src"] = "hn"
        off = d["text"].index(body)
        prot = [(s, e) for s, e, lab in bio_to_spans(toks, hn[j]["labels"]) if lab in ("Medicine", "Dosage")]
        d["protected"] = [(s + off, e + off) for s, e in prot]
        real.append(d); bodies.append(("bn", f"hn_{i:04d}", body, prot))
    ps = set(picked); rest = [j for j in range(len(hn)) if j not in ps]
    for i, j in enumerate(random.Random(12).sample(rest, min(a.n_real, len(rest)))):
        toks = hn[j]["text"].split()
        prot = [(s, e) for s, e, lab in bio_to_spans(toks, hn[j]["labels"]) if lab in ("Medicine", "Dosage")]
        bodies_dev.append(("bn", f"hn_{i:04d}", " ".join(toks), prot))
if real:
    sets["real"] = real
    sets["free"] = make_free(bodies, 23, "free_")                 # same texts and names as run 1
    sets["free_dev"] = make_free(bodies_dev, 24, "freedev_")
use_vocab("dev")
for d in sets["dev"] + sets["test"]:
    d["src"] = d.get("lang", "?")
print({k: len(v) for k, v in sets.items()}, flush=True)

# ---------------------------------------------------------------- 3. model outputs (cached per set, doc, variant)
tagger = OnnxWordTagger(A / "ner", a.threads, "int8")
C, ms = {}, collections.defaultdict(list)
for name, docs in sets.items():
    for d in docs:
        m = list(WORD.finditer(d["text"])); words = [x.group() for x in m]; sp = [x.span() for x in m]
        gold = np.zeros(len(d["text"]), bool)
        for g in d["pii"]:
            gold[g["start"]:g["end"]] = True
        other = np.array([i for i, ch in enumerate(d["text"]) if _content(ch) and not gold[i]], dtype=int)
        C[(name, d["doc_id"])] = {"spans": sp, "pii": {}, "gold": gold, "other": other,
                                  "kept": [k[:2] for k in group(sp, tagger.word_labels(words, "first"), types={"Medicine", "Dosage"})],
                                  "lab_rows": Pipeline.lab_rows(d["text"]),
                                  "rules": {v2: [(s, e) for s, e, *_ in rule_spans(d["text"], v2)] for v2 in (False, True)}}
old = pickle.load(open(a.cache, "rb")) if pathlib.Path(a.cache).exists() else {}
for v in a.variants:
    todo = [(n, d) for n, docs in sets.items() for d in docs if (n, d["doc_id"], v) not in old]
    if todo:
        models = {lg: OnnxWordTagger(A / f"pii_{lg}", a.threads, v) for lg in LANGS}
        for n, d in todo:
            words = [d["text"][s:e] for s, e in C[(n, d["doc_id"])]["spans"]]
            t0 = time.perf_counter()
            old[(n, d["doc_id"], v)] = {lg: models[lg].word_labels_all(words) for lg in route(d["text"])}
            ms[v].append(1000 * (time.perf_counter() - t0))
        old[("ms", v)] = ms[v]
        pickle.dump(old, open(a.cache, "wb"))
    ms[v] = old.get(("ms", v), [0.0])
    for n, docs in sets.items():
        for d in docs:
            C[(n, d["doc_id"])]["pii"][v] = old[(n, d["doc_id"], v)]
    print(f"variant {v}: {len(todo)} docs run, median {np.median(ms[v]):.0f} ms/doc", flush=True)

# ---------------------------------------------------------------- 4. scoring
G = {}                                                            # memo: (set, doc, variant, lang, agg, th) -> spans


def model_spans(n, d, vb, ve, agg, th):
    c, out = C[(n, d["doc_id"])], []
    for lg, v in (("bn", vb), ("en", ve)):
        if lg in c["pii"][v]:
            k = (n, d["doc_id"], v, lg, agg, th)
            if k not in G:
                G[k] = [(s, e) for s, e, _, _ in group(c["spans"], c["pii"][v][lg][agg], threshold=th)]
            out += G[k]
    return out


def predict(n, d, key):
    vs, agg, th, rules = key.split("|")
    vb, ve = (x.split("=")[1] for x in vs.split(","))
    c = C[(n, d["doc_id"])]
    model = _trim(d["text"], subtract(model_spans(n, d, vb, ve, agg, float(th)), c["kept"] + c["lab_rows"]))
    rs = [] if rules == "none" else c["rules"][rules == "v2"]
    return rs + model


R = {}


def ev(n, key, src=None):
    k = (n, key, src)
    if k in R:
        return R[k]
    leaks, per, clin, text = [], collections.Counter(), [0, 0], [0, 0]
    for d in sets[n]:
        if src and d.get("src") != src:
            continue
        p = predict(n, d, key); c = C[(n, d["doc_id"])]
        m = pii_leakage(d["pii"], p, d["text"]); leaks.append(m["span_leak_rate"])
        for t, x in m["per_type"].items():
            per[t + "_l"] += x["leaked"]; per[t + "_n"] += x["total"]
        o = over_redaction(d["protected"], p); clin[0] += o["redacted"]; clin[1] += o["protected"]
        hid = np.zeros(len(d["text"]), bool)
        for s, e in p:
            hid[s:e] = True
        text[0] += int(hid[c["other"]].sum()) if len(c["other"]) else 0; text[1] += len(c["other"])
    mean, lo, hi = bootstrap_ci(leaks) if leaks else (None, None, None)
    R[k] = {"leak": round(mean, 4) if mean is not None else None, "ci95": [lo, hi], "n": len(leaks),
            "clin": round(clin[0] / clin[1], 4) if clin[1] else None,
            "text": round(text[0] / text[1], 4) if text[1] else None,
            "per_type": {t[:-2]: round(per[t] / per[t[:-2] + "_n"], 3) for t in per if t.endswith("_l")}}
    return R[k]


key = lambda vb, ve, agg, th, rules: f"bn={vb},en={ve}|{agg}|{th}|{rules}"
size = lambda k: MB["bn"][k.split(",")[0][3:]] + MB["en"][k.split("|")[0].split(",")[1][3:]]
sel_sets = [s for s in ("dev", "free_dev") if s in sets]
model_keys = [key(vb, ve, agg, th, "none") for vb, ve, agg, th in itertools.product(a.variants, a.variants, ("mean", "max"), a.thresholds)]
t0 = time.time()
for k in model_keys:
    for s in sel_sets:
        ev(s, k)
print(f"scored {len(model_keys)} model settings on {sel_sets} in {time.time()-t0:.0f}s", flush=True)


def ok(k):
    return all((ev(s, k)["clin"] or 0) <= a.max_over and (ev(s, k)["text"] or 0) <= a.max_text_over for s in sel_sets)


def best(filt=lambda k: True, cap=None):
    c = [(float(np.mean([ev(s, k)["leak"] for s in sel_sets])), size(k), -float(k.split("|")[2]), k)
         for k in model_keys if filt(k) and ok(k) and size(k) <= (cap or 1e9)]
    return min(c)[3] if c else None


both = lambda v: (lambda k: k.startswith(f"bn={v},en={v}|"))
chosen = best(cap=a.max_mb)
if chosen is None:
    raise SystemExit("no setting meets the limits; relax --max-text-over or --max-mb")
shipped = chosen.replace("|none", "|v2")
vs = chosen.split("|")[0]; vb, ve = (x.split("=")[1] for x in vs.split(","))
cfg = {"ner_variant": "int8", "pii_variant": {"bn": vb, "en": ve}, "agg": chosen.split("|")[1],
       "threshold": float(chosen.split("|")[2]), "rules_v2": True, "pii_mb": size(chosen),
       "chosen_on": f"{'+'.join(sel_sets)}, model alone, clinical hidden <= {a.max_over}, other text hidden <= "
                    f"{a.max_text_over}, PII models <= {a.max_mb} MB"}
json.dump(cfg, open(A / "pipeline_config.json", "w"), indent=1)

rows = [("E7a phone default", key("int8", "int8", "mean", 0.3, "v1"))]
for v in a.variants:
    rows.append((f"best {v} (both models)", best(both(v))))
rows += [("best INT8-only, any recipe", best(lambda k: "fp32" not in k)),
         ("chosen model (alone)", chosen), ("chosen + v2 rules = SHIPPED", shipped)]
rows = [(l, k) for l, k in rows if k]
names = [s for s in ("dev", "free_dev", "test", "real", "free") if s in sets]
fm = lambda x: f"{x:.3f}" if x is not None else "  -  "
print("\nleak = personal details left visible; text = other text hidden; clin = medicine / lab values hidden")
print(f"{'':28s} {'setting':40s} {'MB':>5s} " + " ".join(f"{n[:8]:>8s}:leak  text  clin" for n in names))
for lab, k in rows:
    print(f"{lab:28s} {k:40s} {size(k):5.0f} " + " ".join(f"{fm(ev(n, k)['leak']):>13s} {fm(ev(n, k)['text'])} {fm(ev(n, k)['clin'])}" for n in names))
print("\nleak by source language (free = unlabelled names in real text; test = synthetic reports)")
for lab, k in rows:
    parts = []
    for n, srcs in (("free_dev", ("pmc", "hn")), ("free", ("pmc", "hn")), ("test", ("en", "mixed", "bn"))):
        if n in sets:
            parts += [f"{n}/{s} {fm(ev(n, k, s)['leak'])}" for s in srcs]
    print(f"  {lab:28s} " + "  ".join(parts))
print("\nshipped config:", cfg)

out = {"sizes_mb": MB, "latency_ms_median": {k: round(float(np.median(x)), 1) for k, x in ms.items()},
       "n": {k: len(x) for k, x in sets.items()}, "config": cfg, "rows": dict(rows),
       "results": {f"{n}|{k}|{s or 'all'}": v for (n, k, s), v in R.items()}}
json.dump(out, open("results/e7b_mobile_tune.json", "w"), indent=1)
print("wrote results/e7b_mobile_tune.json and", A / "pipeline_config.json")
