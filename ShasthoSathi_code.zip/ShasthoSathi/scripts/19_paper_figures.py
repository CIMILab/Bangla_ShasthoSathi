"""Figures for the manuscript (results/figures/paper/*.pdf). Numbers come from docs/RESULTS.md (cluster runs) and, where marked,
are recomputed here from local result files. Palette: validated categorical order (blue, orange, aqua, yellow, magenta,
green, violet, red), single-hue blue ramp for magnitudes, reserved status colours for HIGH / LOW / NORMAL.

    python scripts/19_paper_figures.py            # NER confusion matrix needs results/e18_ner_confusion.json
"""
import collections, json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np

OUT = ROOT / "results/figures/paper"; OUT.mkdir(parents=True, exist_ok=True)
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]   # categorical, fixed order
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
STATUS = {"high": "#d03b3b", "low": "#fab219", "normal": "#0ca30c"}
BLUES = LinearSegmentedColormap.from_list("b", ["#fcfcfb", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"])
W1 = 3.45          # one IEEE column, inches
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times", "Nimbus Roman", "DejaVu Serif"], "font.size": 7.5,
                     "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
                     "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6, "legend.frameon": False,
                     "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42, "figure.dpi": 150})


def grid(ax, axis="y"):
    ax.grid(axis=axis, color=GRID, linewidth=0.6); ax.set_axisbelow(True)


def save(fig, name):
    fig.savefig(OUT / f"{name}.pdf", bbox_inches="tight", pad_inches=0.02); plt.close(fig); print("wrote", name)


# ---------------------------------------------------------------- 1. script of entities in Bangla-HealthNER (E0)
ent = ["Medicine", "Dosage", "Health\ncondition", "Symptom"]
latin = np.array([1121, 175, 222, 690]); bangla = np.array([697, 381, 551, 2811]); mixed = np.array([34, 191, 13, 27])
tot = latin + bangla + mixed
fig, ax = plt.subplots(figsize=(W1, 1.35))
left = np.zeros(4)
for vals, lab, col in ((latin, "Latin script", C[0]), (bangla, "Bengali script", C[1]), (mixed, "Mixed / other", C[2])):
    share = 100 * vals / tot
    ax.barh(ent, share, left=left, color=col, edgecolor=SURF, linewidth=1.0, height=0.62, label=lab)
    for i, s in enumerate(share):
        if s > 9:
            ax.text(left[i] + s / 2, i, f"{s:.0f}%", ha="center", va="center", color="white", fontsize=6.5)
    left += share
ax.invert_yaxis(); ax.set_xlim(0, 100); ax.set_xlabel("Share of gold mentions (%)"); grid(ax, "x")
for i, n in enumerate(tot):
    ax.text(101, i, f"n={n:,}", va="center", fontsize=6, color=INK2)
ax.legend(ncol=3, loc="lower center", bbox_to_anchor=(0.45, 1.0), fontsize=6.5, handlelength=1, columnspacing=1)
save(fig, "e0_script")

# ---------------------------------------------------------------- 2. privacy / utility trade-off (E1, E3, E3b, E7)
fig, ax = plt.subplots(figsize=(W1, 2.05))
th = [0.3, 0.5, 0.7]; dev_leak = [9.5, 12.2, 19.9]; dev_over = [16.3, 7.9, 4.0]
ax.plot(dev_over, dev_leak, "-o", color=C[0], ms=4, lw=1.4, label="OpenMed PII, dev threshold sweep")
for x, y, t in zip(dev_over, dev_leak, th):
    ax.annotate(f"{t}", (x, y), textcoords="offset points", xytext=(4, 3), fontsize=6, color=INK2)
pts = [("Hybrid, real", 36.9, 0.2, C[1], "s"), ("+ protect 0.5, real", 6.2, 0.2, C[2], "s"),
       ("+ protect 0.3, real", 6.9, 0.0, C[2], "D"), ("+ protect 0.3, held-out", 0.1, 0.0, C[3], "D"),
       ("Phone setting, held-out", 5.1, 0.0, C[6], "^")]
for lab, x, y, col, mk in pts:
    ax.scatter(x, y, color=col, marker=mk, s=26, edgecolor=SURF, linewidth=0.8, zorder=3, label=lab)
ax.annotate("", xy=(6.6, 0.6), xytext=(35.5, 0.6), arrowprops=dict(arrowstyle="->", color=INK2, lw=0.8))
ax.text(21, 1.3, "medicine protection", fontsize=6, color=INK2, ha="center")
ax.set_xlabel("Clinical over-redaction (%)  ← better"); ax.set_ylabel("Identifier leak (%)  ← better")
ax.set_xlim(-1.5, 40); ax.set_ylim(-1, 22); grid(ax, "both")
ax.legend(fontsize=5.8, loc="upper right", handletextpad=0.3, labelspacing=0.3)
save(fig, "privacy_tradeoff")

# ---------------------------------------------------------------- 3. NER results with seed SD (E4, E5)
models = ["OpenMed-bn PII\nenc. (278M)", "XLM-R base\n(277M)", "BanglishBERT\n(110M)", "BanglishBERT\nINT8 (106 MB)"]
metrics = ["Micro F1", "Medicine F1", "Med. recall\n(Bengali)", "Dosage F1"]
mean = np.array([[58.71, 83.97, 81.83, 44.91], [58.67, 84.23, 82.31, 45.18], [57.81, 83.03, 80.77, 45.29],
                 [57.32, 82.50, np.nan, np.nan]])
sd = np.array([[0.84, 0.53, 0.36, 1.09], [0.75, 0.83, 0.86, 1.89], [0.40, 0.33, 0.50, 1.43], [0, 0, 0, 0]])
fig, ax = plt.subplots(figsize=(W1, 1.75))
x = np.arange(len(metrics)); w = 0.2
for i, m in enumerate(models):
    ax.bar(x + (i - 1.5) * w, mean[i], w * 0.92, yerr=sd[i], color=C[i], edgecolor=SURF, linewidth=0.5,
           error_kw=dict(lw=0.6, capsize=1.2, ecolor=INK), label=m.replace("\n", " "))
ax.axhline(56.13, xmin=0.02, xmax=0.24, color=INK, lw=0.8, ls="--")
ax.text(-0.42, 63, "published 56.1", fontsize=5.6, color=INK2)
ax.text(2.3, 4, "INT8: n/a", fontsize=5.2, color=INK2, ha="center", rotation=90)
ax.set_xticks(x, metrics, fontsize=6.4); ax.set_ylim(0, 95); ax.set_ylabel("Bangla-HealthNER test (×100)"); grid(ax)
ax.legend(fontsize=5.6, ncol=2, loc="upper center", bbox_to_anchor=(0.5, 1.32), handlelength=1, columnspacing=0.8)
save(fig, "ner_bars")

# ---------------------------------------------------------------- 4. explanation correctness / safety by condition (E6, E6c)
cond = ["free", "facts", "strict"]
en = {"Qwen2.5-0.5B": ([4, 22, None], [11, 17, None]), "Qwen2.5-1.5B": ([6, 59, None], [12, 23, None]),
      "Qwen3-1.7B": ([16, 95, 97], [53, 61, 96]), "Phi-3.5-mini": ([55, 98, 96], [52, 68, 94])}
bn = {"Qwen2.5-0.5B": ([5, 3, None], [67, 54, None]), "Qwen2.5-1.5B": ([8, 31, None], [14, 24, None]),
      "Qwen3-1.7B": ([8, 50, 71], [46, 50, 78]), "Phi-3.5-mini": ([25, 18, 35], [66, 81, 66])}
fig, axes = plt.subplots(2, 2, figsize=(W1, 2.6), sharex=True, sharey=True)
for col, (lang, d, tpl) in enumerate((("English", en, (99, 98)), ("Bengali", bn, (100, 99)))):
    for row, (k, name) in enumerate(((0, "Correct (%)"), (1, "Safe (%)"))):
        ax = axes[row, col]
        for i, (m, vals) in enumerate(d.items()):
            ys = vals[k]; xs = [j for j, v in enumerate(ys) if v is not None]
            ax.plot(xs, [ys[j] for j in xs], "-o", color=C[i], ms=3.2, lw=1.2, label=m)
        ax.axhline(tpl[k], color=INK, lw=0.8, ls="--")
        ax.text(-0.05, tpl[k] - 9, "template", fontsize=5.6, color=INK2, ha="left")
        if col == 1 and k == 0:
            ax.scatter([2], [60], marker="*", s=40, color=C[2], edgecolor=INK, linewidth=0.4, zorder=4)
            ax.annotate("native rater: 60", (2, 60), xytext=(-46, 14), textcoords="offset points", fontsize=5.6,
                        color=INK2, arrowprops=dict(arrowstyle="-", lw=0.5, color=INK2))
        ax.set_ylim(0, 108); ax.set_xticks(range(3), cond); grid(ax)
        if row == 0:
            ax.set_title(lang, fontsize=7.5, color=INK)
        if col == 0:
            ax.set_ylabel(name)
axes[0, 0].legend(fontsize=5.5, ncol=4, loc="lower center", bbox_to_anchor=(1.05, 1.18), handlelength=1.2, columnspacing=0.8)
fig.subplots_adjust(hspace=0.12, wspace=0.16)
for a in axes[1]:
    a.tick_params(axis="x", labelsize=6.3)
save(fig, "explain_conditions")

# ---------------------------------------------------------------- 5. quantization fragility (E7b/E7c)
var = ["FP32", "INT8\nfull", "INT8\nRR", "INT8\nno-attn", "INT8\nno-attn RR", "INT8\nemb. only"]
en_m = [1.5, 1.5, 40.5, 2.0, 42.0, 1.5]; bn_m = [0.0, 100.0, 25.5, 100.0, 14.0, 0.0]
mb = ["1602", "486", "486", "526", "526", "770"]
fig, ax = plt.subplots(figsize=(W1, 1.75))
x = np.arange(len(var)); w = 0.36
b1 = ax.bar(x - w / 2, en_m, w * 0.92, color=C[0], edgecolor=SURF, linewidth=0.5, label="English model (PMC texts)")
b2 = ax.bar(x + w / 2, bn_m, w * 0.92, color=C[1], edgecolor=SURF, linewidth=0.5, label="Bengali model (HealthNER posts)")
for bars in (b1, b2):
    for b in bars:
        h = b.get_height(); ax.text(b.get_x() + b.get_width() / 2, h + 2, f"{h:g}", ha="center", fontsize=5.5, color=INK)
for i, m in enumerate(mb):
    ax.text(i, -30, f"{m} MB", ha="center", fontsize=5.3, color=INK2)
ax.set_xticks(x, var, fontsize=5.6); ax.set_ylim(0, 112); ax.set_ylabel("Unlabelled names missed (%)"); grid(ax)
ax.legend(fontsize=5.8, ncol=2, loc="upper center", bbox_to_anchor=(0.5, 1.2), handlelength=1)
save(fig, "quantization")

# ---------------------------------------------------------------- 6. lab-flag confusion after OCR (E8 proxy; recomputed locally)
from shastho.rules import parse_lab_lines
rows = json.load(open(ROOT / "results/e8_ocr_proxy.json"))
gold_g = [json.loads(l) for l in open(ROOT / "mobile/android/core/src/test/resources/golden/ocr_golden.jsonl")]
cm = collections.Counter()
for r, g in zip(rows, gold_g):
    if r["lang"] != "ben+eng" or r["cond"] == "dim_blur":
        continue
    got = {}
    for l in parse_lab_lines(g["hyp"]):
        got.setdefault(l.name.strip().lower(), l.flag)
    for l in g["labs"]:
        cm[(l["flag"], got.get(l["name"].strip().lower(), "not read"))] += 1
gl = ["low", "normal", "high"]; pl = ["low", "normal", "high", "not read"]
M = np.array([[cm[(a, b)] for b in pl] for a in gl])
fig, ax = plt.subplots(figsize=(W1 * 0.7, 1.5))
ax.imshow(M / M.sum(1, keepdims=True), cmap=BLUES, vmin=0, vmax=1, aspect="auto")
for i in range(3):
    for j in range(4):
        frac = M[i, j] / M[i].sum()
        ax.text(j, i, f"{M[i, j]}", ha="center", va="center", fontsize=7, color="white" if frac > 0.55 else INK)
ax.set_xticks(range(4), ["LOW", "NORM.", "HIGH", "not\nread"], fontsize=6.3); ax.set_yticks(range(3), ["LOW", "NORMAL", "HIGH"])
ax.set_xlabel("Flag from OCR text"); ax.set_ylabel("Gold flag")
for s in ax.spines.values():
    s.set_visible(False)
ax.tick_params(length=0)
save(fig, "ocr_flag_confusion")
json.dump({"labels_gold": gl, "labels_pred": pl, "matrix": M.tolist()}, open(ROOT / "results/e8_flag_confusion.json", "w"))

# ---------------------------------------------------------------- 7. NER word-level confusion matrix (E4 model, from Hellbender)
p = ROOT / "results/e18_ner_confusion.json"
if p.exists():
    d = json.load(open(p)); labs = d["labels"]; M = np.array(d["matrix"], dtype=float)
    R = M / np.maximum(M.sum(1, keepdims=True), 1)
    fig, ax = plt.subplots(figsize=(W1, 2.55))
    ax.imshow(R, cmap=BLUES, vmin=0, vmax=1)
    for i in range(len(labs)):
        for j in range(len(labs)):
            if R[i, j] >= 0.005:
                ax.text(j, i, f"{100 * R[i, j]:.0f}", ha="center", va="center", fontsize=5.6,
                        color="white" if R[i, j] > 0.55 else INK)
    short = [l.replace("Health Condition", "Condition").replace("Medical Procedure", "Procedure") for l in labs]
    ax.set_xticks(range(len(labs)), short, rotation=40, ha="right"); ax.set_yticks(range(len(labs)), short)
    ax.set_xlabel("Predicted entity type (word level)"); ax.set_ylabel("Gold entity type")
    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(length=0)
    save(fig, "ner_confusion")
else:
    print("skip ner_confusion: run scripts/18_ner_confusion.py on Hellbender first")
