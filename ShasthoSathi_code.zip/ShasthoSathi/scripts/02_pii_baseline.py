"""Experiment 1: how much personal information does OpenMed let through?

Runs OpenMed PII models on the synthetic set (and optional injected real text),
compares three routes (English model only, Bengali model only, route by script),
and sweeps the confidence threshold.

    python scripts/02_pii_baseline.py --data data/synthetic/synth_v1.jsonl --device cuda
"""
import argparse, collections, json, pathlib, statistics, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from shastho.metrics import pii_leakage, over_redaction, bootstrap_ci
from shastho.openmed_adapter import OpenMedRunner

ap = argparse.ArgumentParser()
ap.add_argument("--data", nargs="+", default=["data/synthetic/synth_v1.jsonl"])
ap.add_argument("--routes", nargs="+", default=["en", "bn", "script"])
ap.add_argument("--thresholds", nargs="+", type=float, default=[0.3, 0.5, 0.7])
ap.add_argument("--device", default="cpu")
ap.add_argument("--limit", type=int, default=0, help="debug: only first N docs")
ap.add_argument("--out", default="results/exp1_pii.json")
a = ap.parse_args()

docs = [json.loads(l) for p in a.data for l in open(p, encoding="utf-8")]
if a.limit:
    docs = docs[: a.limit]
runner = OpenMedRunner(a.device)
runner.pii("warm up Rahima Begum 01712-345678", "en")
runner.pii("রহিমা বেগম ০১৭১২-৩৪৫৬৭৮", "bn")

summary, per_doc_rows = {}, []
for route in a.routes:
    for th in a.thresholds:
        key = f"{route}@{th}"
        leaks, anyleak, times, over = [], [], [], collections.Counter()
        per_type = collections.defaultdict(lambda: [0, 0])
        per_group = collections.defaultdict(list)
        for d in docs:
            spans, dt, langs = runner.pii_auto(d["text"], th, route)
            pred = [(s, e) for s, e, *_ in spans]
            m = pii_leakage(d["pii"], pred, d["text"])
            protected = [tuple(m_["brand_span"]) for m_ in d.get("meds", [])] + \
                        [tuple(l["value_span"]) for l in d.get("labs", [])]
            o = over_redaction(protected, pred)
            over["protected"] += o["protected"]; over["redacted"] += o["redacted"]
            leaks.append(m["span_leak_rate"]); anyleak.append(m["doc_any_leak"]); times.append(dt)
            per_group[f'{d["doc_type"]}:{d["lang"]}'].append(m["span_leak_rate"])
            for t, v in m["per_type"].items():
                per_type[t][0] += v["leaked"]; per_type[t][1] += v["total"]
            per_doc_rows.append({"route": route, "th": th, "doc_id": d["doc_id"], "leak": m["span_leak_rate"],
                                 "leaked_types": [t for t, v in m["per_type"].items() if v["leaked"]],
                                 "pred": spans, "sec": dt})
        mean, lo, hi = bootstrap_ci(leaks)
        summary[key] = {
            "span_leak_rate": mean, "ci95": [lo, hi],
            "docs_with_any_leak": sum(anyleak) / len(anyleak),
            "per_type_leak": {t: v[0] / v[1] for t, v in per_type.items()},
            "per_group_leak": {g: statistics.mean(v) for g, v in per_group.items()},
            "clinical_over_redaction": over["redacted"] / max(over["protected"], 1),
            "median_sec_per_doc": statistics.median(times),
        }
        print(f"{key:12s} leak={mean:.3f} [{lo:.3f},{hi:.3f}] anyleak={summary[key]['docs_with_any_leak']:.2f} "
              f"over-redact={summary[key]['clinical_over_redaction']:.3f} t={summary[key]['median_sec_per_doc']*1000:.0f}ms")

pathlib.Path(a.out).parent.mkdir(parents=True, exist_ok=True)
json.dump({"args": vars(a), "n_docs": len(docs), "summary": summary,
           "time": time.strftime("%Y-%m-%d %H:%M")}, open(a.out, "w"), indent=2, ensure_ascii=False)
with open(pathlib.Path(a.out).with_suffix(".per_doc.jsonl"), "w", encoding="utf-8") as f:
    for r in per_doc_rows:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")
print("wrote", a.out)
