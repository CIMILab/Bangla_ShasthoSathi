"""Mean ± SD across seeds for each E4 config (runs/<model>-<full|lora>-s<seed>/metrics.json).

    python scripts/98_seed_summary.py
"""
import collections, glob, json, pathlib, re, statistics as st

groups = collections.defaultdict(list)
for f in sorted(glob.glob("runs/*/metrics.json")):
    tag = pathlib.Path(f).parent.name
    m = re.match(r"(.+)-s(\d+)$", tag)
    if m:
        groups[m.group(1)].append((int(m.group(2)), json.load(open(f))))

def ms(xs):
    return f"{st.mean(xs):.2f} ± {st.stdev(xs):.2f}" if len(xs) > 1 else f"{xs[0]:.2f}"

rows = []
for cfg, runs in groups.items():
    t = [r["test"] for _, r in runs]
    get = lambda fn: [100 * fn(x) for x in t]
    rows.append([cfg, ",".join(str(s) for s, _ in sorted(runs, key=lambda x: x[0])),
                 ms(get(lambda x: x["micro"]["f1"])), ms(get(lambda x: x["macro_f1"])),
                 ms(get(lambda x: x["per_type"]["Medicine"]["f1"])),
                 ms(get(lambda x: x["recall_by_script"].get("Medicine|bn", {"recall": 0})["recall"])),
                 ms(get(lambda x: x["per_type"]["Dosage"]["f1"]))])
rows.sort(key=lambda r: -float(r[2].split()[0]))
hdr = ["config", "seeds", "micro F1", "macro F1", "Medicine F1", "Medicine R (Bangla)", "Dosage F1"]
w = [max(len(str(x)) for x in col) for col in zip(hdr, *rows)]
line = lambda r: "| " + " | ".join(str(x).ljust(n) for x, n in zip(r, w)) + " |"
out = [line(hdr), "|" + "|".join("-" * (n + 2) for n in w) + "|"] + [line(r) for r in rows]
print("\n".join(out))
print("\nReference: BanglishBERT micro F1 56.13 ± 0.75 (Khan et al., 2023). All values ×100.")
pathlib.Path("results/e4_seed_summary.md").write_text("\n".join(out) + "\n", encoding="utf-8")
print("wrote results/e4_seed_summary.md")
