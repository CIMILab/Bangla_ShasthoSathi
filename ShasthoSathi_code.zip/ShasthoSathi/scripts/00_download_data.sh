#!/usr/bin/env bash
# Download all open datasets (run on a Hellbender login node).
set -euo pipefail
mkdir -p data/raw && cd data/raw

# 1. Bangla-HealthNER (Khan et al., Findings of EMNLP 2023) — CC BY-NC-SA 4.0
[ -d Bangla-HealthNER ] || git clone --depth 1 https://github.com/alvi-khan/Bangla-HealthNER.git

# 2. PMC-Patients and 3. ADE Corpus v2 via Hugging Face datasets
python - <<'PY'
from datasets import load_dataset
pmc = load_dataset("zhengyun21/PMC-Patients", split="train")
pmc.select(range(2000)).to_json("pmc_patients_sample2000.jsonl", force_ascii=False)
print("PMC-Patients:", len(pmc), "rows; saved a 2,000-row sample")
ade = load_dataset("ade-benchmark-corpus/ade_corpus_v2", "Ade_corpus_v2_drug_dosage_relation", split="train")
ade.to_json("ade_drug_dosage.jsonl", force_ascii=False)
print("ADE drug-dosage:", len(ade))
PY

# 4-6. Prescription images and the DGDA drug list need a browser (Kaggle login /
# Mendeley / DGDA site). Download them manually into data/raw/ — see docs/DATA.md.
ls -la
