"""Radar ("spider") summary figure: three panels, all axes scaled 0-100 with higher = better.

  (a) De-identification  - Table tab_deid  (privacy = 100 - leak, text kept = 100 - over-redaction)
  (b) Explanation        - Table tab_explain (Qwen3-1.7B free -> grounded -> strict, vs. template)
  (c) Medicine tagger    - results/e18_ner_confusion.json (per-type P / R / F1, INT8 on phone)

    python scripts/21_radar.py      # -> results/figures/radar_summary.{pdf,png,svg}
"""
import json, pathlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#d9d8d3", "#fcfcfb"
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times", "Nimbus Roman", "DejaVu Serif"], "font.size": 7,
                     "pdf.fonttype": 42, "legend.frameon": False, "figure.dpi": 150})


def radar(ax, axes, series, title, ours, lab_off=4):
    n = len(axes); th = np.linspace(0, 2 * np.pi, n, endpoint=False)
    ax.set_theta_offset(np.pi / 2); ax.set_theta_direction(-1)          # first axis at the top, clockwise
    ax.set_xticks(th); ax.set_xticklabels(axes, fontsize=6.3, color=INK, linespacing=0.95)
    ax.tick_params(axis="x", pad=lab_off)
    ax.set_yticks([25, 50, 75, 100]); ax.set_yticklabels(["25", "50", "75", ""], fontsize=5, color=INK2)
    ax.set_rlabel_position(np.degrees(th[0]) + 360 / n / 2)
    ax.grid(color=GRID, linewidth=0.5); ax.spines["polar"].set_color(GRID); ax.set_facecolor(SURF)
    tt = np.r_[th, th[:1]]
    for k, (name, vals, col, style) in enumerate(series):
        v = np.r_[vals, vals[:1]]; main = name == ours
        ax.plot(tt, v, color=col, linewidth=1.9 if main else 1.1, linestyle=style, zorder=4 if main else 3,
                label=name, solid_capstyle="round")
        ax.fill(tt, v, color=col, alpha=0.22 if main else 0.06, zorder=2)
        ax.scatter(th, vals, s=14 if main else 7, color=col, edgecolor="white", linewidth=0.6, zorder=5)
        if main:
            for t, x in zip(th, vals):
                ax.text(t, max(x - 19, 8), f"{x:g}", ha="center", va="center", fontsize=5.6, fontweight="bold",
                        color=col, zorder=6, bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none", alpha=0.85))
    ax.set_thetalim(0, 2 * np.pi); ax.set_ylim(0, 100)
    ax.text(0.5, 1.30, title, transform=ax.transAxes, ha="center", va="bottom", fontsize=7.8, fontweight="bold", color=INK)


fig, axs = plt.subplots(1, 3, figsize=(7.16, 2.75), subplot_kw={"projection": "polar"})
fig.subplots_adjust(left=0.05, right=0.97, top=0.82, bottom=0.25, wspace=0.75)

# (a) de-identification (Table tab_deid)
deid_axes = ["Privacy\n(synthetic)", "Privacy\n(real text)", "Clinical text\nkept (real)", "Clinical\ntext kept\n(synthetic)"]
leak = {"Rules only": (53.6, 60.0), "OpenMed PII": (10.3, 5.5), "Hybrid": (0.6, 0.2), "Hybrid + protect (ours)": (0.0, 0.0)}
over = {"Rules only": (0.0, 0.0), "OpenMed PII": (8.4, 36.9), "Hybrid": (8.4, 36.9), "Hybrid + protect (ours)": (0.1, 6.9)}
cols = {"Rules only": (C[3], (0, (3, 2))), "OpenMed PII": (C[1], (0, (1, 1.2))), "Hybrid": (C[6], "-"), "Hybrid + protect (ours)": (C[2], "-")}
sa = [(k, [round(100 - leak[k][0], 1), round(100 - leak[k][1], 1), round(100 - over[k][1], 1), round(100 - over[k][0], 1)], *cols[k]) for k in leak]
radar(axs[0], deid_axes, sa, "(a) De-identification", "Hybrid + protect (ours)")

# (b) explanation (Table tab_explain), Qwen3-1.7B
ex_axes = ["Correct\n(EN)", "Safe\n(EN)", "Safe\n(BN)", "Correct\n(BN)"]
ex = {"Qwen3-1.7B, free": [16, 53, 46, 8], "+ fact sheet": [95, 61, 50, 50], "+ strict prompt": [97, 96, 78, 71], "Template (ours)": [99, 98, 99, 100]}
ecol = {"Qwen3-1.7B, free": (C[7], (0, (1, 1.2))), "+ fact sheet": (C[3], (0, (3, 2))), "+ strict prompt": (C[0], "-"), "Template (ours)": (C[6], "-")}
radar(axs[1], ex_axes, [(k, v, *ecol[k]) for k, v in ex.items()], "(b) Explanation quality", "Template (ours)")

# (c) medicine tagger per entity type (E18)
d = json.load(open(ROOT / "results/e18_ner_confusion.json"))["per_type"]
types = ["Medicine", "Specialist", "Age", "Medical Procedure", "Dosage", "Health Condition", "Symptom"]
short = {"Medical Procedure": "Proce-\ndure", "Health Condition": "Health\ncondition", "Specialist": "Specia-\nlist"}
ner = [("Recall", [round(100 * d[t]["recall"]) for t in types], C[1], (0, (3, 2))),
       ("Precision", [round(100 * d[t]["precision"]) for t in types], C[0], (0, (1, 1.2))),
       ("F1", [round(100 * d[t]["f1"]) for t in types], C[5], "-")]
radar(axs[2], [short.get(t, t) for t in types], ner, "(c) Medicine tagger (INT8)", "F1", lab_off=4)

for ax in axs:
    h, l = ax.get_legend_handles_labels()
    ax.legend(h, l, loc="upper center", bbox_to_anchor=(0.5, -0.17), ncol=2, fontsize=5.9, handlelength=2.2,
              columnspacing=0.9, handletextpad=0.4)

out = ROOT / "results/figures"; out.mkdir(parents=True, exist_ok=True)
fig.savefig(out / "radar_summary.pdf", bbox_inches="tight", pad_inches=0.03)
fig.savefig(out / "radar_summary.png", bbox_inches="tight", pad_inches=0.03, dpi=300)
fig.savefig(out / "radar_summary.svg", bbox_inches="tight", pad_inches=0.03)
print("wrote radar_summary")
