"""E7d: the leak test that runs ON THE PHONE (Research tools -> Leak test).

Rebuilds exactly the E7b/E7c test sets (scripts/14_mobile_tune.py, same seeds):
  test = held-out synthetic reports (300), real = PMC-Patients + Bangla-HealthNER text with injected identifiers (400),
  free = the same real texts with an unlabelled name inside a sentence (400),
runs the shipped phone configuration on the server (src/shastho/mobile_ref.py, mobile/assets/pipeline_config.json)
and writes, per document, the text, the gold identifiers, the protected clinical spans and the server's hidden spans.
The phone runs its own pipeline on the same texts, scores it with the same metric and compares span by span.

    python scripts/24_phone_leak_set.py --threads 4
    -> results/phone_models/ShasthoSathi/phone_leak_set.jsonl (copy with the model folder; the app picks it up)

Offsets are written in UTF-16 code units (what Kotlin strings use); identical to Python's for BMP-only text.
"""
import argparse, json, os, pathlib, random, re, sys, time
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import numpy as np
from shastho.metrics import _content, bio_to_spans, bootstrap_ci, over_redaction, pii_leakage
from shastho.mobile_ref import MobilePipeline
from shastho.synth import _name, inject_pii, use_vocab

ap = argparse.ArgumentParser()
ap.add_argument("--assets", default=os.environ.get("ASSETS", "mobile/assets"))
ap.add_argument("--test", default="data/synthetic/synth_heldout.jsonl")
ap.add_argument("--pmc", default="data/raw/pmc_patients_sample2000.jsonl")
ap.add_argument("--healthner", default="data/raw/Bangla-HealthNER/Dataset/test.json")
ap.add_argument("--n", type=int, default=300)
ap.add_argument("--n-real", type=int, default=200)
ap.add_argument("--threads", type=int, default=4)
ap.add_argument("--out", default="results/phone_models/ShasthoSathi/phone_leak_set.jsonl")
a = ap.parse_args()

# ---------------------------------------------------------------- sets (copied from 14_mobile_tune.py; same seeds)
load = lambda p, n=0: [json.loads(l) for l in open(p, encoding="utf-8")][: n or None]
sets = {"test": load(ROOT / a.test, a.n)}
for d in sets["test"]:
    d["protected"] = [tuple(m["brand_span"]) for m in d.get("meds", [])] + [tuple(l["value_span"]) for l in d["labs"]]
    d["src"] = d.get("lang", "?")

EN_SUBJ = re.compile(r"\b(?:[Tt]he patient|[Aa]n? \d{1,3}[- ]year[- ]old (?:man|woman|male|female|boy|girl|patient))\b")
BN_T = ["আমার বাবা {n} অনেক দিন ধরে অসুস্থ। ", "{n} গত সপ্তাহে ডাক্তার দেখিয়েছেন। ", "আমি {n}, আমার একটা প্রশ্ন আছে। ",
        "আমার মা {n} এর জন্য পরামর্শ চাই। "]


def make_free(bodies, seed, prefix):
    rf, out = random.Random(seed), []
    for lang, did, body, prot in bodies:
        name = _name(rf, rf.choice("MF"), lang == "bn")
        if lang == "en":
            m = EN_SUBJ.search(body)
            if m:
                text, s = body[:m.start()] + name + body[m.end():], m.start()
            else:
                text, s = f"{name} was seen in the clinic. {body}", 0
            prot2 = []
        else:
            pre = rf.choice(BN_T).format(n=name); s = pre.index(name); text = pre + body
            prot2 = [(ps + len(pre), pe + len(pre)) for ps, pe in prot]
        out.append({"doc_id": prefix + did, "src": did.split("_")[0], "text": text, "labs": [], "protected": prot2,
                    "pii": [{"start": s, "end": s + len(name), "type": "NAME", "text": name}]})
    return out


r = random.Random(11)
real, bodies = [], []
use_vocab("heldout")
if (ROOT / a.pmc).exists():
    pmc = load(ROOT / a.pmc)
    for i, j in enumerate(r.sample(range(len(pmc)), min(a.n_real, len(pmc)))):
        body = (pmc[j].get("patient") or pmc[j].get("text") or "")[:1500]
        d = inject_pii(body, "en", r, f"pmc_{i:04d}").to_dict(); d["protected"] = []; d["src"] = "pmc"
        real.append(d); bodies.append(("en", f"pmc_{i:04d}", body, []))
else:
    print("note: no", a.pmc, "-> English real/free texts skipped")
if (ROOT / a.healthner).exists():
    hn = json.load(open(ROOT / a.healthner, encoding="utf-8"))
    for i, j in enumerate(r.sample(range(len(hn)), min(a.n_real, len(hn)))):
        toks = hn[j]["text"].split(); body = " ".join(toks)
        d = inject_pii(body, "bn", r, f"hn_{i:04d}").to_dict(); d["src"] = "hn"
        off = d["text"].index(body)
        prot = [(s, e) for s, e, lab in bio_to_spans(toks, hn[j]["labels"]) if lab in ("Medicine", "Dosage")]
        d["protected"] = [(s + off, e + off) for s, e in prot]
        real.append(d); bodies.append(("bn", f"hn_{i:04d}", body, prot))
if real:
    sets["real"] = real
    sets["free"] = make_free(bodies, 23, "free_")
use_vocab("dev")
print({k: len(v) for k, v in sets.items()}, flush=True)

# ---------------------------------------------------------------- server run of the shipped phone configuration
mp = MobilePipeline(ROOT / a.assets, threads=a.threads)
print("config:", mp.config, flush=True)


def u16(text):
    """Python index -> UTF-16 index."""
    out, k = [0] * (len(text) + 1), 0
    for i, ch in enumerate(text):
        out[i] = k; k += 2 if ord(ch) > 0xFFFF else 1
    out[len(text)] = k
    return out


out = pathlib.Path(ROOT / a.out); out.parent.mkdir(parents=True, exist_ok=True)
summary, t0 = {}, time.time()
with open(out, "w", encoding="utf-8") as f:
    rows = []
    for name, docs in sets.items():
        leaks, clin, hidden = [], [0, 0], [0, 0]
        for d in docs:
            text = d["text"]
            _, merged = mp.privacy(text)
            pred = [(s, e) for s, e, _ in merged]
            m = pii_leakage(d["pii"], pred, text); leaks.append(m["span_leak_rate"])
            o = over_redaction(d["protected"], pred); clin[0] += o["redacted"]; clin[1] += o["protected"]
            gold = np.zeros(len(text), bool); hid = np.zeros(len(text), bool)
            for g in d["pii"]:
                gold[g["start"]:g["end"]] = True
            for s, e in pred:
                hid[s:e] = True
            other = [i for i, ch in enumerate(text) if _content(ch) and not gold[i]]
            hidden[0] += int(hid[other].sum()) if other else 0; hidden[1] += len(other)
            U = u16(text)
            rows.append({"set": name, "doc_id": d["doc_id"], "src": d.get("src", "?"), "text": text,
                         "pii": [[U[g["start"]], U[g["end"]], g["type"]] for g in d["pii"]],
                         "protected": [[U[s], U[e]] for s, e in d["protected"]],
                         "server": [[U[s], U[e]] for s, e in pred]})
        mean, lo, hi = bootstrap_ci(leaks)
        summary[name] = {"n": len(docs), "leak": round(mean, 4), "ci95": [lo, hi],
                         "clin": round(clin[0] / clin[1], 4) if clin[1] else None,
                         "text": round(hidden[0] / hidden[1], 4) if hidden[1] else None}
        print(name, summary[name], flush=True)
    f.write(json.dumps({"meta": {"config": mp.config, "server": summary}}, ensure_ascii=False) + "\n")
    for row in rows:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
json.dump(summary, open(ROOT / "results/e7d_server_leak.json", "w"), indent=1)
print(f"wrote {out} ({sum(len(v) for v in sets.values())} docs, {out.stat().st_size / 2**20:.1f} MB, {time.time()-t0:.0f}s)")
print("Copy it to the phone into Download/ShasthoSathi, then in the app: Settings -> Load privacy models -> same folder,")
print("then Research tools -> Leak test.")
