"""Collect exactly the files the app (v0.4) needs into one small folder to copy to the phone.

    python scripts/20_web_golden.py      # first: golden files for the on-phone check
    python scripts/23_phone_bundle.py    # -> results/phone_models/ShasthoSathi/{ner,pii_bn,pii_en}

mobile/assets also holds the FP32 and other INT8 variants (several GB); the phone needs only the chosen variant of
each model (pipeline_config.json), its tokenizer and meta files, and the two golden files: about 700 MB.
"""
import json, os, pathlib, shutil
ROOT = pathlib.Path(__file__).resolve().parents[1]
A = pathlib.Path(os.environ.get("ASSETS", ROOT / "mobile/assets"))
OUT = ROOT / "results/phone_models/ShasthoSathi"
cfg = json.load(open(A / "pipeline_config.json"))
pv = cfg["pii_variant"] if isinstance(cfg["pii_variant"], dict) else {"bn": cfg["pii_variant"], "en": cfg["pii_variant"]}
variant = {"ner": cfg.get("ner_variant", "int8"), "pii_bn": pv["bn"], "pii_en": pv["en"]}

if OUT.exists():
    shutil.rmtree(OUT)
total = 0
for name, v in variant.items():
    need = ["meta.json", "tokenizer.json", f"model_{v}.onnx"]
    missing = [f for f in need if not (A / name / f).exists()]
    if missing:
        raise SystemExit(f"{name}: missing {missing} in {A / name}")
    for f in need + ["tok_golden.json", "model_golden.json"]:
        src = A / name / f
        if not src.exists():
            print(f"  note: {name}/{f} not found (run scripts/20_web_golden.py for the on-phone check)"); continue
        (OUT / name).mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, OUT / name / f); total += src.stat().st_size
    print(f"{name:7s} {v:11s} {sum((OUT / name / f).stat().st_size for f in os.listdir(OUT / name)) / 2**20:7.1f} MB")
shutil.copy2(A / "pipeline_config.json", OUT / "pipeline_config.json")
print(f"total {total / 2**20:.0f} MB -> {OUT}")
print("Copy this ShasthoSathi folder to the phone's Download folder, then in the app: Settings -> Load privacy models.")
