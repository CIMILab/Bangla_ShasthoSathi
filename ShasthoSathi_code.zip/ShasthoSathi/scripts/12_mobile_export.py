"""E7 step 1: build the phone asset folder (mobile/assets/) from the evaluated models.

    mobile/assets/ner/        fine-tuned BanglishBERT medicine/dosage tagger (INT8 from E5)
    mobile/assets/pii_bn/     OpenMed Bengali PII model   -> ONNX INT8
    mobile/assets/pii_en/     OpenMed English PII model   -> ONNX INT8
    each: model_int8.onnx (+ model_fp32.onnx for the parity check, not shipped), tokenizer.json, meta.json
    mobile/assets/text.json   Bengali test names, status words, doctor sentence (so Kotlin never retypes them)
    mobile/assets/manifest.json  file sizes + md5

Checks printed at the end: the saved tokenizer.json gives the same ids as the Hugging Face tokenizer,
and ONNX FP32 logits match PyTorch.

    python scripts/12_mobile_export.py --ner-tag banglishbert-full-s42
"""
import argparse, hashlib, json, pathlib, shutil, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
import numpy as np
import torch

ap = argparse.ArgumentParser()
ap.add_argument("--ner-tag", default="banglishbert-full-s42")
ap.add_argument("--runs", default="runs")
ap.add_argument("--out", default="mobile/assets")
ap.add_argument("--pii", nargs="*", default=["bn", "en"])
ap.add_argument("--max-len", type=int, default=256)
ap.add_argument("--stride", type=int, default=64)
a = ap.parse_args()

from transformers import AutoModelForTokenClassification, AutoTokenizer
from tokenizers import Tokenizer
import onnxruntime as ort
from onnxruntime.quantization import QuantType, quantize_dynamic
from shastho.explain import BN_LABEL, DOCTOR, STATUS
from shastho.openmed_adapter import BN_PII_MODEL, EN_PII_MODEL, compat_model_dir

OUT = pathlib.Path(a.out); OUT.mkdir(parents=True, exist_ok=True)
SAMPLE = ["Patient:", "Nusrat", "Mollah", "01365-538485", "Haemoglobin", "10.2", "g/dL",
          "রোগীর", "নাম:", "নুসরাত", "মোল্লা", "নাপা", "৫০০", "১+০+১", "ঢাকা"]


class Wrap(torch.nn.Module):
    def __init__(self, m): super().__init__(); self.m = m
    def forward(self, input_ids, attention_mask): return self.m(input_ids=input_ids, attention_mask=attention_mask).logits


def export(model, tok, path):
    ex = tok(["Patient Nusrat রোগীর নাম নাপা ৫০০"], return_tensors="pt")
    torch.onnx.export(Wrap(model).eval(), (ex["input_ids"], ex["attention_mask"]), str(path), dynamo=False,
                      input_names=["input_ids", "attention_mask"], output_names=["logits"], opset_version=17,
                      dynamic_axes={"input_ids": {0: "b", 1: "t"}, "attention_mask": {0: "b", 1: "t"},
                                    "logits": {0: "b", 1: "t"}})
    model.eval()


def build(name, model_dir, int8_src=None):
    d = OUT / name; d.mkdir(exist_ok=True)
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(model_dir, use_fast=True)
    model = AutoModelForTokenClassification.from_pretrained(model_dir).eval()
    fp32, int8 = d / "model_fp32.onnx", d / "model_int8.onnx"
    if not fp32.exists():
        export(model, tok, fp32)
    if not int8.exists():
        if int8_src and pathlib.Path(int8_src).exists():
            shutil.copy(int8_src, int8)                  # reuse the exact file evaluated in E5
        else:
            quantize_dynamic(str(fp32), str(int8), weight_type=QuantType.QInt8)
    tok.backend_tokenizer.save(str(d / "tokenizer.json"))
    labels = [model.config.id2label[i] for i in range(model.config.num_labels)]
    meta = {"source": str(model_dir), "labels": labels, "cls_id": tok.cls_token_id, "sep_id": tok.sep_token_id,
            "pad_id": tok.pad_token_id, "max_len": a.max_len, "stride": a.stride,
            "inputs": ["input_ids", "attention_mask"], "output": "logits [1, T, num_labels]"}
    json.dump(meta, open(d / "meta.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    # check 1: tokenizer.json (what the phone loads) == Hugging Face tokenizer, word by word
    t2 = Tokenizer.from_file(str(d / "tokenizer.json")); t2.no_truncation(); t2.no_padding()
    tok_ok = all(t2.encode(w, add_special_tokens=False).ids == tok(w, add_special_tokens=False)["input_ids"] for w in SAMPLE)
    # check 2: ONNX FP32 / INT8 vs PyTorch on one sentence
    x = tok([" ".join(SAMPLE)], return_tensors="pt")
    with torch.inference_mode():
        ref = model(**{k: x[k] for k in ("input_ids", "attention_mask")}).logits[0].numpy()
    diff, agree = {}, {}
    for v, p in (("fp32", fp32), ("int8", int8)):
        so = ort.SessionOptions(); so.intra_op_num_threads = 4     # explicit threads: no affinity warnings on Slurm
        s = ort.InferenceSession(str(p), so, providers=["CPUExecutionProvider"])
        z = s.run(None, {k: x[k].numpy().astype(np.int64) for k in ("input_ids", "attention_mask")})[0][0]
        diff[v] = float(np.abs(z - ref).max()); agree[v] = float((z.argmax(-1) == ref.argmax(-1)).mean())
    mb = int8.stat().st_size / 2**20
    print(f"{name:7s} labels={len(labels):3d} int8={mb:6.1f} MB  tokenizer_match={tok_ok}  "
          f"max|logit diff| fp32={diff['fp32']:.2e}  argmax agree fp32={agree['fp32']:.3f} int8={agree['int8']:.3f}  "
          f"({time.time()-t0:.0f}s)", flush=True)
    return {"tokenizer_match": tok_ok, "logit_diff": diff, "argmax_agree": agree, "int8_mb": round(mb, 1)}


checks = {}
ner_run = pathlib.Path(a.runs) / a.ner_tag
checks["ner"] = build("ner", ner_run / "model", ner_run / "onnx" / "model_int8.onnx")
for lg in a.pii:
    checks[f"pii_{lg}"] = build(f"pii_{lg}", compat_model_dir(BN_PII_MODEL if lg == "bn" else EN_PII_MODEL))

json.dump({"bn_label": BN_LABEL, "status": STATUS, "doctor": DOCTOR}, open(OUT / "text.json", "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
md5 = lambda p: hashlib.md5(p.read_bytes()).hexdigest()
files = {str(p.relative_to(OUT)): {"mb": round(p.stat().st_size / 2**20, 2), "md5": md5(p),
                                   "ship": "fp32" not in p.name}
         for p in sorted(OUT.rglob("*")) if p.is_file() and p.name != "manifest.json"}
ship_mb = sum(v["mb"] for v in files.values() if v["ship"])
json.dump({"files": files, "checks": checks, "ship_mb": round(ship_mb, 1)}, open(OUT / "manifest.json", "w"), indent=1)
print(f"\nshipped assets (INT8 models + tokenizers + text): {ship_mb:.0f} MB  -> {OUT}/manifest.json")
