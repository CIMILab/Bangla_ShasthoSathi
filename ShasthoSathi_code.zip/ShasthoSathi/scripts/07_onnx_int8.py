"""Experiment 5: how much accuracy is lost when a fine-tuned E4 model is shrunk for a phone?

Exports runs/<tag>/model to ONNX (FP32), quantizes it to INT8 (dynamic, weights only),
then runs all three versions (PyTorch FP32, ONNX FP32, ONNX INT8) on the CPU over the
Bangla-HealthNER test split, one document at a time (batch 1, like a phone).

Reports: file size (MB), exact-span micro/macro F1, Medicine / Dosage F1, Bangla-script
Medicine recall, tag agreement with FP32, and median / p90 latency per document.

    python scripts/07_onnx_int8.py --tag banglishbert-full-s42
    python scripts/07_onnx_int8.py --tag banglishbert-full-s42 --limit 300 --threads 2   # quick check
"""
import argparse, collections, json, os, pathlib, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
import numpy as np
import torch
from shastho.openmed_adapter import text_script

ap = argparse.ArgumentParser()
ap.add_argument("--tag", required=True, help="folder name under runs/ that has model/ (trained with --save-model)")
ap.add_argument("--runs", default="runs")
ap.add_argument("--data", default="data/raw/Bangla-HealthNER/Dataset")
ap.add_argument("--limit", type=int, default=0, help="first N test docs (0 = all 3,179)")
ap.add_argument("--threads", type=int, default=4, help="CPU threads (a mid-range phone has 4 fast cores)")
ap.add_argument("--max-len", type=int, default=256)
ap.add_argument("--skip-torch", action="store_true", help="skip the PyTorch FP32 pass (saves time)")
a = ap.parse_args()

torch.set_num_threads(a.threads)
from transformers import AutoModelForTokenClassification, AutoTokenizer
import onnxruntime as ort
from onnxruntime.quantization import QuantType, quantize_dynamic

run_dir = pathlib.Path(a.runs) / a.tag
model_dir = run_dir / "model"
assert model_dir.exists(), f"{model_dir} not found: train with --save-model first"
onnx_dir = run_dir / "onnx"; onnx_dir.mkdir(exist_ok=True)
fp32_path, int8_path = onnx_dir / "model_fp32.onnx", onnx_dir / "model_int8.onnx"

tok = AutoTokenizer.from_pretrained(model_dir, use_fast=True)
model = AutoModelForTokenClassification.from_pretrained(model_dir).eval()
labels = [model.config.id2label[i] for i in range(model.config.num_labels)]
types = sorted({l[2:] for l in labels if l != "O"})

# ---------------------------------------------------------------- export + quantize
class Wrap(torch.nn.Module):          # plain tensor in / tensor out, no ModelOutput objects
    def __init__(self, m): super().__init__(); self.m = m
    def forward(self, input_ids, attention_mask): return self.m(input_ids=input_ids, attention_mask=attention_mask).logits


def export():
    ex = tok(["ডাক্তার আমাকে Napa 500 দিয়েছেন"], return_tensors="pt")
    args = (ex["input_ids"], ex["attention_mask"])
    kw = dict(input_names=["input_ids", "attention_mask"], output_names=["logits"], opset_version=17)
    try:      # classic exporter (TorchScript based): simple, well supported by onnxruntime quantization
        torch.onnx.export(Wrap(model).eval(), args, str(fp32_path), dynamo=False,
                          dynamic_axes={"input_ids": {0: "b", 1: "t"}, "attention_mask": {0: "b", 1: "t"},
                                        "logits": {0: "b", 1: "t"}}, **kw)
    except Exception as e:  # newer torch: fall back to the dynamo exporter
        print("classic exporter failed, using dynamo:", repr(e)[:200], flush=True)
        B, T = torch.export.Dim("b", max=64), torch.export.Dim("t", max=a.max_len)
        torch.onnx.export(Wrap(model).eval(), args, str(fp32_path), dynamo=True, external_data=False,
                          dynamic_shapes={"input_ids": {0: B, 1: T}, "attention_mask": {0: B, 1: T}}, **kw)


if not fp32_path.exists():
    t0 = time.time(); export(); print(f"exported FP32 ONNX in {time.time()-t0:.0f}s", flush=True)
model.eval()   # the exporter can switch the model back to training mode (dropout on)
if not int8_path.exists():
    t0 = time.time()
    quantize_dynamic(str(fp32_path), str(int8_path), weight_type=QuantType.QInt8)
    print(f"quantized INT8 in {time.time()-t0:.0f}s", flush=True)
mb = lambda p: sum(f.stat().st_size for f in onnx_dir.glob(p.name + "*")) / 2**20

# ---------------------------------------------------------------- data + metrics (same definition as E4)
rows = json.load(open(pathlib.Path(a.data) / "test.json", encoding="utf-8"))
rows = rows[:a.limit] if a.limit else rows
test = [{"tokens": r["text"].split(), "tags": r["labels"]} for r in rows]
enc = [tok(r["tokens"], is_split_into_words=True, truncation=True, max_length=a.max_len) for r in test]


def seq_spans(tags):
    spans, start, cur = [], None, None
    for i, t in enumerate(list(tags) + ["O"]):
        if t.startswith("B-") or (t.startswith("I-") and t[2:] != cur) or t == "O":
            if cur is not None:
                spans.append((start, i, cur))
            start, cur = (i, t[2:]) if t != "O" else (None, None)
    return spans


def scores(G, P, W):
    per = collections.defaultdict(lambda: [0, 0, 0]); med_bn = [0, 0]
    for g, p, w in zip(G, P, W):
        gs, ps = set(seq_spans(g)), set(seq_spans(p))
        for t in types:
            gt = {x for x in gs if x[2] == t}; pt = {x for x in ps if x[2] == t}
            per[t][0] += len(gt & pt); per[t][1] += len(pt - gt); per[t][2] += len(gt - pt)
        for sp in gs:
            if sp[2] == "Medicine" and text_script(" ".join(w[sp[0]:sp[1]])) == "bn":
                med_bn[1] += 1; med_bn[0] += sp in ps
    f1 = lambda tp, fp, fn: 2 * tp / (2 * tp + fp + fn) if tp else 0.0
    TP, FP, FN = (sum(v[i] for v in per.values()) for i in range(3))
    return {"micro_f1": f1(TP, FP, FN), "macro_f1": float(np.mean([f1(*v) for v in per.values()])),
            "per_type_f1": {t: f1(*v) for t, v in sorted(per.items())},
            "medicine_recall_bangla": med_bn[0] / med_bn[1] if med_bn[1] else None}


def word_tags(r, e, pred):
    tags, prev = ["O"] * len(r["tokens"]), None
    for j, w in enumerate(e.word_ids()):
        if w is not None and w != prev:
            tags[w] = labels[int(pred[j])]
        prev = w
    return tags


def evaluate(name, predict):
    for r, e in zip(test[:5], enc[:5]):   # warm-up
        predict(e)
    P, ms = [], []
    for r, e in zip(test, enc):
        t0 = time.perf_counter(); pred = predict(e); ms.append(1000 * (time.perf_counter() - t0))
        P.append(word_tags(r, e, pred))
    s = scores([r["tags"] for r in test], P, [r["tokens"] for r in test])
    s.update(latency_ms_median=float(np.median(ms)), latency_ms_p90=float(np.percentile(ms, 90)))
    print(f"{name:10s} micro F1 {100*s['micro_f1']:.2f} | Medicine {100*s['per_type_f1'].get('Medicine',0):.2f} "
          f"| median {s['latency_ms_median']:.1f} ms/doc", flush=True)
    return s, P


def torch_predict(e):
    with torch.inference_mode():
        x = {k: torch.tensor([e[k]]) for k in ("input_ids", "attention_mask")}
        return model(**x).logits[0].argmax(-1).numpy()


def ort_predictor(path):
    so = ort.SessionOptions(); so.intra_op_num_threads = a.threads; so.inter_op_num_threads = 1
    sess = ort.InferenceSession(str(path), so, providers=["CPUExecutionProvider"])
    names = {i.name for i in sess.get_inputs()}
    def predict(e):
        feed = {k: np.array([e[k]], dtype=np.int64) for k in ("input_ids", "attention_mask") if k in names}
        return sess.run(None, feed)[0][0].argmax(-1)
    return predict


res, preds = {}, {}
if not a.skip_torch:
    res["torch_fp32"], preds["torch_fp32"] = evaluate("torch_fp32", torch_predict)
res["onnx_fp32"], preds["onnx_fp32"] = evaluate("onnx_fp32", ort_predictor(fp32_path))
res["onnx_int8"], preds["onnx_int8"] = evaluate("onnx_int8", ort_predictor(int8_path))

ref = preds["onnx_fp32"]
for k in res:   # share of words whose tag is unchanged vs FP32 ONNX
    same = sum(a_ == b_ for p, q in zip(preds[k], ref) for a_, b_ in zip(p, q)); n = sum(len(p) for p in ref)
    res[k]["tag_agreement_vs_fp32"] = same / n
res["onnx_fp32"]["size_mb"], res["onnx_int8"]["size_mb"] = mb(fp32_path), mb(int8_path)
res["onnx_int8"]["micro_f1_drop_pts"] = 100 * (res["onnx_fp32"]["micro_f1"] - res["onnx_int8"]["micro_f1"])

import platform
out = {"tag": a.tag, "n_docs": len(test), "threads": a.threads, "cpu": platform.processor() or platform.machine(),
       "onnxruntime": ort.__version__, "results": res}
pathlib.Path("results").mkdir(exist_ok=True)
json.dump(out, open(f"results/e5_{a.tag}.json", "w"), indent=1)
print(f"\nsize FP32 {res['onnx_fp32']['size_mb']:.0f} MB -> INT8 {res['onnx_int8']['size_mb']:.0f} MB | "
      f"F1 drop {res['onnx_int8']['micro_f1_drop_pts']:.2f} pts | agreement {100*res['onnx_int8']['tag_agreement_vs_fp32']:.2f}%")
print(f"wrote results/e5_{a.tag}.json")
