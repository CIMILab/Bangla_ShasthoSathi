"""Experiment 4: fine-tune a token classifier on Bangla-HealthNER (7 entity types).

Full fine-tuning or LoRA, any Hugging Face encoder. Reports entity-level
precision / recall / F1 (exact span + type, the seqeval default) on the official
test split, per type, and recall split by script (Latin vs Bangla) — the gap E2 found.

Published reference: BanglishBERT, F1 56.13 ± 0.75 (Khan et al., Findings of EMNLP 2023).

    python scripts/06_healthner_finetune.py --model csebuetnlp/banglishbert
    python scripts/06_healthner_finetune.py --model xlm-roberta-base --lora
    python scripts/06_healthner_finetune.py --model openmed-bn-pii          # OpenMed Bengali PII backbone
"""
import argparse, collections, json, os, pathlib, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
import numpy as np
import torch
from shastho.openmed_adapter import text_script

ap = argparse.ArgumentParser()
ap.add_argument("--model", required=True, help="HF id, local path, or 'openmed-bn-pii'")
ap.add_argument("--lora", action="store_true")
ap.add_argument("--lora-r", type=int, default=16)
ap.add_argument("--epochs", type=float, default=4)
ap.add_argument("--lr", type=float, default=None, help="default 3e-5 full / 3e-4 LoRA")
ap.add_argument("--bs", type=int, default=32)
ap.add_argument("--max-len", type=int, default=256)
ap.add_argument("--train-limit", type=int, default=0, help="debug: use first N train docs")
ap.add_argument("--eval-limit", type=int, default=0, help="debug: use first N valid/test docs")
ap.add_argument("--seed", type=int, default=42)
ap.add_argument("--data", default="data/raw/Bangla-HealthNER/Dataset")
ap.add_argument("--runs", default="runs")
ap.add_argument("--save-model", action="store_true", help="keep the fine-tuned weights (needed for E5 export)")
a = ap.parse_args()

from transformers import (AutoModelForTokenClassification, AutoTokenizer, DataCollatorForTokenClassification,
                          Trainer, TrainingArguments, set_seed)
set_seed(a.seed)

model_path = a.model
if a.model == "openmed-bn-pii":
    from shastho.openmed_adapter import BN_PII_MODEL, compat_model_dir
    model_path = compat_model_dir(BN_PII_MODEL)
tag = (a.model.split("/")[-1] + ("-lora" if a.lora else "-full") + f"-s{a.seed}")
out_dir = pathlib.Path(a.runs) / tag
out_dir.mkdir(parents=True, exist_ok=True)
lr = a.lr or (3e-4 if a.lora else 3e-5)

# ---------------------------------------------------------------- data
def load(split, limit):
    rows = json.load(open(pathlib.Path(a.data) / f"{split}.json", encoding="utf-8"))
    rows = rows[:limit] if limit else rows
    return [{"tokens": r["text"].split(), "tags": r["labels"]} for r in rows]

train, valid, test = load("train", a.train_limit), load("valid", a.eval_limit), load("test", a.eval_limit)
types = sorted({t[2:] for r in train for t in r["tags"] if t != "O"})
labels = ["O"] + [f"{p}-{t}" for t in types for p in ("B", "I")]
l2i = {l: i for i, l in enumerate(labels)}
print(f"train {len(train)} valid {len(valid)} test {len(test)} | types {types}", flush=True)

tok = AutoTokenizer.from_pretrained(model_path, use_fast=True)
assert tok.is_fast, "a fast tokenizer is required (word_ids)"


def encode(rows):
    enc = tok([r["tokens"] for r in rows], is_split_into_words=True, truncation=True, max_length=a.max_len)
    feats = []
    for i, r in enumerate(rows):
        wids, prev, lab = enc.word_ids(i), None, []
        for w in wids:
            lab.append(-100 if w is None or w == prev else l2i.get(r["tags"][w], 0))
            prev = w
        feats.append({"input_ids": enc["input_ids"][i], "attention_mask": enc["attention_mask"][i], "labels": lab})
    return feats


tr_f, va_f, te_f = encode(train), encode(valid), encode(test)

# ---------------------------------------------------------------- model
model = AutoModelForTokenClassification.from_pretrained(
    model_path, num_labels=len(labels), id2label=dict(enumerate(labels)), label2id=l2i, ignore_mismatched_sizes=True)
n_total = sum(p.numel() for p in model.parameters())
if a.lora:
    from peft import LoraConfig, TaskType, get_peft_model
    linear = {n.split(".")[-1] for n, m in model.named_modules() if isinstance(m, torch.nn.Linear)}
    targets = [x for x in ("query", "value", "query_proj", "value_proj", "q_proj", "v_proj", "q_lin", "v_lin") if x in linear]
    head = [x for x in ("classifier",) if x in linear] or None
    model = get_peft_model(model, LoraConfig(task_type=TaskType.TOKEN_CLS, r=a.lora_r, lora_alpha=2 * a.lora_r,
                                             lora_dropout=0.1, target_modules=targets, modules_to_save=head))
n_train = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"params total {n_total/1e6:.1f}M, trainable {n_train/1e6:.2f}M", flush=True)


# ---------------------------------------------------------------- metrics
def seq_spans(tags):
    """BIO tags -> {(start_word, end_word_exclusive, type)} (an I- without B- starts a span, like seqeval)."""
    spans, start, cur = [], None, None
    for i, t in enumerate(list(tags) + ["O"]):
        if t.startswith("B-") or (t.startswith("I-") and t[2:] != cur) or t == "O":
            if cur is not None:
                spans.append((start, i, cur))
            start, cur = (i, t[2:]) if t != "O" else (None, None)
    return spans


def entity_scores(gold_seqs, pred_seqs, word_seqs=None):
    per = collections.defaultdict(lambda: [0, 0, 0])
    by_script = collections.defaultdict(lambda: [0, 0])
    for k, (g, p) in enumerate(zip(gold_seqs, pred_seqs)):
        gs, ps = set(seq_spans(g)), set(seq_spans(p))
        for t in types:
            gt = {x for x in gs if x[2] == t}; pt = {x for x in ps if x[2] == t}
            per[t][0] += len(gt & pt); per[t][1] += len(pt - gt); per[t][2] += len(gt - pt)
        if word_seqs is not None:  # recall split by the script the gold entity is written in
            for sp in gs:
                key = (sp[2], text_script(" ".join(word_seqs[k][sp[0]:sp[1]])))
                by_script[key][1] += 1
                by_script[key][0] += sp in ps
    out = {}
    for t, (tp, fp, fn) in per.items():
        p = tp / (tp + fp) if tp + fp else 0.0; r = tp / (tp + fn) if tp + fn else 0.0
        out[t] = {"precision": p, "recall": r, "f1": 2 * p * r / (p + r) if p + r else 0.0, "support": tp + fn}
    TP, FP, FN = (sum(v[i] for v in per.values()) for i in range(3))
    P = TP / (TP + FP) if TP + FP else 0.0; R = TP / (TP + FN) if TP + FN else 0.0
    res = {"micro": {"precision": P, "recall": R, "f1": 2 * P * R / (P + R) if P + R else 0.0},
           "macro_f1": float(np.mean([v["f1"] for v in out.values()])), "per_type": out}
    if word_seqs is not None:
        res["recall_by_script"] = {f"{t}|{s}": {"hit": v[0], "total": v[1], "recall": v[0] / v[1]}
                                   for (t, s), v in sorted(by_script.items())}
    return res


def compute_metrics(ev):
    logits, lab = ev
    pred = logits.argmax(-1)
    G, P = [], []
    for pr, lb in zip(pred, lab):
        m = lb != -100
        G.append([labels[i] for i in lb[m]]); P.append([labels[i] for i in pr[m]])
    s = entity_scores(G, P)
    return {"f1": s["micro"]["f1"], "precision": s["micro"]["precision"], "recall": s["micro"]["recall"]}


args = TrainingArguments(
    output_dir=str(out_dir / "ckpt"), per_device_train_batch_size=a.bs, per_device_eval_batch_size=64,
    learning_rate=lr, num_train_epochs=a.epochs, weight_decay=0.01, warmup_ratio=0.1, lr_scheduler_type="linear",
    eval_strategy="epoch", save_strategy="epoch", load_best_model_at_end=True, metric_for_best_model="f1",
    save_total_limit=1, logging_steps=50, report_to=[], seed=a.seed,
    bf16=torch.cuda.is_available(), dataloader_num_workers=2)
trainer = Trainer(model=model, args=args, train_dataset=tr_f, eval_dataset=va_f,
                  data_collator=DataCollatorForTokenClassification(tok), compute_metrics=compute_metrics)
ckpts = sorted((out_dir / "ckpt").glob("checkpoint-*"))   # resume if a previous job was killed mid-training
if ckpts:
    print("resuming from", ckpts[-1], flush=True)
t0 = time.time(); trainer.train(resume_from_checkpoint=bool(ckpts)); train_sec = time.time() - t0

# ---------------------------------------------------------------- test: word-level, truncated words count as "O"
t0 = time.time(); out = trainer.predict(te_f); test_sec = time.time() - t0
pred_ids = out.predictions.argmax(-1)
G, P, W = [], [], []
enc_ids = [tok(r["tokens"], is_split_into_words=True, truncation=True, max_length=a.max_len).word_ids() for r in test]
for r, wids, pr in zip(test, enc_ids, pred_ids):
    tags, prev = ["O"] * len(r["tokens"]), None
    for j, w in enumerate(wids):
        if w is not None and w != prev and j < len(pr):
            tags[w] = labels[pr[j]]
        prev = w
    G.append(r["tags"]); P.append(tags); W.append(r["tokens"])
test_scores = entity_scores(G, P, W)
val_scores = trainer.evaluate()

result = {"model": a.model, "lora": a.lora, "lora_r": a.lora_r if a.lora else None, "seed": a.seed, "lr": lr,
          "epochs": a.epochs, "max_len": a.max_len, "params_total_M": n_total / 1e6, "params_trainable_M": n_train / 1e6,
          "train_minutes": train_sec / 60, "test_ms_per_doc": 1000 * test_sec / max(len(test), 1),
          "valid": val_scores, "test": test_scores, "labels": labels,
          "reference": "BanglishBERT micro F1 56.13 ± 0.75 (Khan et al., 2023)"}
json.dump(result, open(out_dir / "metrics.json", "w"), indent=1, ensure_ascii=False)
if a.save_model:
    m = trainer.model.merge_and_unload() if a.lora else trainer.model
    m.save_pretrained(out_dir / "model"); tok.save_pretrained(out_dir / "model")
import shutil; shutil.rmtree(out_dir / "ckpt", ignore_errors=True)
print(f"\n{tag}: test micro F1 {test_scores['micro']['f1']:.4f} (P {test_scores['micro']['precision']:.3f} "
      f"R {test_scores['micro']['recall']:.3f}) macro F1 {test_scores['macro_f1']:.4f} | train {train_sec/60:.1f} min")
for t, v in sorted(test_scores["per_type"].items()):
    print(f"  {t:18s} F1 {v['f1']:.3f}  (n={v['support']})")
print("wrote", out_dir / "metrics.json")
