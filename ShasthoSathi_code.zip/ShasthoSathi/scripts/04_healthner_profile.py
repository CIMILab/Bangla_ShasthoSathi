"""Profile Bangla-HealthNER: which script are the medical entities written in?

This tells us the ceiling for an English-only model (OpenMed pharma/disease NER):
it can only ever find entities written in Latin script.

    python scripts/04_healthner_profile.py --data data/raw/Bangla-HealthNER/Dataset
"""
import argparse, collections, json, pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from shastho.metrics import bio_to_spans

BN = re.compile(r"[ঀ-৿]")
LAT = re.compile(r"[A-Za-z]")


def script(s):
    b, l = bool(BN.search(s)), bool(LAT.search(s))
    return "mixed" if b and l else "bangla" if b else "latin" if l else "other"


ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data/raw/Bangla-HealthNER/Dataset")
ap.add_argument("--out", default="results/healthner_profile.json")
a = ap.parse_args()

report = {}
for split in ["train", "valid", "test"]:
    rows = json.load(open(pathlib.Path(a.data) / f"{split}.json", encoding="utf-8"))
    by_type = collections.defaultdict(collections.Counter)
    doc_scripts = collections.Counter()
    examples = collections.defaultdict(list)
    for r in rows:
        toks = r["text"].split()
        text = " ".join(toks)
        doc_scripts[script(text)] += 1
        for s, e, lab in bio_to_spans(toks, r["labels"]):
            sc = script(text[s:e])
            by_type[lab][sc] += 1
            if split == "test" and len(examples[(lab, sc)]) < 5:
                examples[(lab, sc)].append(text[s:e])
    report[split] = {
        "documents": len(rows),
        "document_script": dict(doc_scripts),
        "entity_script": {k: dict(v) for k, v in by_type.items()},
    }
    if split == "test":
        report["test_examples"] = {f"{k[0]}|{k[1]}": v for k, v in examples.items()}

pathlib.Path(a.out).parent.mkdir(parents=True, exist_ok=True)
json.dump(report, open(a.out, "w"), ensure_ascii=False, indent=2)

t = report["test"]["entity_script"]
print(f"{'type':20s} {'total':>6s} {'latin':>7s} {'bangla':>7s} {'mixed':>7s}  latin%")
for lab, c in sorted(t.items(), key=lambda x: -sum(x[1].values())):
    n = sum(c.values())
    print(f"{lab:20s} {n:6d} {c.get('latin',0):7d} {c.get('bangla',0):7d} {c.get('mixed',0):7d}  {100*c.get('latin',0)/n:5.1f}")
print("test documents by script:", report["test"]["document_script"])
