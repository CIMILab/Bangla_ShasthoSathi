"""E18: word-level confusion matrix of the shipped medical NER tagger (BanglishBERT, ONNX) on the Bangla-HealthNER
test split. B-/I- are collapsed to the entity type; 'O' is kept as its own class. Also reports entity-level
precision / recall / F1 per type (exact span match, seqeval-style) so the matrix and Table III can be read together.

    python scripts/18_ner_confusion.py                      # INT8 phone model, first sub-token (training scheme)
    python scripts/18_ner_confusion.py --variant fp32
Writes results/e18_ner_confusion.json (read by scripts/19_paper_figures.py).
"""
import argparse, collections, json, pathlib, sys, time
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import numpy as np
from shastho.mobile_ref import OnnxWordTagger

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data/raw/Bangla-HealthNER/Dataset")
ap.add_argument("--model", default="mobile/assets/ner")
ap.add_argument("--variant", default="int8")
ap.add_argument("--agg", default="first", choices=["first", "mean", "max"])
ap.add_argument("--threads", type=int, default=8)
ap.add_argument("--limit", type=int, default=0)
a = ap.parse_args()

rows = json.load(open(ROOT / a.data / "test.json", encoding="utf-8"))
if a.limit:
    rows = rows[:a.limit]
tagger = OnnxWordTagger(ROOT / a.model, threads=a.threads, variant=a.variant)
typ = lambda t: "O" if t == "O" else t[2:]
types = sorted({typ(t) for r in rows for t in r["labels"]} - {"O"})
labels = types + ["O"]
ix = {l: i for i, l in enumerate(labels)}
M = np.zeros((len(labels), len(labels)), dtype=int)


def spans(tags):
    out, start, cur = set(), None, None
    for i, t in enumerate(list(tags) + ["O"]):
        if t == "O" or t.startswith("B-") or (t.startswith("I-") and t[2:] != cur):
            if cur is not None:
                out.add((start, i, cur))
            start, cur = (i, t[2:]) if t != "O" else (None, None)
    return out


tp, fp, fn = collections.Counter(), collections.Counter(), collections.Counter()
t0 = time.time()
for n, r in enumerate(rows):
    words, gold = r["text"].split(), r["labels"]
    pred = [l for l, _ in tagger.word_labels(words, a.agg)]
    for g, p in zip(gold, pred):
        gt, pt = typ(g), typ(p)
        M[ix[gt], ix.get(pt, ix["O"])] += 1
    G, P = spans(gold), spans(pred)
    for s in G & P: tp[s[2]] += 1
    for s in P - G: fp[s[2]] += 1
    for s in G - P: fn[s[2]] += 1
    if n % 500 == 0:
        print(f"{n}/{len(rows)} docs, {time.time() - t0:.0f}s", flush=True)

prf = lambda t, f_p, f_n: (t / max(t + f_p, 1), t / max(t + f_n, 1), 2 * t / max(2 * t + f_p + f_n, 1))
per = {}
for t in types:
    p, r_, f = prf(tp[t], fp[t], fn[t]); per[t] = {"precision": p, "recall": r_, "f1": f, "support": tp[t] + fn[t]}
P_, R_, F_ = prf(sum(tp.values()), sum(fp.values()), sum(fn.values()))
word_acc_ent = np.trace(M[:-1, :-1]) / max(M[:-1].sum(), 1)

print(f"\n{'type':20s} {'P':>6s} {'R':>6s} {'F1':>6s} {'n':>6s}")
for t, v in per.items():
    print(f"{t:20s} {v['precision']:6.3f} {v['recall']:6.3f} {v['f1']:6.3f} {v['support']:6d}")
print(f"{'micro':20s} {P_:6.3f} {R_:6.3f} {F_:6.3f}")
print(f"entity words tagged with the right type: {word_acc_ent:.3f}")
print("\nrow-normalised confusion (%), rows = gold:")
print(" " * 18 + "".join(f"{l[:8]:>9s}" for l in labels))
for i, l in enumerate(labels):
    print(f"{l[:18]:18s}" + "".join(f"{100 * v / max(M[i].sum(), 1):9.1f}" for v in M[i]))

(ROOT / "results").mkdir(exist_ok=True)
json.dump({"model": a.model, "variant": a.variant, "agg": a.agg, "docs": len(rows), "labels": labels,
           "matrix": M.tolist(), "per_type": per, "micro": {"precision": P_, "recall": R_, "f1": F_},
           "entity_word_type_accuracy": word_acc_ent}, open(ROOT / "results/e18_ner_confusion.json", "w"), indent=1)
print("wrote results/e18_ner_confusion.json")
