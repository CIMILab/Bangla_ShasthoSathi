"""E7a: does the phone version of the pipeline still protect privacy? + golden files for the app's tests.

Runs src/shastho/mobile_ref.py (INT8 ONNX, word-level, template explanations) on the 300 held-out
synthetic reports and measures, against the gold annotations:
  leak rate      share of gold personal-detail spans with any visible character (by type)
  lab damage     share of lab values that got redacted          (must be 0)
  med damage     share of gold medicine mentions that got redacted
  over-redaction share of non-personal characters that got hidden
  latency        per report on this CPU (the phone numbers come later, from the app)
for the shipped settings (mobile/assets/pipeline_config.json, chosen in E7b), the same settings with FP32
models, rules alone, and (with --compare-python) for the research pipeline
(openmed package + PyTorch tagger) at 0.3, so the report can state the cost of going mobile.

Writes
  mobile/golden/golden.jsonl      per report: text, spans, redacted text, labs, both templates (+ token ids, first 5)
  mobile/golden/gate_cases.jsonl  LLM outputs from E6c with the gate's decision (for the optional LLM mode)
  results/e7a_mobile.json

    python scripts/13_mobile_golden.py --threads 4
    python scripts/13_mobile_golden.py --threads 4 --compare-python --protect-model runs/banglishbert-full-s42/model
"""
import argparse, collections, glob, json, pathlib, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
import numpy as np
from shastho.explain import gate, template
from shastho.metrics import _content
from shastho.mobile_ref import MobilePipeline, WORD
from shastho.pipeline import Pipeline
from shastho.rules import parse_lab_lines

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data/synthetic/synth_heldout.jsonl")
ap.add_argument("--assets", default="mobile/assets")
ap.add_argument("--threads", type=int, default=4)
ap.add_argument("--limit", type=int, default=0)
ap.add_argument("--compare-python", action="store_true")
ap.add_argument("--protect-model", default="runs/banglishbert-full-s42/model")
ap.add_argument("--device", default="cpu")
a = ap.parse_args()

docs = [json.loads(l) for l in open(a.data, encoding="utf-8")]
docs = docs[: a.limit] if a.limit else docs
print(f"{len(docs)} held-out reports", flush=True)


def score(doc, merged):
    """Compare redaction spans with the gold annotation of one report."""
    text, hidden = doc["text"], np.zeros(len(doc["text"]), bool)
    for s, e, *_ in merged:
        hidden[s:e] = True
    r = collections.Counter()
    gold = np.zeros(len(text), bool)
    for p in doc["pii"]:
        gold[p["start"]:p["end"]] = True
        vis = any(not hidden[i] and _content(text[i]) for i in range(p["start"], p["end"]))   # same rule as E3
        r[f"n_{p['type']}"] += 1; r[f"leak_{p['type']}"] += vis; r["n_pii"] += 1; r["leak"] += vis
    for l in doc["labs"]:
        s, e = l["value_span"]; r["n_lab"] += 1; r["lab_hit"] += bool(hidden[s:e].any())
    for m in doc.get("meds", []):                      # medicine name, strength and dose pattern must stay visible
        for key in ("brand_span", "strength_span", "dose_span"):
            if m.get(key):
                s, e = m[key]; r["n_med"] += 1; r["med_hit"] += bool(hidden[s:e].any())
    other = ~gold & np.array([not c.isspace() for c in text])
    r["n_other"] += int(other.sum()); r["over"] += int((hidden & other).sum())
    return r


def summary(C):
    f = lambda k, n: round(100 * C[k] / C[n], 2) if C[n] else None
    out = {"leak_pct": f("leak", "n_pii"), "lab_damage_pct": f("lab_hit", "n_lab"),
           "med_damage_pct": f("med_hit", "n_med"), "over_redaction_pct": f("over", "n_other")}
    out["leak_by_type"] = {k[2:]: f("leak_" + k[2:], k) for k in sorted(C) if k.startswith("n_") and k[2:].isupper()}
    return out


results, golden, ms = {}, [], collections.defaultdict(list)
# the shipped settings come from mobile/assets/pipeline_config.json (E7b); "fp32" = same settings, unquantized models
for label, kw in (("shipped", {}), ("fp32_same_settings", {"variant": "fp32"})):
    mp = MobilePipeline(a.assets, threads=a.threads, **kw)
    for d in docs[:3]:                                            # warm-up
        mp.analyse(d["text"])
    C = collections.Counter()
    for d in docs:
        t0 = time.perf_counter(); an = mp.analyse(d["text"]); ms[label].append(1000 * (time.perf_counter() - t0))
        red, merged = mp.privacy(d["text"], an)
        C += score(d, merged)
        if label == "shipped":                                    # golden file = exactly what ships
            labs = [l.to_dict() for l in parse_lab_lines(d["text"])]
            g = {"doc_id": d["doc_id"], "text": d["text"], "config": mp.config,
                 "kept": [list(k) for k in an["kept"]], "spans": [list(m) for m in merged], "redacted_text": red,
                 "labs": labs, "lab_rows": Pipeline.lab_rows(d["text"]),
                 "template_bn": template(labs, "bn"), "template_en": template(labs, "en")}
            if len(golden) < 5:                                   # tokenizer + label check for the app
                words = [m.group() for m in WORD.finditer(d["text"])]
                g["debug"] = {"words": words}
                for name, tg in [("ner", mp.tagger)] + [(f"pii_{k}", v) for k, v in mp.pii.items()]:
                    if tg:
                        ids, wid = tg.word_pieces(words)
                        g["debug"][name] = {"ids": ids, "word_ids": wid,
                                            "word_labels": tg.word_labels(words, "first" if name == "ner" else mp.agg)}
            golden.append(g)
    results[label] = summary(C)
    results[label + "_latency_ms"] = {"median": round(float(np.median(ms[label])), 1),
                                      "p90": round(float(np.percentile(ms[label], 90)), 1)}
results["config"] = MobilePipeline(a.assets, use_models=False).config

if a.compare_python:                                              # the research pipeline evaluated in E3b
    p = Pipeline(a.device, openmed=True, protect_model=a.protect_model)
    C = collections.Counter()
    for d in docs:
        _, merged, _ = p.privacy(d["text"]); C += score(d, merged)
    results["python_openmed@0.3"] = summary(C)

for lab, v2 in (("rules_only_v1", False), ("rules_only_v2", True)):
    ro = MobilePipeline(a.assets, use_models=False, rules_v2=v2)
    C = collections.Counter()
    for d in docs:
        C += score(d, ro.privacy(d["text"])[1])
    results[lab] = summary(C)

# ---------------------------------------------------------------- gate cases (optional LLM mode)
by_id, gates = {d["doc_id"]: d for d in docs}, []
for f in sorted(glob.glob("results/e6c/*.jsonl")):
    for line in open(f, encoding="utf-8"):
        r = json.loads(line)
        if r.get("doc_id") in by_id and r.get("model") != "template" and r.get("output"):
            labs = by_id[r["doc_id"]]["labs"]
            labs = [{k: l[k] for k in ("name", "value", "unit", "low", "high", "flag")} for l in labs]
            g = gate(r["output"], labs, r["lang"])
            gates.append({"doc_id": r["doc_id"], "model": r["model"], "lang": r["lang"], "llm_text": r["output"],
                          "labs": labs, "source": g["source"], "blocked_numbers": g["blocked_numbers"],
                          "missing_tests": g.get("missing_tests", [])})

G = pathlib.Path("mobile/golden"); G.mkdir(parents=True, exist_ok=True)
with open(G / "golden.jsonl", "w", encoding="utf-8") as f:
    for g in golden:
        f.write(json.dumps(g, ensure_ascii=False) + "\n")
with open(G / "gate_cases.jsonl", "w", encoding="utf-8") as f:
    for g in gates:
        f.write(json.dumps(g, ensure_ascii=False) + "\n")
json.dump({"n_docs": len(docs), "threads": a.threads, "results": results}, open("results/e7a_mobile.json", "w"), indent=1)

print(f"\n{'system':24s} {'leak%':>6s} {'lab dmg%':>8s} {'med dmg%':>8s} {'over%':>6s}")
for k, v in results.items():
    if "leak_pct" in v:
        print(f"{k:24s} {v['leak_pct']!s:>6s} {v['lab_damage_pct']!s:>8s} {v['med_damage_pct']!s:>8s} {v['over_redaction_pct']!s:>6s}")
for k, v in results.items():
    if "latency" in k:
        print(f"{k}: median {v['median']} ms, p90 {v['p90']} ms per report ({a.threads} CPU threads)")
print("leaks by type (shipped):", results["shipped"]["leak_by_type"])
print("config:", results["config"])
print(f"wrote {G}/golden.jsonl ({len(golden)}), {G}/gate_cases.jsonl ({len(gates)}), results/e7a_mobile.json")
