"""Create the synthetic test set (300 documents) with gold labels.

    python scripts/01_make_synthetic.py --out data/synthetic/synth_v1.jsonl
"""
import argparse, collections, json, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from shastho.synth import generate, write_jsonl

ap = argparse.ArgumentParser()
ap.add_argument("--out", default="data/synthetic/synth_v1.jsonl")
ap.add_argument("--seed", type=int, default=42)
ap.add_argument("--vocab", default="dev", choices=["dev", "heldout"])
a = ap.parse_args()

docs = generate(n_lab=100, n_rx_mixed=100, n_rx_en=40, n_bn=60, seed=a.seed, vocab=a.vocab)
pathlib.Path(a.out).parent.mkdir(parents=True, exist_ok=True)
write_jsonl(docs, a.out)

stats = {
    "documents": collections.Counter(d["doc_type"] + ":" + d["lang"] for d in docs),
    "pii_spans": collections.Counter(p["type"] for d in docs for p in d["pii"]),
    "lab_rows": sum(len(d["labs"]) for d in docs),
    "lab_flags": collections.Counter(l["flag"] for d in docs for l in d["labs"]),
    "medicines": sum(len(d["meds"]) for d in docs),
}
print(json.dumps(stats, indent=2, ensure_ascii=False))
json.dump(stats, open(pathlib.Path(a.out).with_suffix(".stats.json"), "w"), indent=2, ensure_ascii=False)
