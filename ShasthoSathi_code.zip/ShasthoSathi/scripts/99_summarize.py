"""Print the Week 7 tables in the terminal and write results/bundle_week7.json + results/week7_summary.md.

    python scripts/99_summarize.py
"""
import glob, json, os, pathlib, time

ROOT = pathlib.Path(__file__).resolve().parents[1]
os.chdir(ROOT)
lines = [f"# Week 7 summary ({time.strftime('%Y-%m-%d %H:%M')})", ""]


def table(header, rows):
    w = [max(len(str(x)) for x in col) for col in zip(header, *rows)]
    fmt = lambda r: "| " + " | ".join(str(x).ljust(n) for x, n in zip(r, w)) + " |"
    out = [fmt(header), "|" + "|".join("-" * (n + 2) for n in w) + "|"] + [fmt(r) for r in rows]
    print("\n".join(out)); lines.extend(out + [""])


f3 = lambda x: "—" if x is None else f"{x:.3f}"
bundle = {}

# ---------------- E3
if pathlib.Path("results/exp3_pii_hybrid.json").exists():
    e3 = json.load(open("results/exp3_pii_hybrid.json"))
    s = e3["summary"]; bundle["e3"] = s; bundle["e3_all"] = e3["all"]; bundle["e3_sizes"] = e3["sizes"]
    lines.append(f"## E3 hybrid de-identification (thresholds chosen on dev: {s['chosen_threshold']})"); lines.append("")
    print(f"\nE3 — thresholds chosen on dev: {s['chosen_threshold']}  sizes: {e3['sizes']}")
    for split, rep in s["report"].items():
        print(f"\n[{split}]"); lines.append(f"### {split}")
        rows = [[m, f3(v["span_leak_rate"]), f"[{f3(v['ci95'][0])}, {f3(v['ci95'][1])}]", f3(v["leak_without_facility"]),
                 f3(v["docs_with_any_leak"]), f3(v["clinical_over_redaction"])]
                for m, v in rep.items() if m != "hybrid_minus_model"]
        table(["mode", "span leak", "95% CI", "leak w/o facility", "docs ≥1 leak", "over-redaction"], rows)
        if "hybrid_minus_model" in rep:
            p = rep["hybrid_minus_model"]
            msg = (f"hybrid − model: {p['diff']:+.3f} [{p['ci95'][0]:+.3f}, {p['ci95'][1]:+.3f}]; McNemar on 'any leak': "
                   f"only model leaks {p['mcnemar_b_only_first_leaks']}, only hybrid leaks {p['mcnemar_c_only_second_leaks']}")
            print(msg); lines += [msg, ""]
else:
    print("E3: results/exp3_pii_hybrid.json not found yet")

# ---------------- E4
runs = {}
for f in sorted(glob.glob("runs/*/metrics.json")):
    m = json.load(open(f)); m.pop("labels", None); runs[pathlib.Path(f).parent.name] = m
bundle["e4"] = runs
if runs:
    lines.append("## E4 fine-tuning on Bangla-HealthNER (test split; reference BanglishBERT F1 56.13 ± 0.75)"); lines.append("")
    print("\nE4 — test split (reference: BanglishBERT micro F1 56.13 ± 0.75)")
    rows = []
    for tag, m in sorted(runs.items(), key=lambda kv: -kv[1]["test"]["micro"]["f1"]):
        t = m["test"]; rs = t.get("recall_by_script", {})
        rows.append([tag, f"{100*t['micro']['f1']:.2f}", f"{100*t['micro']['precision']:.1f}", f"{100*t['micro']['recall']:.1f}",
                     f"{100*t['macro_f1']:.2f}", f3(t["per_type"].get("Medicine", {}).get("f1")),
                     f3(rs.get("Medicine|bn", {}).get("recall")), f3(rs.get("Medicine|en", {}).get("recall")),
                     f3(t["per_type"].get("Dosage", {}).get("f1")),
                     f"{m['params_trainable_M']:.1f}/{m['params_total_M']:.0f}", f"{m['train_minutes']:.1f}"])
    table(["run", "micro F1", "P", "R", "macro F1", "Medicine F1", "Med R (Bangla)", "Med R (Latin)", "Dosage F1",
           "trainable/total M", "train min"], rows)
else:
    print("E4: no runs/*/metrics.json yet")

failed = sorted(pathlib.Path(p).stem.replace("e4_", "") for p in glob.glob("logs/e4_*.log")
                if not pathlib.Path("runs", pathlib.Path(p).stem.replace("e4_", ""), "metrics.json").exists())
if failed:
    msg = f"Not finished / failed: {failed} — see logs/e4_<name>.log"; print("\n" + msg); lines.append(msg)

json.dump(bundle, open("results/bundle_week7.json", "w"), indent=1, ensure_ascii=False)
pathlib.Path("results/week7_summary.md").write_text("\n".join(lines), encoding="utf-8")
print("\nwrote results/bundle_week7.json and results/week7_summary.md")
