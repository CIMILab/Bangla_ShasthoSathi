"""Experiment 2: can OpenMed's English clinical NER find medicines and conditions?

(a) Synthetic prescriptions/notes: recall of Bangladeshi brand names (Napa, Seclo...).
(b) Bangla-HealthNER test split (real Bengali health text): recall of gold
    Medicine / Health Condition spans, broken down by script (Latin vs Bangla).

A prediction counts as a hit if it overlaps the gold span (label names differ
between OpenMed and the gold sets, so we score by overlap only).

    python scripts/03_ner_baseline.py --device cuda --limit-healthner 0
"""
import argparse, collections, json, pathlib, statistics, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from shastho.metrics import bio_to_spans
from shastho.openmed_adapter import OpenMedRunner, text_script

ap = argparse.ArgumentParser()
ap.add_argument("--synth", default="data/synthetic/synth_v1.jsonl")
ap.add_argument("--healthner", default="data/raw/Bangla-HealthNER/Dataset/test.json")
ap.add_argument("--pharma-models", nargs="+", default=["pharma_detection_supermedical", "pharma_detection_superclinical"])
ap.add_argument("--disease-model", default="disease_detection_superclinical")
ap.add_argument("--device", default="cpu")
ap.add_argument("--limit-healthner", type=int, default=0, help="0 = all 3,179 test docs")
ap.add_argument("--out", default="results/exp2_ner.json")
a = ap.parse_args()

runner = OpenMedRunner(a.device)


def overlaps(g, preds):
    return any(p[0] < g[1] and g[0] < p[1] for p in preds)


def score(items):
    """items: list of (hit:bool, group:str)."""
    by = collections.defaultdict(lambda: [0, 0])
    for hit, grp in items:
        by[grp][0] += hit; by[grp][1] += 1
        by["ALL"][0] += hit; by["ALL"][1] += 1
    return {k: {"hit": v[0], "total": v[1], "recall": v[0] / v[1] if v[1] else None} for k, v in by.items()}


results = {"args": vars(a)}

# ---------------- (a) synthetic
synth = [json.loads(l) for l in open(a.synth, encoding="utf-8")]
synth = [d for d in synth if d["meds"]]
for model in a.pharma_models:
    runner.ner("Paracetamol 500 mg twice daily", model)  # warm up
    items, times, n_pred, n_fp = [], [], 0, 0
    for d in synth:
        preds, dt = runner.ner(d["text"], model)
        times.append(dt)
        gold = [tuple(m["brand_span"]) for m in d["meds"]]
        clinical = gold + [tuple(m["strength_span"]) for m in d["meds"] if m["strength_span"]]
        n_pred += len(preds)
        n_fp += sum(1 for p in preds if not any(p[0] < g[1] and g[0] < p[1] for g in clinical))
        items += [(overlaps(g, preds), f'{d["doc_type"]}:{d["lang"]}') for g in gold]
    results[f"synthetic_brand_recall|{model}"] = {
        "recall": score(items), "predicted": n_pred, "predicted_outside_any_drug": n_fp,
        "median_sec_per_doc": statistics.median(times)}
    print(model, "synthetic brand recall:", {k: round(v["recall"], 3) for k, v in score(items).items()})

# ---------------- (b) Bangla-HealthNER
rows = json.load(open(a.healthner, encoding="utf-8"))
if a.limit_healthner:
    rows = rows[: a.limit_healthner]
targets = {m: "Medicine" for m in a.pharma_models}
targets[a.disease_model] = "Health Condition"
for model, gold_type in targets.items():
    items, times = [], []
    for r in rows:
        toks = r["text"].split()
        gold = [(s, e) for s, e, lab in bio_to_spans(toks, r["labels"]) if lab == gold_type]
        if not gold:
            continue
        text = " ".join(toks)
        preds, dt = runner.ner(text, model)
        times.append(dt)
        items += [(overlaps(g, preds), text_script(text[g[0]:g[1]])) for g in gold]
    results[f"healthner_{gold_type}_recall|{model}"] = {"recall": score(items), "median_sec_per_doc": statistics.median(times)}
    print(model, f"HealthNER {gold_type} recall by script:", {k: round(v["recall"], 3) for k, v in score(items).items()})

results["time"] = time.strftime("%Y-%m-%d %H:%M")
pathlib.Path(a.out).parent.mkdir(parents=True, exist_ok=True)
json.dump(results, open(a.out, "w"), indent=2, ensure_ascii=False)
print("wrote", a.out)
