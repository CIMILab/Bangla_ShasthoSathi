package org.shastho.models

import org.junit.Assume.assumeTrue
import org.junit.Assert.assertTrue
import org.junit.Test
import org.shastho.core.PhonePipeline
import org.shastho.core.PipelineConfig
import java.io.File

/**
 * Optional laptop check before the phone: the same Kotlin model code on desktop ONNX Runtime, against the golden
 * files from scripts/20_web_golden.py.   ./gradlew :models:test -Passets=/path/to/mobile/assets
 * Skipped when no folder is given.
 */
class ModelsGoldenTest {
    private val root = File(System.getProperty("assets") ?: "")

    @Test fun tokenizerAndLabelsMatchPython() {
        assumeTrue("pass -Passets=/path/to/mobile/assets", root.isDirectory)
        val cfgFile = File(root, "pipeline_config.json")
        val cfg = if (cfgFile.exists()) PipelineConfig.fromJson(cfgFile.readText()) else PipelineConfig()
        ModelSet.load(root, cfg).use { set ->
            println("models: " + set.summary())
            val results = set.all.map { it.goldenCheck(if (it.name == "ner") "first" else cfg.agg) }
            results.forEach { println(it.describe()) }
            val p = PhonePipeline(cfg, set.ner?.core, set.pii.mapValues { it.value.core })
            println("example: " + p.run("রোগী: রহিম উদ্দিন, মোবাইল 01712345678\nHemoglobin 9.1 g/dL 12.0-15.5").redactedText)
            assertTrue(results.joinToString("\n") { it.describe() }, results.all { it.tokDiff == 0 })
        }
    }
}
