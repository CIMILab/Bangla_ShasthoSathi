package org.shastho.models

import ai.djl.huggingface.tokenizers.HuggingFaceTokenizer
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import org.shastho.core.Json
import org.shastho.core.ModelGolden
import org.shastho.core.PipelineConfig
import org.shastho.core.WordTaggerCore
import java.io.File
import java.nio.LongBuffer

/**
 * Port of the model half of src/shastho/mobile_ref.py (OnnxWordTagger): one folder per model with
 *   meta.json       labels, cls_id, sep_id, max_len, stride
 *   tokenizer.json  the exported Hugging Face tokenizer
 *   model_<variant>.onnx
 * Windows, softmax and word aggregation are in :core (WordTaggerCore, already identical to Python); this file only
 * supplies `encode` (tokenizer) and `logits` (ONNX Runtime).
 */
class OnnxWordModel(val name: String, val dir: File, val variant: String, threads: Int = 4) : AutoCloseable {
    private val meta = Json.parse(File(dir, "meta.json").readText()) as Map<*, *>
    val labels: List<String> = (meta["labels"] as List<*>).map { it as String }
    val modelFile = File(dir, "model_$variant.onnx")

    // Same settings as Python: tokenizer.no_truncation(); no_padding(); each word encoded without special tokens.
    private val tok: HuggingFaceTokenizer = HuggingFaceTokenizer.newInstance(
        File(dir, "tokenizer.json").toPath(),
        mapOf("addSpecialTokens" to "false", "truncation" to "false", "padding" to "false"))

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession = OrtSession.SessionOptions().use { so ->
        so.setIntraOpNumThreads(threads); so.setInterOpNumThreads(1)       // mobile_ref.py: intra = threads, inter = 1
        env.createSession(modelFile.absolutePath, so)                        // from the file: weights stay out of the Java heap
    }
    private val inputs: Set<String> = session.inputNames

    fun encode(word: String): IntArray = tok.encode(word, false, false).ids.map { it.toInt() }.toIntArray()

    /** One window [CLS] ... [SEP] -> logits per token (rows = tokens, columns = labels). */
    fun logits(ids: IntArray): Array<FloatArray> {
        val n = ids.size.toLong(); val shape = longArrayOf(1, n)
        val tensors = LinkedHashMap<String, OnnxTensor>()
        try {
            tensors["input_ids"] = OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(ids.size) { ids[it].toLong() }), shape)
            if ("attention_mask" in inputs) tensors["attention_mask"] = OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(ids.size) { 1L }), shape)
            if ("token_type_ids" in inputs) tensors["token_type_ids"] = OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(ids.size)), shape)
            session.run(tensors).use { out ->
                val t = out.get(0) as OnnxTensor
                val buf = t.floatBuffer; val k = labels.size
                return Array(ids.size) { j -> FloatArray(k) { c -> buf.get(j * k + c) } }
            }
        } finally {
            tensors.values.forEach { it.close() }
        }
    }

    val core = WordTaggerCore(labels, (meta["cls_id"] as Number).toInt(), (meta["sep_id"] as Number).toInt(),
        (meta["max_len"] as Number).toInt(), (meta["stride"] as Number).toInt(), ::encode, ::logits)

    /** Compare with Python using the golden files next to the model (if scripts/20_web_golden.py wrote them). */
    fun goldenCheck(mode: String): ModelGolden.Result = ModelGolden.check(name, mode, ::encode, core,
        File(dir, "tok_golden.json").takeIf { it.exists() }?.readText(),
        File(dir, "model_golden.json").takeIf { it.exists() }?.readText())

    override fun close() { session.close(); tok.close() }
}

/** The three models together, as PhonePipeline needs them. */
class ModelSet(val ner: OnnxWordModel?, val pii: Map<String, OnnxWordModel>, val loadMs: Long) : AutoCloseable {
    val all get() = listOfNotNull(ner) + pii.values
    val bytes get() = all.sumOf { it.modelFile.length() + File(it.dir, "tokenizer.json").length() }
    fun summary() = all.joinToString(", ") { "${it.name}=${it.variant}" } +
        " · %.0f MB · loaded in %.1f s".format(bytes / 1048576.0, loadMs / 1000.0)
    override fun close() = all.forEach { it.close() }

    companion object {
        val NAMES = listOf("ner", "pii_bn", "pii_en")
        val OPTIONAL = listOf("tok_golden.json", "model_golden.json")

        fun variantFor(name: String, c: PipelineConfig) = if (name == "ner") c.nerVariant else c.piiVariant.getValue(name.removePrefix("pii_"))

        /** Files the app needs per model folder (golden files are optional, for the self-test). */
        fun needed(name: String, c: PipelineConfig) = listOf("meta.json", "tokenizer.json", "model_${variantFor(name, c)}.onnx")

        /** Which models in `root` are complete. */
        fun available(root: File, c: PipelineConfig) = NAMES.filter { n -> needed(n, c).all { File(root, "$n/$it").isFile } }

        /** Loads every complete model folder under `root` (root/ner, root/pii_bn, root/pii_en). */
        fun load(root: File, c: PipelineConfig, threads: Int = 4): ModelSet {
            val t0 = System.currentTimeMillis()
            val m = available(root, c).associateWith { OnnxWordModel(it, File(root, it), variantFor(it, c), threads) }
            return ModelSet(m["ner"], m.filterKeys { it != "ner" }.mapKeys { it.key.removePrefix("pii_") }, System.currentTimeMillis() - t0)
        }
    }
}
