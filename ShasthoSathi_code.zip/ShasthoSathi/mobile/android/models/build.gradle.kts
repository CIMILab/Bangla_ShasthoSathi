// The three privacy models on ONNX Runtime + the Hugging Face tokenizer (DJL bindings to the same Rust library
// Python uses). Plain JVM code: the Android app supplies the Android builds of both libraries at runtime, and the
// JVM test below runs the same code on a laptop against the server's golden files:
//   ./gradlew :models:test -Passets=/path/to/mobile/assets
plugins { id("org.jetbrains.kotlin.jvm") }

java { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }

val ortVersion = "1.20.0"
val djlVersion = "0.33.0"

dependencies {
    api(project(":core"))
    compileOnly("com.microsoft.onnxruntime:onnxruntime:$ortVersion")     // Android: onnxruntime-android (same API)
    compileOnly("ai.djl.huggingface:tokenizers:$djlVersion")              // Android: + ai.djl.android:tokenizer-native
    testImplementation("com.microsoft.onnxruntime:onnxruntime:$ortVersion")
    testImplementation("ai.djl.huggingface:tokenizers:$djlVersion")
    testImplementation("junit:junit:4.13.2")
}

tasks.test {
    systemProperty("assets", (findProperty("assets") ?: "").toString())
    testLogging { events("passed", "failed", "skipped"); showStandardStreams = true }
}
