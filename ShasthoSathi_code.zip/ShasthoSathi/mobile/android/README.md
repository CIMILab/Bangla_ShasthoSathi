# ShasthoSathi app (Android, Kotlin + Jetpack Compose)

v0.1 = rules + templates on the phone (privacy header rules v1+v2, lab flags, Bengali/English explanations).
v0.2 = + camera / gallery and on-phone text reading (ML Kit Latin + Tesseract ben+eng), row rebuilding for lab
tables, a "check the text" step, and the E8 photo test (see ../eval/README.md).
v0.3 = redesigned interface (splash, Bengali / English UI, charts).
v0.4 = the three privacy models on the phone: ONNX Runtime for Android + the Hugging Face tokenizer (DJL bindings to
the same Rust library as Python), loaded once from a folder the user picks (Settings -> Privacy models).
The app declares **no internet permission** and no camera permission (the phone's camera app takes the photo).

```
android/
  core/   pure Kotlin port of the Python pipeline (no Android code) + golden tests against Python
  models/ ONNX Runtime + tokenizer glue for the three models (plain JVM; optional laptop test against the server)
  app/    Compose UI: Report -> Private -> Results -> Explain, plus Speed test and Self-test (E7)
```

`core/.../Generated.kt` is generated from the Python sources by `tools/gen_kotlin.py`; the golden files in
`core/src/test/resources/golden` by `scripts/15_core_golden.py`. Do not edit either by hand.

## Windows: build and run on the phone
1. Install **Android Studio** (default options; it installs the Android SDK).
2. Unzip this folder, e.g. to `C:\Users\<you>\ShasthoSathi\android`.
3. Android Studio -> **Open** -> choose the `android` folder (the one with `settings.gradle.kts`).
   Wait for "Gradle sync" to finish (first time downloads 1-2 GB). If it offers to upgrade the Android Gradle
   plugin, you can accept or postpone.
4. Check the Kotlin core against Python: right-click `core/src/test/.../GoldenTest` -> **Run 'GoldenTest'**
   (expect: 6 tests passed). Terminal alternative: `.\gradlew.bat :core:test` (needs JAVA_HOME = Android Studio's `jbr`).
5. Phone: Settings -> About phone -> Software information -> tap **Build number** 7 times ->
   Settings -> **Developer options** -> **USB debugging** on. Connect the USB cable, accept "Allow USB debugging".
6. In Android Studio pick the Samsung in the device list at the top and press **Run** (green triangle).
7. In the app: pick a sample -> **Make private & explain** -> look at the four tabs.
   Then **Self-test** (expect `ALL IDENTICAL`) and **Speed test**; press **Copy** and paste the text into the chat.

## v0.4: privacy models on the phone
1. **Hellbender** (repo root): `sbatch slurm/phone_models.sbatch`. It runs `scripts/20_web_golden.py` (golden files
   for the on-phone check) and `scripts/23_phone_bundle.py`, which collects only the needed files (~700 MB) into
   `results/phone_models/ShasthoSathi/`.
2. **Laptop** (PowerShell): `scp -r <user>@hellbender-login.rnet.missouri.edu:/cluster/pixstor/data/<user>/shasthosathi/results/phone_models/ShasthoSathi .`
3. **Phone**: connect by USB, choose *File transfer*, copy the `ShasthoSathi` folder into the phone's `Download` folder.
4. **Android Studio**: open this folder, Gradle sync (downloads ONNX Runtime and the tokenizer once), Run on the S23.
5. **App**: Settings -> **Load privacy models** -> pick `Download/ShasthoSathi` -> *Use this folder* -> *Allow*.
   The models are copied into the app (about a minute) and loaded; the card then says *Active: 3 models*.
   You can delete the copy in `Download` afterwards.
6. Settings -> Research tools -> **Self-test** and **Speed test** -> Copy -> paste into the chat.
   The self-test now also compares each model's tokenizer ids and word labels with Python.

Optional, before the phone: the same model code on the laptop's desktop ONNX Runtime:
`.\gradlew.bat :models:test -Passets=C:\path\to\ShasthoSathi` (prints the same check as the phone).
