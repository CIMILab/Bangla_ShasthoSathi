package org.shastho.core

import kotlin.math.abs

/** One word read from a photo, with its box in image pixels. `line` = the engine's own line id (-1 if unknown). */
data class OcrWord(val text: String, val left: Float, val top: Float, val right: Float, val bottom: Float, val line: Int = -1) {
    val cx get() = (left + right) / 2
    val cy get() = (top + bottom) / 2
    val h get() = bottom - top
}

/**
 * Rebuilds text rows from word boxes. OCR engines often return a lab table column by column
 * (all test names, then all values), which breaks the "test value unit range" rows the parser needs.
 * Steps: estimate page tilt from the engine's lines, undo it, group words whose centres sit at the same
 * height into one row, order each row left to right, and keep wide gaps as 3 spaces (like the printed table).
 */
object OcrLayout {
    private fun median(xs: List<Float>) = xs.sorted().let { if (it.isEmpty()) 0f else it[it.size / 2] }

    fun slope(words: List<OcrWord>): Float {
        val s = words.filter { it.line >= 0 }.groupBy { it.line }.values.filter { it.size >= 2 }.mapNotNull { ln ->
            val a = ln.minBy { it.cx }; val b = ln.maxBy { it.cx }
            if (b.cx - a.cx > 3 * a.h) (b.cy - a.cy) / (b.cx - a.cx) else null
        }
        return median(s)
    }

    fun toText(words: List<OcrWord>): String {
        val ws = words.filter { it.text.isNotBlank() }
        if (ws.isEmpty()) return ""
        val k = slope(ws)
        val h = median(ws.map { it.h }).coerceAtLeast(1f)
        val y = { w: OcrWord -> w.cy - k * w.cx }
        val rows = ArrayList<MutableList<OcrWord>>(); val rowY = ArrayList<Float>()
        for (w in ws.sortedBy(y)) {
            val i = rowY.lastIndex
            if (i >= 0 && abs(y(w) - rowY[i]) < 0.55f * h) {
                rows[i].add(w); rowY[i] = rows[i].map(y).average().toFloat()
            } else { rows.add(mutableListOf(w)); rowY.add(y(w)) }
        }
        return rows.joinToString("\n") { row ->
            val r = row.sortedBy { it.left }
            buildString {
                r.forEachIndexed { i, w ->
                    if (i > 0) append(if (w.left - r[i - 1].right > 1.2f * h) "   " else " ")
                    append(w.text)
                }
            }
        }
    }
}

/** E8 metrics, mirror of src/shastho/ocr_eval.py (golden-tested). */
object OcrEval {
    private val WS = Generated.SPACES

    fun norm(t: String): String = Py.strip(WS.replace(Generated.OCR_ID_LINE.replace(t, ""), " "))

    fun levenshtein(a0: String, b0: String): Int {
        val (a, b) = if (a0.length < b0.length) b0 to a0 else a0 to b0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] != b[j - 1]) 1 else 0)
            prev = cur
        }
        return prev[b.length]
    }

    fun cer(ref: String, hyp: String): Double { val r = norm(ref); return levenshtein(r, norm(hyp)).toDouble() / maxOf(1, r.length) }

    data class Labs(val goldRows: Int, val rowsExact: Int, val flagsCorrect: Int, val spurious: Int)

    fun labScores(gold: List<LabResult>, hyp: String): Labs {
        val got = Rules.parseLabLines(hyp)
        val key = { n: String -> WS.replace(Py.strip(n), " ").lowercase() }
        val used = HashSet<Int>(); var exact = 0; var flags = 0
        for (g in gold) {
            val j = got.indices.firstOrNull { it !in used && key(got[it].name) == key(g.name) } ?: continue
            used.add(j); val h = got[j]
            if (h.value == g.value && h.unit == g.unit && h.low == g.low && h.high == g.high) exact++
            if (h.flag == g.flag) flags++
        }
        return Labs(gold.size, exact, flags, got.size - used.size)
    }

    data class Leak(val pii: Int, val leaked: Int, val leakedItems: List<String>)

    fun leakScores(pii: List<String>, redacted: String): Leak {
        val visible = Generated.OCR_TOKEN.findAll(redacted).map { it.value }.toSet()
        val leaked = pii.filter { p -> Generated.OCR_TOKEN.findAll(p).any { it.value.length >= 3 && it.value in visible } }
        return Leak(pii.size, leaked.size, leaked)
    }
}
