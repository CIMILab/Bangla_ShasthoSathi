package org.shastho.core

/** Port of src/shastho/rules.py (lab rows, flags, number check). */
data class LabResult(
    val name: String, val value: Double, val unit: String,
    val low: Double?, val high: Double?, val flag: String, val line: Int?,
)

object Rules {
    fun flagValue(value: Double, low: Double?, high: Double?): String = when {
        low == null && high == null -> "unknown"
        low != null && value < low -> "low"
        high != null && value > high -> "high"
        else -> "normal"
    }

    private fun f(x: String?): Double? = x?.let { Py.toAsciiDigits(it).replace(",", ".").toDouble() }

    /** Pull 'test value unit range' rows out of a report and flag each one. */
    fun parseLabLines(text: String): List<LabResult> {
        val out = ArrayList<LabResult>()
        Py.splitlines(text).forEachIndexed { idx, raw ->
            val m = Generated.LAB_LINE.find(raw) ?: return@forEachIndexed     // pattern is anchored ^...$ like re.match
            val gr = m.groups
            var lo = f(gr["lo"]?.value); var hi = f(gr["hi"]?.value)
            gr["lt"]?.let { lo = null; hi = f(it.value) }
            gr["gt"]?.let { lo = f(it.value); hi = null }
            val v = f(gr["val"]!!.value)!!
            out.add(LabResult(Py.strip(gr["name"]!!.value), v, gr["unit"]!!.value, lo, hi, flagValue(v, lo, hi), idx + 1))
        }
        return out
    }

    fun numbersIn(text: String): List<String> =
        Generated.ANY_NUM.findAll(text).map { Py.toAsciiDigits(it.value).replace(",", ".") }.toList()

    /** Numbers in `generated` that never appear in `source` (9.8 == 9.80 == ৯.৮). Empty list = passes. */
    fun unsupportedNumbers(generated: String, source: String): List<String> {
        val ok = numbersIn(source).map { it.toDouble() }.toSet()
        return numbersIn(generated).filter { it.toDouble() !in ok }
    }
}
