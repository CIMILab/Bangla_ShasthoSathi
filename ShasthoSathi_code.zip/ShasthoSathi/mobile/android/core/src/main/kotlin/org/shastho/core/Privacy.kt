package org.shastho.core

import kotlin.math.exp

/** A character span [start, end) with a label. */
data class Span(val start: Int, val end: Int, val label: String = "PII")

/** Port of the privacy parts of pipeline.py, protect.py, pii_rules.py and mobile_ref.py. */
object Privacy {
    /** pii_rules.rule_spans */
    fun ruleSpans(text: String, v2: Boolean): List<Span> {
        val out = ArrayList<Span>()
        for (r in Generated.RULES_V1 + (if (v2) Generated.RULES_V2 else emptyList())) {
            for (m in r.rx.findAll(text)) {
                val g = m.groups[r.group] ?: continue
                val s = g.range.first; val e = g.range.last + 1
                if (e > s) out.add(Span(s, e, r.label))
            }
        }
        return out
    }

    /** pipeline._merge: sort by (start, end, label), join overlapping spans, keep the first label. */
    fun merge(spans: List<Span>): List<Span> {
        val out = ArrayList<Span>()
        for (sp in spans.sortedWith(compareBy<Span>({ it.start }, { it.end }, { it.label }))) {
            val last = out.lastOrNull()
            if (last != null && sp.start <= last.end) out[out.size - 1] = Span(last.start, maxOf(last.end, sp.end), last.label)
            else out.add(sp)
        }
        return out
    }

    /** protect.subtract: cut every hole out of every span. */
    fun subtract(spans: List<Pair<Int, Int>>, holes: List<Pair<Int, Int>>): List<Pair<Int, Int>> {
        val hs = holes.sortedWith(compareBy({ it.first }, { it.second }))
        val out = ArrayList<Pair<Int, Int>>()
        for ((s, e) in spans) {
            var pieces = listOf(s to e)
            for ((a, b) in hs) {
                val nxt = ArrayList<Pair<Int, Int>>()
                for ((ps, pe) in pieces) {
                    if (b <= ps || a >= pe) { nxt.add(ps to pe); continue }
                    if (ps < a) nxt.add(ps to a)
                    if (b < pe) nxt.add(b to pe)
                }
                pieces = nxt
            }
            out.addAll(pieces.filter { it.second > it.first })
        }
        return out
    }

    /** pipeline._trim: strip whitespace/punctuation at the edges; drop pieces with nothing else. */
    fun trim(text: String, spans: List<Pair<Int, Int>>): List<Pair<Int, Int>> {
        fun skip(c: Char) = Py.isSpace(c) || c in Generated.TRIM_PUNCT
        val out = ArrayList<Pair<Int, Int>>()
        for ((s0, e0) in spans) {
            var s = s0; var e = e0
            while (s < e && skip(text[s])) s++
            while (e > s && skip(text[e - 1])) e--
            if (e > s) out.add(s to e)
        }
        return out
    }

    /** Pipeline.lab_rows: spans of lines that parse as lab rows (never redacted by the models). */
    fun labRows(text: String): List<Pair<Int, Int>> {
        val wanted = Rules.parseLabLines(text).mapNotNull { it.line }.toSet()
        val rows = ArrayList<Pair<Int, Int>>(); var pos = 0
        Py.splitlines(text, keepends = true).forEachIndexed { i, ln ->
            if ((i + 1) in wanted) rows.add(pos to pos + ln.trimEnd('\n').length)
            pos += ln.length
        }
        return rows
    }

    /** mobile_ref.route: English model for Latin-only text, Bengali for Bangla-only, both if mixed. */
    fun route(text: String): List<String> {
        val b = Generated.BN_CHAR.containsMatchIn(text); val l = Generated.LAT_CHAR.containsMatchIn(text)
        return if (b && l) listOf("en", "bn") else if (b) listOf("bn") else listOf("en")
    }

    data class Entity(val start: Int, val end: Int, val type: String, val score: Double)

    /** mobile_ref.group: consecutive words with the same type -> one entity; 'B-' starts a new one. */
    fun group(spans: List<Pair<Int, Int>>, labels: List<Pair<String, Double>>, types: Set<String>? = null,
              threshold: Double = 0.0): List<Entity> {
        val out = ArrayList<Entity>()
        var cs = 0; var ce = 0; var ct: String? = null; val sc = ArrayList<Double>()
        fun flush() { if (ct != null && sc.average() >= threshold) out.add(Entity(cs, ce, ct!!, sc.average())) }
        for (i in spans.indices) {
            val (s, e) = spans[i]; val (lab, score) = labels[i]
            val typ = if (lab == "O") null else lab.replace(Regex("^[BIES]-"), "")
            if (typ != null && (types == null || typ in types)) {
                if (ct == typ && !lab.startsWith("B-")) { ce = e; sc.add(score) }
                else { flush(); cs = s; ce = e; ct = typ; sc.clear(); sc.add(score) }
            } else { flush(); ct = null; sc.clear() }
        }
        flush()
        return out
    }
}

/** The model-independent part of mobile_ref.OnnxWordTagger; `logits` runs the ONNX model on one window. */
class WordTaggerCore(
    val labels: List<String>, private val cls: Int, private val sep: Int, maxLen: Int, private val stride: Int,
    private val encode: (String) -> IntArray,
    private val logits: (IntArray) -> Array<FloatArray>,
) {
    private val L = maxLen - 2

    fun wordPieces(words: List<String>): Pair<IntArray, IntArray> {
        val ids = ArrayList<Int>(); val wid = ArrayList<Int>()
        words.forEachIndexed { i, w -> for (t in encode(w)) { ids.add(t); wid.add(i) } }
        return ids.toIntArray() to wid.toIntArray()
    }

    fun tokenProbs(ids: IntArray): Array<DoubleArray?> {
        val n = ids.size; val out = arrayOfNulls<DoubleArray>(n); var start = 0
        while (n > 0) {
            val chunk = ids.copyOfRange(start, minOf(n, start + L))
            val z = logits(intArrayOf(cls) + chunk + intArrayOf(sep))
            for (j in chunk.indices) {
                if (out[start + j] != null) continue
                val row = z[j + 1].map { it.toDouble() }; val mx = row.max()
                val ex = row.map { exp(it - mx) }; val sum = ex.sum()
                out[start + j] = DoubleArray(ex.size) { ex[it] / sum }
            }
            if (start + L >= n) break
            start += L - stride
        }
        return out
    }

    /** mode: "first" (E4 tagger), "mean" or "max" (PII models). */
    fun wordLabels(words: List<String>, mode: String): List<Pair<String, Double>> {
        val (ids, wid) = wordPieces(words)
        val probs = tokenProbs(ids)
        val per = List(words.size) { ArrayList<DoubleArray>() }
        for (k in ids.indices) per[wid[k]].add(probs[k]!!)
        val o = labels.indexOf("O")
        return per.map { ps ->
            if (ps.isEmpty()) return@map "O" to 1.0
            if (mode == "max" && o >= 0) {
                val ent = ps.map { 1.0 - it[o] }; val best = ent.indices.maxBy { ent[it] }
                val p = ps[best].copyOf(); p[o] = -1.0
                return@map labels[p.indices.maxBy { p[it] }] to ent[best]
            }
            val v = if (mode == "first") ps[0] else DoubleArray(ps[0].size) { c -> ps.sumOf { it[c] } / ps.size }
            val k = v.indices.maxBy { v[it] }
            labels[k] to v[k]
        }
    }
}
