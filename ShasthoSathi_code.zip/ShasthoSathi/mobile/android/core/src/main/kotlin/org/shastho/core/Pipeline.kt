package org.shastho.core

/**
 * The on-phone pipeline (port of src/shastho/mobile_ref.py, MobilePipeline):
 *   1. privacy   : rule spans (v1 + v2 header rules) + PII models; medicine/dosage words and lab rows are protected
 *   2. lab flags : parse "test value unit range" rows; rules decide high / low / normal
 *   3. explain   : deterministic template (Bengali or English)
 * Models are optional: with none loaded the pipeline runs on rules + template alone.
 */
data class PipelineConfig(
    val agg: String = "mean", val threshold: Double = 0.1, val rulesV2: Boolean = true,
    val nerVariant: String = "int8", val piiVariant: Map<String, String> = mapOf("bn" to "int8emb", "en" to "int8noattn"),
) {
    companion object {
        /** Reads mobile/assets/pipeline_config.json (written by E7b). */
        fun fromJson(s: String): PipelineConfig {
            val j = Json.parse(s) as Map<*, *>
            val pv = j["pii_variant"]
            return PipelineConfig(
                agg = j["agg"] as String, threshold = (j["threshold"] as Number).toDouble(),
                rulesV2 = j["rules_v2"] as Boolean, nerVariant = (j["ner_variant"] ?: "int8") as String,
                piiVariant = if (pv is Map<*, *>) pv.entries.associate { it.key as String to it.value as String }
                             else mapOf("bn" to pv as String, "en" to pv),
            )
        }
    }
}

data class PipelineResult(
    val lang: String, val redactedText: String, val spans: List<Span>, val removed: Map<String, Int>,
    val medicines: List<Pair<String, String>>, val labs: List<LabResult>, val abnormal: List<String>,
    val explanation: String, val timingMs: Map<String, Double>, val stages: Map<String, Boolean>,
)

class PhonePipeline(
    val config: PipelineConfig = PipelineConfig(),
    private val ner: WordTaggerCore? = null,
    private val pii: Map<String, WordTaggerCore> = emptyMap(),
) {
    data class Analysis(val spans: List<Pair<Int, Int>>, val kept: List<Privacy.Entity>,
                        val piiWords: Map<String, List<Pair<String, Double>>>)

    fun analyse(text: String): Analysis {
        val ms = Generated.WORD.findAll(text).toList()
        val words = ms.map { it.value }; val spans = ms.map { it.range.first to it.range.last + 1 }
        val kept = ner?.let { Privacy.group(spans, it.wordLabels(words, "first"), setOf("Medicine", "Dosage")) } ?: emptyList()
        val piiWords = Privacy.route(text).filter { it in pii }.associateWith { pii[it]!!.wordLabels(words, config.agg) }
        return Analysis(spans, kept, piiWords)
    }

    fun privacy(text: String, an: Analysis = analyse(text)): Pair<String, List<Span>> {
        val rs = Privacy.ruleSpans(text, config.rulesV2)
        val model = ArrayList<Pair<Int, Int>>()
        for ((_, labs) in an.piiWords) model += Privacy.group(an.spans, labs, threshold = config.threshold).map { it.start to it.end }
        val holes = an.kept.map { it.start to it.end } + Privacy.labRows(text)
        val ms = Privacy.trim(text, Privacy.subtract(model, holes)).map { Span(it.first, it.second, "PII") }
        val merged = Privacy.merge(rs + ms)
        val sb = StringBuilder(); var last = 0
        for (m in merged) { sb.append(text, last, m.start).append('[').append(m.label).append(']'); last = m.end }
        sb.append(text, last, text.length)
        return sb.toString() to merged
    }

    fun run(text: String, lang: String = "bn"): PipelineResult {
        val t0 = System.nanoTime(); val an = analyse(text)
        val t1 = System.nanoTime(); val (red, merged) = privacy(text, an)
        val t2 = System.nanoTime(); val labs = Rules.parseLabLines(text); val exp = Explain.template(labs, lang)
        val t3 = System.nanoTime()
        val ms = { a: Long, b: Long -> (b - a) / 1e6 }
        return PipelineResult(
            lang, red, merged, merged.groupingBy { it.label }.eachCount(),
            an.kept.map { text.substring(it.start, it.end) to it.type }, labs,
            labs.filter { it.flag == "high" || it.flag == "low" }.map { it.name }, exp,
            mapOf("models_ms" to ms(t0, t1), "rules_ms" to ms(t1, t2), "labs_explain_ms" to ms(t2, t3)),
            mapOf("medicine_tagger" to (ner != null), "pii_bn" to ("bn" in pii), "pii_en" to ("en" in pii),
                  "header_rules_v2" to config.rulesV2),
        )
    }
}
