package org.shastho.core

import kotlin.math.abs

/**
 * Checks a loaded model against the files written by scripts/20_web_golden.py on the server:
 *   tok_golden.json   [{"word": ..., "ids": [...]}]            -> tokenizer ids must be identical to Python
 *   model_golden.json [{"words": [...], "<mode>": [[label, score], ...]}] -> word labels from the full model
 * The same check runs in the web app (web/js/models.js); here it runs on the phone's ONNX Runtime.
 */
object ModelGolden {
    data class Result(
        val model: String, val mode: String,
        val tokWords: Int = 0, val tokDiff: Int = 0, val tokExamples: List<String> = emptyList(),
        val words: Int = 0, val labelDiff: Int = 0, val maxScoreDiff: Double = 0.0,
        val labelExamples: List<String> = emptyList(), val hasTok: Boolean = false, val hasModel: Boolean = false,
    ) {
        val identical get() = hasTok && hasModel && tokDiff == 0 && labelDiff == 0

        fun describe(): String = buildString {
            append("$model ($mode): ")
            if (!hasTok && !hasModel) { append("no golden files in the folder (run scripts/20_web_golden.py)"); return@buildString }
            if (hasTok) append(if (tokDiff == 0) "tokenizer identical ($tokWords words)" else "tokenizer $tokDiff/$tokWords differ ${tokExamples.take(3)}")
            if (hasModel) {
                append(" · ")
                append(if (labelDiff == 0) "labels identical ($words words)" else "labels $labelDiff/$words differ")
                append(", max score diff %.1e".format(maxScoreDiff))
                labelExamples.take(3).forEach { append("\n   ").append(it) }
            }
        }
    }

    private fun int(x: Any?) = (x as Number).toInt()

    fun check(model: String, mode: String, encode: (String) -> IntArray, tagger: WordTaggerCore,
              tokGolden: String?, modelGolden: String?): Result {
        var r = Result(model, mode)
        if (tokGolden != null) {
            val rows = Json.parse(tokGolden) as List<*>
            val bad = ArrayList<String>()
            for (row in rows) {
                val m = row as Map<*, *>; val w = m["word"] as String
                val want = (m["ids"] as List<*>).map(::int)
                if (encode(w).toList() != want) bad.add(w)
            }
            r = r.copy(hasTok = true, tokWords = rows.size, tokDiff = bad.size, tokExamples = bad.take(5))
        }
        if (modelGolden != null) {
            var n = 0; var diff = 0; var maxd = 0.0; val ex = ArrayList<String>()
            for (doc in Json.parse(modelGolden) as List<*>) {
                val d = doc as Map<*, *>
                val words = (d["words"] as List<*>).map { it as String }
                val want = (d[mode] as List<*>).map { val a = it as List<*>; a[0] as String to (a[1] as Number).toDouble() }
                val got = tagger.wordLabels(words, mode)
                want.forEachIndexed { i, (lab, sc) ->
                    n++
                    if (lab != got[i].first) { diff++; if (ex.size < 5) ex.add("'${words[i]}': python $lab, phone ${got[i].first}") }
                    maxd = maxOf(maxd, abs(sc - got[i].second))
                }
            }
            r = r.copy(hasModel = true, words = n, labelDiff = diff, maxScoreDiff = maxd, labelExamples = ex)
        }
        return r
    }
}
