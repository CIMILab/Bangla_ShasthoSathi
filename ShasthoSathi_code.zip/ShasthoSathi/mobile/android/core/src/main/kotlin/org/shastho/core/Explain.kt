package org.shastho.core

/** Port of src/shastho/explain.py: fact sheet, deterministic templates (EN / BN), strict prompt and the gate. */
object Explain {
    private fun range(l: LabResult, lang: String): String {
        if (l.low == null && l.high == null) return ""
        val r = if (l.low != null && l.high != null) "${Py.g(l.low)}-${Py.g(l.high)}"
                else if (l.low == null) "< ${Py.g(l.high)}" else "> ${Py.g(l.low)}"
        return if (lang == "bn") " (স্বাভাবিক সীমা $r)" else " (normal range $r)"
    }

    fun bnLabel(name: String): String? =
        Generated.BN_LABEL[Generated.SPACES.replace(Py.strip(name).lowercase(), " ")]

    fun facts(labs: List<LabResult>): String = labs.joinToString("\n") {
        "- ${it.name}: ${Py.g(it.value)} ${it.unit}${range(it, "en")} -> ${it.flag.uppercase()}"
    }

    fun template(labs: List<LabResult>, lang: String): String {
        val rows = labs.map { l ->
            val st = Generated.STATUS[lang]!![l.flag]!!
            if (lang == "bn") {
                val lab = bnLabel(l.name)
                val head = if (lab != null) "$lab — ${l.name}" else l.name
                "$head: ${Py.g(l.value)} ${l.unit} — $st${range(l, "bn")}।"
            } else "${l.name}: ${Py.g(l.value)} ${l.unit} is $st${range(l, "en")}."
        }
        return (rows + Generated.DOCTOR[lang]!!).joinToString("\n")
    }

    fun strictPrompt(labs: List<LabResult>, lang: String): String {
        val name = if (lang == "bn") "Bangla (Bengali script)" else "English"
        return "These facts were checked by the app:\n${facts(labs)}\n\nRewrite them for the patient in simple $name.\n${Generated.STRICT}"
    }

    data class Gated(val source: String, val text: String, val blockedNumbers: List<String>, val missingTests: List<String>)

    /** Number check + coverage check: an LLM text that fails either is replaced by the template. */
    fun gate(text: String, labs: List<LabResult>, lang: String): Gated {
        val clean = Generated.GATE_BULLET.replace(text.replace("**", ""), "")
        val bad = Rules.unsupportedNumbers(clean, facts(labs))
        val low = clean.lowercase()
        val missing = labs.filter { l ->
            (l.flag == "high" || l.flag == "low") &&
                (Generated.NAME_PAREN.replace(l.name, "").lowercase().replace("s. ", "") !in low || Py.g(l.value) !in clean)
        }.map { it.name }
        return if (bad.isNotEmpty() || missing.isNotEmpty()) Gated("template", template(labs, lang), bad, missing)
               else Gated("llm", text, emptyList(), emptyList())
    }
}
