package org.shastho.core

import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Compares the Kotlin core with the Python reference, file by file (scripts/15_core_golden.py).
 * Each check returns a list of human-readable mismatches; empty = identical to Python.
 * Runs in the JVM unit tests and on the phone itself (the app's "Self-test" reads the same files from its assets),
 * which checks that Android's regex engine gives Python's answers too.
 */
object GoldenChecks {
    /** file name -> its lines. JVM tests read src/test/resources/golden; the app reads assets/golden. */
    var reader: (String) -> List<String> = { File("src/test/resources/golden", it).readLines(Charsets.UTF_8) }

    private fun lines(name: String): List<Map<*, *>> =
        reader(name).filter { it.isNotBlank() }.map { Json.parse(it) as Map<*, *> }

    private fun dbl(x: Any?): Double? = (x as Number?)?.toDouble()
    private fun int(x: Any?): Int = (x as Number).toInt()

    private fun lab(m: Map<*, *>) = LabResult(m["name"] as String, dbl(m["value"])!!, m["unit"] as String,
        dbl(m["low"]), dbl(m["high"]), m["flag"] as String, (m["line"] as Number?)?.toInt())

    private fun spans3(x: Any?) = (x as List<*>).map { val a = it as List<*>; Span(int(a[0]), int(a[1]), a[2] as String) }
    private fun pairs(x: Any?) = (x as List<*>).map { val a = it as List<*>; int(a[0]) to int(a[1]) }

    private fun <T> cmp(fails: MutableList<String>, id: Any?, what: String, want: T, got: T) {
        if (want != got && fails.size < 30) fails.add("$id [$what]\n   python: $want\n   kotlin: $got")
    }

    fun core(): List<String> {
        val f = ArrayList<String>()
        val rulesOnly = PhonePipeline(PipelineConfig(rulesV2 = true))
        for (g in lines("core_golden.jsonl")) {
            val id = g["id"]; val t = g["text"] as String
            cmp(f, id, "rules_v1", spans3(g["rules_v1"]), Privacy.ruleSpans(t, false))
            cmp(f, id, "rules_v2", spans3(g["rules_v2"]), Privacy.ruleSpans(t, true))
            val labs = (g["labs"] as List<*>).map { lab(it as Map<*, *>) }
            cmp(f, id, "labs", labs, Rules.parseLabLines(t))
            cmp(f, id, "lab_rows", pairs(g["lab_rows"]), Privacy.labRows(t))
            val (red, merged) = rulesOnly.privacy(t)
            cmp(f, id, "merged_v2", spans3(g["merged_v2"]), merged)
            cmp(f, id, "redacted_v2", g["redacted_v2"], red)
            cmp(f, id, "template_bn", g["template_bn"], Explain.template(labs, "bn"))
            cmp(f, id, "template_en", g["template_en"], Explain.template(labs, "en"))
            cmp(f, id, "facts", g["facts"], Explain.facts(labs))
            cmp(f, id, "numbers", g["numbers"], Rules.numbersIn(t))
            cmp(f, id, "route", g["route"], Privacy.route(t))
        }
        return f
    }

    fun gate(): List<String> {
        val f = ArrayList<String>()
        for (g in lines("gate_golden.jsonl")) {
            val labs = (g["labs"] as List<*>).map { lab(it as Map<*, *>) }
            val r = Explain.gate(g["text"] as String, labs, g["lang"] as String)
            cmp(f, g["id"], "source", g["source"], r.source)
            cmp(f, g["id"], "out", g["out"], r.text)
            cmp(f, g["id"], "blocked", g["blocked"], r.blockedNumbers)
            cmp(f, g["id"], "missing", g["missing"], r.missingTests)
        }
        return f
    }

    fun tagger(): List<String> {
        val f = ArrayList<String>()
        for (g in lines("tagger_golden.jsonl")) {
            val labels = (g["labels"] as List<*>).map { it as String }
            val tg = WordTaggerCore(labels, 1, 2, int(g["max_len"]), int(g["stride"]),
                encode = { w -> w.take(3).map { 3 + it.code % 50 }.toIntArray() },
                logits = { ids -> Array(ids.size) { j -> FloatArray(labels.size) { k ->
                    (sin(0.37 * ids[j] + 1.3 * k) * 3 + cos(0.11 * j)).toFloat() } } })
            val words = (g["words"] as List<*>).map { it as String }
            for (mode in listOf("first", "mean", "max")) {
                val want = (g[mode] as List<*>).map { val a = it as List<*>; a[0] as String to dbl(a[1])!! }
                val got = tg.wordLabels(words, mode)
                val ok = want.size == got.size && want.zip(got).all { (a, b) -> a.first == b.first && abs(a.second - b.second) < 1e-6 }
                if (!ok && f.size < 30) f.add("${g["id"]} L=${g["max_len"]} [$mode]\n   python: $want\n   kotlin: $got")
            }
        }
        return f
    }

    fun groups(): List<String> {
        val f = ArrayList<String>()
        lines("group_golden.jsonl").forEachIndexed { i, g ->
            val spans = pairs(g["spans"])
            val labels = (g["labels"] as List<*>).map { val a = it as List<*>; a[0] as String to dbl(a[1])!! }
            val types = (g["types"] as List<*>?)?.map { it as String }?.toSet()
            val want = (g["group"] as List<*>).map { val a = it as List<*>; Privacy.Entity(int(a[0]), int(a[1]), a[2] as String, dbl(a[3])!!) }
            val got = Privacy.group(spans, labels, types, dbl(g["threshold"])!!)
            val ok = want.size == got.size && want.zip(got).all { (a, b) ->
                a.start == b.start && a.end == b.end && a.type == b.type && abs(a.score - b.score) < 6e-5 }   // python rounds scores to 4 decimals
            if (!ok && f.size < 30) f.add("group #$i\n   python: $want\n   kotlin: $got")
            cmp(f, "case $i", "subtract", pairs(g["subtract"]), Privacy.subtract(spans, pairs(g["holes"])))
            cmp(f, "case $i", "trim", pairs(g["trim"]), Privacy.trim(g["text"] as String, spans))
            cmp(f, "case $i", "merge", spans3(g["merge"]),
                Privacy.merge(spans.zip(labels).map { (s, l) -> Span(s.first, s.second, l.first) }))
        }
        return f
    }

    /** E8 metrics and rules-only redaction on real OCR output (desktop Tesseract on the printable pages). */
    fun ocr(): List<String> {
        val f = ArrayList<String>()
        val rulesOnly = PhonePipeline(PipelineConfig(rulesV2 = true))
        lines("ocr_golden.jsonl").forEachIndexed { i, g ->
            val hyp = g["hyp"] as String
            val red = rulesOnly.privacy(hyp).first
            cmp(f, "ocr $i", "redacted", g["redacted"], red)
            val c = OcrEval.cer(g["ref"] as String, hyp)
            if (abs(c - dbl(g["cer"])!!) > 1e-12 && f.size < 30) f.add("ocr $i [cer] python ${g["cer"]} kotlin $c")
            val labs = (g["labs"] as List<*>).map { val m = it as Map<*, *>; LabResult(m["name"] as String, dbl(m["value"])!!,
                m["unit"] as String, dbl(m["low"]), dbl(m["high"]), m["flag"] as String, null) }
            val ls = OcrEval.labScores(labs, hyp)
            cmp(f, "ocr $i", "labs", listOf(int(g["gold_rows"]), int(g["rows_exact"]), int(g["flags_correct"]), int(g["spurious"])),
                listOf(ls.goldRows, ls.rowsExact, ls.flagsCorrect, ls.spurious))
            val lk = OcrEval.leakScores((g["pii_items"] as List<*>).map { it as String }, red)
            cmp(f, "ocr $i", "leak", g["leaked_items"], lk.leakedItems)
        }
        return f
    }

    /** Layout: report lines cut into word boxes, tilted 3 degrees and shuffled column-wise must come back as rows. */
    fun layout(): List<String> {
        val f = ArrayList<String>()
        val ang = Math.toRadians(3.0); val cs = kotlin.math.cos(ang).toFloat(); val sn = kotlin.math.sin(ang).toFloat()
        for (g in lines("core_golden.jsonl").filter { (it["id"] as String).startsWith("heldout") }.take(60)) {
            val text = g["text"] as String
            val src = Py.splitlines(text)
            val words = ArrayList<OcrWord>()
            src.forEachIndexed { li, ln ->
                for (m in Generated.WORD.findAll(ln)) {
                    val x0 = m.range.first * 12f; val x1 = (m.range.last + 1) * 12f; val y0 = li * 34f; val y1 = y0 + 22f
                    // rotate the box centre; keep box size
                    val cx = (x0 + x1) / 2; val cy = (y0 + y1) / 2
                    val rx = cx * cs - cy * sn; val ry = cx * sn + cy * cs
                    words.add(OcrWord(m.value, rx - (x1 - x0) / 2, ry - 11f, rx + (x1 - x0) / 2, ry + 11f, line = li))
                }
            }
            val back = OcrLayout.toText(words.sortedBy { it.left })          // column-wise order, like a table read by columns
            val want = src.filter { it.isNotBlank() }.map { OcrEval.norm(it) }
            val got = Py.splitlines(back).map { OcrEval.norm(it) }
            cmp(f, g["id"], "layout rows", want, got)
            // the parser must find the same lab rows in the rebuilt text
            cmp(f, g["id"], "layout labs", Rules.parseLabLines(text).map { Triple(it.name, it.value, it.flag) },
                Rules.parseLabLines(back).map { Triple(it.name, it.value, it.flag) })
        }
        return f
    }

    fun all(): Map<String, List<String>> = linkedMapOf("core" to core(), "gate" to gate(), "tagger" to tagger(),
        "groups" to groups(), "ocr" to ocr(), "layout" to layout())
}
