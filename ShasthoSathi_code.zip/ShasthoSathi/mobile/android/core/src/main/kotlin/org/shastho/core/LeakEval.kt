package org.shastho.core

/**
 * E7d: the server's leak test, run on the phone (file from scripts/24_phone_leak_set.py).
 * Same metric as src/shastho/metrics.py: a gold identifier leaks if any of its letters/digits is not hidden
 * (spaces and punctuation ignored); leak = mean over documents of the share of leaked identifiers.
 * Also: clinical spans (medicine/dose/lab value) touched, and other (non-identifier) text hidden.
 */
object LeakEval {
    data class Doc(val set: String, val id: String, val src: String, val text: String,
                   val pii: List<Triple<Int, Int, String>>, val protected: List<Pair<Int, Int>>, val server: List<Pair<Int, Int>>)

    class Acc { var n = 0; var leakSum = 0.0; var leakedSpans = 0; var spans = 0; var clinHit = 0; var clinN = 0
                var hid = 0L; var other = 0L; var docsLeaking = 0 }

    private val NOT_CONTENT = setOf(
        CharCategory.SPACE_SEPARATOR, CharCategory.LINE_SEPARATOR, CharCategory.PARAGRAPH_SEPARATOR,
        CharCategory.DASH_PUNCTUATION, CharCategory.START_PUNCTUATION, CharCategory.END_PUNCTUATION,
        CharCategory.CONNECTOR_PUNCTUATION, CharCategory.OTHER_PUNCTUATION, CharCategory.INITIAL_QUOTE_PUNCTUATION,
        CharCategory.FINAL_QUOTE_PUNCTUATION, CharCategory.CONTROL, CharCategory.FORMAT, CharCategory.PRIVATE_USE,
        CharCategory.SURROGATE, CharCategory.UNASSIGNED)

    /** metrics._content: unicodedata category not Z*, P* or C*. */
    fun content(c: Char) = c.category !in NOT_CONTENT

    private fun int(x: Any?) = (x as Number).toInt()
    private fun pairs(x: Any?) = (x as List<*>).map { val a = it as List<*>; int(a[0]) to int(a[1]) }

    fun parse(lines: List<String>): Pair<Map<*, *>, List<Doc>> {
        val rows = lines.filter { it.isNotBlank() }.map { Json.parse(it) as Map<*, *> }
        val meta = rows.first()["meta"] as Map<*, *>
        val docs = rows.drop(1).map { m ->
            Doc(m["set"] as String, m["doc_id"] as String, m["src"] as String, m["text"] as String,
                (m["pii"] as List<*>).map { val a = it as List<*>; Triple(int(a[0]), int(a[1]), a[2] as String) },
                pairs(m["protected"]), pairs(m["server"]))
        }
        return meta to docs
    }

    /** Adds one document's scores to `acc`; returns the leaked identifiers' types. */
    fun score(d: Doc, pred: List<Pair<Int, Int>>, acc: Acc): List<String> {
        val hidden = BooleanArray(d.text.length); val gold = BooleanArray(d.text.length)
        for ((s, e) in pred) for (i in s until minOf(e, d.text.length)) hidden[i] = true
        val leakedTypes = ArrayList<String>()
        for ((s, e, t) in d.pii) {
            for (i in s until e) gold[i] = true
            if ((s until e).any { content(d.text[it]) && !hidden[it] }) leakedTypes.add(t)
        }
        acc.n++; acc.spans += d.pii.size; acc.leakedSpans += leakedTypes.size
        acc.leakSum += if (d.pii.isEmpty()) 0.0 else leakedTypes.size.toDouble() / d.pii.size
        if (leakedTypes.isNotEmpty()) acc.docsLeaking++
        acc.clinN += d.protected.size; acc.clinHit += d.protected.count { (s, e) -> (s until e).any { hidden[it] } }
        for (i in d.text.indices) if (content(d.text[i]) && !gold[i]) { acc.other++; if (hidden[i]) acc.hid++ }
        return leakedTypes
    }

    /** Runs `predict` (the phone pipeline's hidden spans) on every document and compares with the server. */
    fun run(meta: Map<*, *>, docs: List<Doc>, predict: (String) -> List<Pair<Int, Int>>, progress: (Int, Int) -> Unit = { _, _ -> },
            diagnose: ((Doc, List<Pair<Int, Int>>) -> String)? = null): String {
        val diag = ArrayList<String>()
        val phone = LinkedHashMap<String, Acc>(); val server = LinkedHashMap<String, Acc>()
        val same = HashMap<String, Int>(); val onlyPhone = ArrayList<String>(); val onlyServer = ArrayList<String>()
        val t0 = System.nanoTime()
        docs.forEachIndexed { k, d ->
            val p = predict(d.text)
            val lp = score(d, p, phone.getOrPut(d.set) { Acc() })
            val ls = score(d, d.server, server.getOrPut(d.set) { Acc() })
            if (p.toSet() == d.server.toSet()) same[d.set] = (same[d.set] ?: 0) + 1
            if (lp.isNotEmpty() && ls.isEmpty()) {
                onlyPhone.add("${d.id} ${lp.distinct()}")
                if (diagnose != null && diag.size < 25) diag.add(d.id + ": " + diagnose(d, p))
            }
            if (ls.isNotEmpty() && lp.isEmpty()) onlyServer.add("${d.id} ${ls.distinct()}")
            if (k % 10 == 0) progress(k, docs.size)
        }
        val sec = (System.nanoTime() - t0) / 1e9
        fun pc(x: Double) = "%.1f%%".format(100 * x)
        return buildString {
            appendLine("Leak test (E7d): phone vs server, same texts, same metric")
            appendLine("server config: ${meta["config"]}")
            appendLine("set     n   leak phone/server   docs leaking   clinical hit   other text hidden   identical spans")
            for ((name, a) in phone) {
                val b = server.getValue(name)
                appendLine("%-6s %4d   %6s / %-6s   %3d / %-3d     %6s / %-6s   %6s / %-6s   %d/%d".format(name, a.n,
                    pc(a.leakSum / a.n), pc(b.leakSum / b.n), a.docsLeaking, b.docsLeaking,
                    if (a.clinN > 0) pc(a.clinHit.toDouble() / a.clinN) else "-", if (b.clinN > 0) pc(b.clinHit.toDouble() / b.clinN) else "-",
                    pc(a.hid.toDouble() / maxOf(a.other, 1)), pc(b.hid.toDouble() / maxOf(b.other, 1)), same[name] ?: 0, a.n))
            }
            appendLine("leak only on the phone (${onlyPhone.size}): ${onlyPhone.take(10)}")
            appendLine("leak only on the server (${onlyServer.size}): ${onlyServer.take(10)}")
            if (diag.isNotEmpty()) { appendLine("why (phone-only leaks):"); diag.forEach { appendLine("  $it") } }
            appendLine("time: %.0f s for %d documents (%.0f ms each)".format(sec, docs.size, 1000 * sec / docs.size))
        }
    }
}
