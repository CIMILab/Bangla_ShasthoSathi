package org.shastho.core

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

/**
 * Small helpers that reproduce Python behaviour exactly, so the phone gives byte-identical output to the
 * Python reference (src/shastho). Offsets are UTF-16 indices; Bengali and Latin text is all in the BMP, where
 * they equal Python's code-point indices.
 */
object Py {
    private const val BN_DIGITS = "০১২৩৪৫৬৭৮৯"

    /** str.isspace() */
    fun isSpace(c: Char): Boolean = c == ' ' || c in '\t'..'\r' || c in '\u001C'..'\u001F' || c == '\u0085' ||
        c == ' ' || c == ' ' || c in ' '..' ' || c == ' ' || c == ' ' ||
        c == ' ' || c == ' ' || c == '　'

    /** str.strip() */
    fun strip(s: String): String {
        var a = 0; var b = s.length
        while (a < b && isSpace(s[a])) a++
        while (b > a && isSpace(s[b - 1])) b--
        return s.substring(a, b)
    }

    /** '১২.৫' -> '12.5' (same length) */
    fun toAsciiDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) { val i = BN_DIGITS.indexOf(c); sb.append(if (i >= 0) ('0' + i) else c) }
        return sb.toString()
    }

    /** str.splitlines(keepends) - Python's full set of line boundaries. */
    fun splitlines(s: String, keepends: Boolean = false): List<String> {
        val out = ArrayList<String>(); var start = 0; var i = 0
        while (i < s.length) {
            val c = s[i]
            val brk = c == '\n' || c == '\r' || c == '\u000B' || c == '\u000C' || c in '\u001C'..'\u001E' ||
                c == '\u0085' || c == ' ' || c == ' '
            if (brk) {
                var end = i + 1
                if (c == '\r' && end < s.length && s[end] == '\n') end++
                out.add(if (keepends) s.substring(start, end) else s.substring(start, i))
                start = end; i = end
            } else i++
        }
        if (start < s.length) out.add(s.substring(start))
        return out
    }

    /** f"{x:g}" : 6 significant digits, trailing zeros removed, scientific when exp < -4 or >= 6. */
    fun g(x: Double): String {
        if (x.isNaN()) return "nan"
        if (x.isInfinite()) return if (x > 0) "inf" else "-inf"
        if (x == 0.0) return if (1.0 / x < 0) "-0" else "0"
        val r = BigDecimal(x).round(MathContext(6, RoundingMode.HALF_EVEN))
        val exp = r.precision() - r.scale() - 1
        return if (exp < -4 || exp >= 6) {
            val digits = r.unscaledValue().abs().toString().trimEnd('0').ifEmpty { "0" }
            val mant = if (digits.length > 1) digits[0] + "." + digits.substring(1) else digits
            (if (r.signum() < 0) "-" else "") + mant + "e" + (if (exp < 0) "-" else "+") + String.format("%02d", kotlin.math.abs(exp))
        } else {
            var t = r.toPlainString()
            if (t.contains('.')) t = t.trimEnd('0').trimEnd('.')
            t
        }
    }

    fun g(x: Double?): String = if (x == null) "" else g(x)
}
