package org.shastho.core

import org.junit.Assert.assertTrue
import org.junit.Test

/** The Kotlin core must give exactly the Python reference's answers (scripts/15_core_golden.py). */
class GoldenTest {
    private fun check(name: String, fails: List<String>) =
        assertTrue("$name: ${fails.size}+ mismatches with Python\n" + fails.take(5).joinToString("\n"), fails.isEmpty())

    @Test fun rulesLabsTemplatesRedaction() = check("core", GoldenChecks.core())
    @Test fun gate() = check("gate", GoldenChecks.gate())
    @Test fun modelWrapperWindowsAndAggregation() = check("tagger", GoldenChecks.tagger())
    @Test fun groupingSubtractTrimMerge() = check("groups", GoldenChecks.groups())
    @Test fun ocrMetricsAndRedactionOnOcrText() = check("ocr", GoldenChecks.ocr())
    @Test fun ocrLayoutRebuildsRows() = check("layout", GoldenChecks.layout())
}
