@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package org.shastho.app

import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.shastho.core.*
import org.shastho.models.ModelSet
import java.io.File

/**
 * Research tools (English only, reached from Settings): on-phone speed test and self-test (E7), and the E8 photo
 * evaluation. Kept out of the patient-facing screens.
 */
@Composable
fun ResearchScreen(samples: List<Sample>, pipeline: PhonePipeline, models: ModelStore, onBack: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("Research tools") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad -> Box(Modifier.padding(pad)) { ResearchBody(samples, pipeline, models) } }
}

@Composable
private fun ResearchBody(samples: List<Sample>, pipeline: PhonePipeline, models: ModelStore) {
    var text by remember { mutableStateOf(samples.firstOrNull()?.text ?: "") }
    val onText = { t: String -> text = t }
    var report by remember { mutableStateOf("") }
    val onReport = { t: String -> report = t }
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val ocr = remember { OcrRunner(ctx) }
    val e8 = remember { E8(ctx) }
    var mode by remember { mutableStateOf(OcrMode.AUTO) }
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var reading by remember { mutableStateOf(false) }
    var ocrInfo by remember { mutableStateOf<OcrOutput?>(null) }
    var e8Item by remember { mutableStateOf<EvalItem?>(null) }
    var e8Cond by remember { mutableStateOf("flat") }
    var e8Msg by remember { mutableStateOf("") }
    val photoFile = remember { File(ctx.cacheDir, "photos").apply { mkdirs() }.resolve("report.jpg") }
    val photoUri = remember { FileProvider.getUriForFile(ctx, ctx.packageName + ".files", photoFile) }

    fun readPhoto(uri: Uri, deleteAfter: Boolean) = scope.launch {
        reading = true; e8Msg = ""
        try {
            val (bmp, out) = withContext(Dispatchers.Default) { ocr.load(uri, 1200) to ocr.read(uri, mode) }   // small copy for the screen
            photo = bmp; ocrInfo = out; onText(out.text)
            e8Item?.let { item -> e8Msg = withContext(Dispatchers.Default) { e8.score(item, e8Cond, out, pipeline) } }
        } catch (t: Throwable) {
            e8Msg = "Could not read the photo: ${t.message}"
        } finally {
            if (deleteAfter) photoFile.delete()                  // the photo never stays on the phone
            reading = false
        }
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) readPhoto(photoUri, true) }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let { readPhoto(it, false) } }

    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Developer tools for the evaluation. Photos read here are scored for E8 when a sheet id is selected.", fontSize = 14.sp)
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { takePhoto.launch(photoUri) }, enabled = !reading) { Text("Take photo") }
            OutlinedButton(onClick = { pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                enabled = !reading) { Text("From gallery") }
            OutlinedButton(onClick = { clip.getText()?.text?.let(onText) }) { Text("Paste") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Reader:", fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterVertically))
            OcrMode.entries.forEach { m -> FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.label, fontSize = 12.sp) }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            samples.forEach { s -> AssistChip(onClick = { onText(s.text); photo = null; ocrInfo = null }, label = { Text(s.title) }) }
        }
        if (reading) Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)); Text("Reading the photo on this phone…")
        }
        photo?.let { bmp ->
            Image(bmp.asImageBitmap(), "photo of the report", Modifier.fillMaxWidth().heightIn(max = 260.dp))
        }
        ocrInfo?.let { o ->
            Text("⚠ Check the text below against the photo and fix any wrong number before you continue.\n" +
                 "ছবির সাথে মিলিয়ে দেখুন; ভুল সংখ্যা থাকলে ঠিক করুন।",
                color = Color(0xFF7A4B00), fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Color(0xFFFFF3D6), RoundedCornerShape(8.dp)).padding(10.dp))
            Text("Read by ${o.engine} in ${o.ms} ms · ${o.detail} · lab rows found: ${Rules.parseLabLines(text).size}",
                fontSize = 12.sp, color = Color.Gray)
        }
        OutlinedTextField(text, onText, Modifier.fillMaxWidth().heightIn(min = 220.dp),
            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
            label = { Text("Report text / রিপোর্টের লেখা") })

        HorizontalDivider(Modifier.padding(vertical = 16.dp))
        Text("For the evaluation (E7 speed, E8 photos)", fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { scope.launch { onReport("Running speed test…"); onReport(withContext(Dispatchers.Default) { Bench.speed(pipeline, samples, models.ready()) }) } }) { Text("Speed test") }
            OutlinedButton(onClick = { scope.launch { onReport("Running self-test…"); onReport(withContext(Dispatchers.Default) { Bench.selfTest(models.ready(), pipeline.config) }) } }) { Text("Self-test") }
            if (report.isNotBlank()) OutlinedButton(onClick = { clip.setText(AnnotatedString(report)) }) { Text("Copy") }
        }
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val leakFile = models.leakSet
            fun leakTest(only: String?) = scope.launch {
                onReport("Running leak test…")
                onReport(withContext(Dispatchers.Default) {
                    val (meta, all) = LeakEval.parse(leakFile!!.readLines())
                    val docs = if (only == null) all else all.filter { it.set == only }
                    "models: " + (models.ready()?.summary() ?: "-") + "\n" +
                    LeakEval.run(meta, docs, { t -> pipeline.privacy(t).second.map { it.start to it.end } },
                        { k, n -> onReport("Running leak test… $k / $n documents") },
                        diagnose = { d, _ -> leakWhy(pipeline, d) })
                })
            }
            OutlinedButton(enabled = leakFile != null && models.ready() != null, onClick = { leakTest(null) }) { Text("Leak test (E7d)") }
            OutlinedButton(enabled = leakFile != null && models.ready() != null, onClick = { leakTest("free") }) { Text("Free set only") }
            if (leakFile == null) Text("Load the model folder that contains phone_leak_set.jsonl", fontSize = 12.sp,
                color = Color.Gray, modifier = Modifier.align(Alignment.CenterVertically))
        }
        if (report.isNotBlank()) SelectionContainer {
            Text(report, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().background(Color(0xFFF3F5F5), RoundedCornerShape(8.dp)).padding(10.dp))
        }
        Text("E8: before taking the photo, pick the printed sheet's id (bottom-right corner) and the condition.", fontSize = 13.sp,
            modifier = Modifier.padding(top = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = e8Item == null, onClick = { e8Item = null }, label = { Text("off") })
            e8.items.forEach { it2 -> FilterChip(selected = e8Item?.id == it2.id, onClick = { e8Item = it2 }, label = { Text(it2.id) }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("flat", "angled", "dim").forEach { c -> FilterChip(selected = e8Cond == c, onClick = { e8Cond = c }, label = { Text(c) }) }
        }
        if (e8Msg.isNotBlank()) Text(e8Msg, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { clip.setText(AnnotatedString(e8.export())); e8Msg = "Copied ${e8.count()} E8 results" }) { Text("Copy E8 log (${e8.count()})") }
            OutlinedButton(onClick = { e8.clear(); e8Msg = "E8 log cleared" }) { Text("Clear") }
        }
    }
}


/** For a name the phone left visible: was it protected as a medicine, or did the PII model(s) label it 'O'? */
fun leakWhy(pipeline: PhonePipeline, d: LeakEval.Doc): String {
    val an = pipeline.analyse(d.text)
    return d.pii.joinToString("; ") { (s, e, t) ->
        val idx = an.spans.indices.filter { an.spans[it].first < e && an.spans[it].second > s }
        val kept = an.kept.any { it.start < e && it.end > s }
        val labs = an.piiWords.entries.joinToString(" ") { (lg, l) -> lg + "=" + idx.map { "%s %.2f".format(l[it].first, l[it].second) } }
        "$t '${d.text.substring(s, e)}' tagger-protected=$kept $labs"
    }
}

/** E7 measurements that run on the phone and print a block the user can copy into the report. */
object Bench {
    private fun pct(xs: List<Double>, p: Double) = xs.sorted().let { it[((it.size - 1) * p).toInt()] }

    fun speed(pipeline: PhonePipeline, samples: List<Sample>, models: ModelSet? = null,
              reps: Int = if (models == null) 20 else 5): String {
        repeat(3) { samples.forEach { s -> pipeline.run(s.text, "bn") } }            // warm-up
        val stage = HashMap<String, MutableList<Double>>(); val total = ArrayList<Double>()
        repeat(reps) { samples.forEach { s -> listOf("bn", "en").forEach { lg ->
            val t = System.nanoTime(); val r = pipeline.run(s.text, lg); total.add((System.nanoTime() - t) / 1e6)
            r.timingMs.forEach { (k, v) -> stage.getOrPut(k) { ArrayList() }.add(v) }
        } } }
        val rt = Runtime.getRuntime()
        return buildString {
            appendLine("device: ${Build.MANUFACTURER} ${Build.MODEL} | Android ${Build.VERSION.RELEASE} | ${rt.availableProcessors()} cores")
            appendLine("stages: ${pipeline.run(samples[0].text).stages}")
            appendLine("config: ${pipeline.config}")
            appendLine("models: " + (models?.summary() ?: "not loaded (rules + template only)"))
            appendLine("runs: ${total.size} (${samples.size} reports x 2 languages x $reps)")
            appendLine("total per report: median %.2f ms, p90 %.2f ms".format(pct(total, .5), pct(total, .9)))
            stage.forEach { (k, v) -> appendLine("  $k: median %.2f ms, p90 %.2f ms".format(pct(v, .5), pct(v, .9))) }
            appendLine("java heap in use: %.0f MB".format((rt.totalMemory() - rt.freeMemory()) / 1048576.0))
            val mi = android.os.Debug.MemoryInfo(); android.os.Debug.getMemoryInfo(mi)
            appendLine("app memory (PSS, incl. native model runtime): %.0f MB".format(mi.totalPss / 1024.0))
        }
    }

    fun selfTest(models: ModelSet? = null, config: PipelineConfig = PipelineConfig()): String = buildString {
        appendLine("Self-test: phone output vs the Python reference (golden files)")
        var ok = true
        GoldenChecks.all().forEach { (k, v) ->
            appendLine("$k: " + if (v.isEmpty()) "identical" else "${v.size}+ differences"); v.take(3).forEach { appendLine(it) }
            ok = ok && v.isEmpty()
        }
        if (models == null) appendLine("models: not loaded (Settings -> Privacy models); model checks skipped")
        else {
            appendLine("models: " + models.summary())
            models.all.forEach { m ->
                val r = m.goldenCheck(if (m.name == "ner") "first" else config.agg)
                appendLine(r.describe()); ok = ok && r.identical
            }
        }
        appendLine(if (ok) "ALL IDENTICAL" else "DIFFERENCES FOUND")
    }
}
