package org.shastho.app

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.shastho.core.*
import java.io.File

data class Sample(val title: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()                       // system splash: teal + shield mark (Theme.ShasthoSathi.Starting)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val read = { name: String -> assets.open(name).bufferedReader(Charsets.UTF_8).readText() }
        val samples = ((Json.parse(read("samples.json")) as Map<*, *>)["samples"] as List<*>).map {
            val m = it as Map<*, *>; Sample(m["title"] as String, m["text"] as String)
        }
        val config = PipelineConfig.fromJson(read("pipeline_config.json"))
        GoldenChecks.reader = { name -> read("golden/$name").lines() }
        // Rules + templates + on-phone OCR always; the three privacy models join once the user has loaded them
        // (Settings -> Privacy models). They then run on ONNX Runtime with the same config as the Python reference.
        val models = ModelStore.get(applicationContext, config)
        // Only the language and reader choice are stored; reports, photos and edits are never written to storage.
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        setContent { ShasthoTheme { ShasthoApp(config, models, samples, prefs) } }
    }
}

enum class Screen { INTRO, LANGUAGE, HOME, REVIEW, REPORT, SETTINGS, RESEARCH }

@Composable
fun ShasthoApp(config: PipelineConfig, models: ModelStore, samples: List<Sample>, prefs: SharedPreferences) {
    val ctx = LocalContext.current
    // The pipeline follows the model status: rules-only until the models are ready.
    val status = models.status
    val pipeline = remember(status) {
        val set = (status as? ModelStore.Status.Ready)?.set
        PhonePipeline(if (set != null) models.config else config, set?.ner?.core, set?.pii?.mapValues { it.value.core } ?: emptyMap())
    }
    LaunchedEffect(Unit) { if (models.status == ModelStore.Status.None && models.installed()) withContext(Dispatchers.IO) { models.load() } }
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var lang by remember { mutableStateOf(prefs.getString("lang", null)) }
    var mode by remember {
        mutableStateOf(runCatching { OcrMode.valueOf(prefs.getString("reader", "AUTO") ?: "AUTO") }.getOrDefault(OcrMode.AUTO))
    }
    var screen by remember { mutableStateOf(Screen.INTRO) }
    var text by remember { mutableStateOf("") }
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var ocrOut by remember { mutableStateOf<OcrOutput?>(null) }
    var fromPhoto by remember { mutableStateOf(false) }
    var reading by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var report by remember { mutableStateOf<ReportState?>(null) }
    var pickSample by remember { mutableStateOf(false) }

    val s: Str = if (lang == "en") En else Bn
    val ocr = remember { OcrRunner(ctx) }
    val photoFile = remember { File(ctx.cacheDir, "photos").apply { mkdirs() }.resolve("report.jpg") }
    val photoUri = remember { FileProvider.getUriForFile(ctx, ctx.packageName + ".files", photoFile) }

    fun readPhoto(uri: Uri, deleteAfter: Boolean) {
        scope.launch {
            reading = true; error = null
            try {
                val (bmp, out) = withContext(Dispatchers.Default) { ocr.load(uri, 1200) to ocr.read(uri, mode) }
                photo = bmp; ocrOut = out; text = out.text; fromPhoto = true
                screen = Screen.REVIEW
            } catch (t: Throwable) {
                error = s.readFailed
            } finally {
                if (deleteAfter) photoFile.delete()          // the photo never stays on the phone
                reading = false
            }
        }
    }

    fun startText(t: String) {
        text = t; photo = null; ocrOut = null; fromPhoto = false; error = null
        screen = Screen.REVIEW
    }

    fun analyse() {
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.Default) { pipeline.run(text, s.code) }
            report = ReportState(r, fromPhoto)
            busy = false
            screen = Screen.REPORT
        }
    }

    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) readPhoto(photoUri, true) }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) readPhoto(uri, false) }
    // System folder picker: read access to that one folder only, for this import (no storage permission).
    val pickModels = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) { models.importFrom(uri) }
    }

    BackHandler(enabled = screen == Screen.REVIEW || screen == Screen.REPORT || screen == Screen.SETTINGS || screen == Screen.RESEARCH) {
        screen = if (screen == Screen.RESEARCH) Screen.SETTINGS else Screen.HOME
    }

    CompositionLocalProvider(LocalStr provides s) {
        Crossfade(targetState = screen) { sc ->
            when (sc) {
                Screen.INTRO -> BrandIntro { screen = if (lang == null) Screen.LANGUAGE else Screen.HOME }
                Screen.LANGUAGE -> LanguageScreen { code ->
                    lang = code; prefs.edit().putString("lang", code).apply(); screen = Screen.HOME
                }
                Screen.HOME -> HomeScreen(
                    reading = reading, error = error,
                    onScan = { error = null; takePhoto.launch(photoUri) },
                    onGallery = { error = null; pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    onPaste = { startText(clip.getText()?.text ?: "") },
                    onSample = { pickSample = true },
                    onSettings = { screen = Screen.SETTINGS },
                )
                Screen.REVIEW -> ReviewScreen(text, { text = it }, photo, ocrOut, fromPhoto, busy,
                    onBack = { screen = Screen.HOME }, onAnalyse = { analyse() })
                Screen.REPORT -> report?.let { rep ->
                    ReportScreen(rep, onBack = { screen = Screen.REVIEW }, onNew = {
                        report = null; photo = null; ocrOut = null; text = ""; screen = Screen.HOME
                    })
                }
                Screen.SETTINGS -> SettingsScreen(
                    lang = s.code, onLang = { code -> lang = code; prefs.edit().putString("lang", code).apply() },
                    mode = mode, onMode = { m -> mode = m; prefs.edit().putString("reader", m.name).apply() },
                    onResearch = { screen = Screen.RESEARCH }, onBack = { screen = Screen.HOME },
                    models = models,
                    onPickModels = { pickModels.launch(null) },
                    onRemoveModels = { scope.launch(Dispatchers.IO) { models.remove() } },
                )
                Screen.RESEARCH -> ResearchScreen(samples, pipeline, models) { screen = Screen.SETTINGS }
            }
        }

        if (pickSample) AlertDialog(
            onDismissRequest = { pickSample = false },
            title = { Text(s.chooseSample) },
            text = {
                Column {
                    Text(s.sampleNote, style = MaterialTheme.typography.bodySmall, color = muted(),
                        modifier = Modifier.padding(bottom = 8.dp))
                    samples.forEach { sm ->
                        TextButton(onClick = { pickSample = false; startText(sm.text) }, modifier = Modifier.fillMaxWidth()) {
                            Text(s.sampleTitle(sm.title), modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickSample = false }) { Text(s.close) } },
        )
    }
}
