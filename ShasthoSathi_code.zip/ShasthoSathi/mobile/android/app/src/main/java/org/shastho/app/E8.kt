package org.shastho.app

import android.content.Context
import android.os.Build
import org.shastho.core.*
import java.io.File

/** One printed test sheet (mobile/eval/E8_printable.pdf) with its ground truth. */
data class EvalItem(val id: String, val type: String, val text: String, val pii: List<String>, val labs: List<LabResult>)

/**
 * E8 on the phone: photograph a printed test sheet, pick its id, and the app scores the raw OCR text
 * (before any correction by the user) and appends one line to files/e8_log.jsonl. "Export" copies the log.
 */
class E8(private val ctx: Context) {
    val items: List<EvalItem> by lazy {
        val j = Json.parse(ctx.assets.open("eval_set.json").bufferedReader(Charsets.UTF_8).readText()) as Map<*, *>
        (j["items"] as List<*>).map { x ->
            val m = x as Map<*, *>
            EvalItem(m["id"] as String, m["type"] as String, m["text"] as String, (m["pii"] as List<*>).map { it as String },
                (m["labs"] as List<*>).map { l -> val d = l as Map<*, *>
                    LabResult(d["name"] as String, (d["value"] as Number).toDouble(), d["unit"] as String,
                        (d["low"] as Number?)?.toDouble(), (d["high"] as Number?)?.toDouble(), d["flag"] as String, null) })
        }
    }
    private val log get() = File(ctx.filesDir, "e8_log.jsonl")

    private fun q(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t") + "\""

    /** Scores one photo and appends it to the log. Returns a short summary for the screen. */
    fun score(item: EvalItem, condition: String, out: OcrOutput, pipeline: PhonePipeline): String {
        val c = OcrEval.cer(item.text, out.text)
        val l = OcrEval.labScores(item.labs, out.text)
        val red = pipeline.privacy(out.text).first
        val k = OcrEval.leakScores(item.pii, red)
        val line = "{\"id\":${q(item.id)},\"type\":${q(item.type)},\"condition\":${q(condition)},\"engine\":${q(out.engine)}," +
            "\"ocr_ms\":${out.ms},\"cer\":${"%.4f".format(java.util.Locale.ROOT, c)},\"gold_rows\":${l.goldRows},\"rows_exact\":${l.rowsExact}," +
            "\"flags_correct\":${l.flagsCorrect},\"spurious\":${l.spurious},\"pii\":${k.pii},\"leaked\":${k.leaked}," +
            "\"leaked_items\":[${k.leakedItems.joinToString(",") { q(it) }}],\"device\":${q(Build.MODEL)},\"ocr_text\":${q(out.text)}}"
        log.appendText(line + "\n")
        return "${item.id} · $condition · ${out.engine}: CER ${"%.1f".format(100 * c)}% · lab rows ${l.rowsExact}/${l.goldRows} exact · " +
            "flags ${l.flagsCorrect}/${l.goldRows} · leaked ${k.leaked}/${k.pii} · ${out.ms} ms"
    }

    fun export(): String = if (log.exists()) log.readText() else ""
    fun count(): Int = if (log.exists()) log.readLines().count { it.isNotBlank() } else 0
    fun clear() { log.delete() }
}
