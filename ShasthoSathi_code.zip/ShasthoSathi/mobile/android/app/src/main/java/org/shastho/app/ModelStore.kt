package org.shastho.app

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import org.shastho.core.PipelineConfig
import org.shastho.models.ModelSet
import java.io.File

/**
 * The privacy models live in the app's private storage (filesDir/models/{ner,pii_bn,pii_en}). They are too large
 * to ship in the app, so the user copies the server's mobile/assets folder to the phone once and picks it here.
 * The system folder picker grants read access to that folder only: no storage or internet permission is needed.
 */
class ModelStore private constructor(ctx: Context, private val defaultConfig: PipelineConfig) {
    companion object {
        @Volatile private var instance: ModelStore? = null
        /** One store per process, so a screen rotation does not load ~700 MB again. */
        const val LEAK_SET = "phone_leak_set.jsonl"            // scripts/24_phone_leak_set.py
        const val CONFIG = "pipeline_config.json"              // the server's phone config, copied with the models
        fun get(ctx: Context, config: PipelineConfig) = instance ?: synchronized(this) { instance ?: ModelStore(ctx, config).also { instance = it } }
    }

    sealed interface Status {
        data object None : Status
        data class Copying(val file: String, val done: Long, val total: Long) : Status
        data object Loading : Status
        data class Ready(val set: ModelSet) : Status
        data class Failed(val message: String) : Status
    }

    var status by mutableStateOf<Status>(Status.None)
        private set

    init {
        // DJL (tokenizer bindings): never try to download anything, and keep its cache inside the app.
        System.setProperty("ai.djl.offline", "true")
        System.setProperty("DJL_CACHE_DIR", File(ctx.cacheDir, "djl").path)
        // the tokenizer's native library links against the shared C++ runtime; load it first
        runCatching { System.loadLibrary("c++_shared") }
    }

    private val cr = ctx.contentResolver
    val root = File(ctx.filesDir, "models")

    /** The model folder's own pipeline_config.json (same as the server's) wins over the one built into the app. */
    var config: PipelineConfig = readConfig()
        private set
    private fun readConfig() = File(root, CONFIG).takeIf { it.isFile }
        ?.let { runCatching { PipelineConfig.fromJson(it.readText()) }.getOrNull() } ?: defaultConfig

    fun installed() = ModelSet.available(root, config).isNotEmpty()
    val leakSet get() = File(root, LEAK_SET).takeIf { it.isFile }
    fun ready() = (status as? Status.Ready)?.set

    /** Loads what is installed (call off the main thread). */
    fun load(): ModelSet? {
        if (!installed()) { status = Status.None; return null }
        status = Status.Loading
        return try {
            ModelSet.load(root, config).also { status = Status.Ready(it) }
        } catch (t: Throwable) {
            status = Status.Failed("${t.javaClass.simpleName}: ${t.message}"); null
        }
    }

    /** Finds the folder that holds ner/, pii_bn/, pii_en/: the picked folder itself, or one or two levels below it. */
    private fun findModelRoot(dir: DocumentFile, depth: Int = 0): DocumentFile? {
        val kids = dir.listFiles()
        if (kids.any { it.isDirectory && it.name in ModelSet.NAMES }) return dir
        if (depth >= 2) return null
        return kids.filter { it.isDirectory }.firstNotNullOfOrNull { findModelRoot(it, depth + 1) }
    }

    /** Copies the needed files from the picked folder into private storage, then loads them (call off the main thread). */
    fun importFrom(tree: Uri): ModelSet? {
        try {
            val old = ready(); status = Status.Loading; old?.close()        // switch the pipeline to rules-only first
            val picked = DocumentFile.fromTreeUri(ctxApp, tree) ?: error("cannot open the folder")
            val src = findModelRoot(picked) ?: error("no ner / pii_bn / pii_en folder inside '${picked.name}'")
            src.findFile(CONFIG)?.let { doc ->                 // use the folder's config to know which files to copy
                val txt = cr.openInputStream(doc.uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
                config = PipelineConfig.fromJson(txt); root.mkdirs(); File(root, CONFIG).writeText(txt)
            }
            val jobs = ArrayList<Pair<DocumentFile, File>>()
            for (name in ModelSet.NAMES) {
                val d = src.findFile(name)?.takeIf { it.isDirectory } ?: continue
                val need = ModelSet.needed(name, config)
                val missing = need.filter { d.findFile(it) == null }
                if (missing.isNotEmpty()) error("$name: missing ${missing.joinToString()}")
                for (fn in need + ModelSet.OPTIONAL) d.findFile(fn)?.let { jobs.add(it to File(root, "$name/$fn")) }
            }
            if (jobs.isEmpty()) error("no model folders found")
            src.findFile(LEAK_SET)?.let { jobs.add(it to File(root, LEAK_SET)) }   // optional: E7d leak test texts
            val total = jobs.sumOf { it.first.length() }; var done = 0L
            for ((doc, dst) in jobs) {
                dst.parentFile!!.mkdirs()
                if (dst.isFile && dst.length() == doc.length()) { done += dst.length(); continue }   // already copied
                val tmp = File(dst.path + ".part")
                cr.openInputStream(doc.uri)!!.use { inp -> tmp.outputStream().use { out ->
                    val buf = ByteArray(1 shl 20)
                    while (true) {
                        val k = inp.read(buf); if (k < 0) break
                        out.write(buf, 0, k); done += k
                        status = Status.Copying(doc.name ?: "", done, total)
                    }
                } }
                if (!tmp.renameTo(dst)) error("could not save ${dst.name}")
            }
            return load()
        } catch (t: Throwable) {
            status = Status.Failed(t.message ?: t.javaClass.simpleName); return null
        }
    }

    fun remove() {
        val old = ready(); status = Status.None; old?.close(); root.deleteRecursively(); config = defaultConfig
    }

    private val ctxApp = ctx.applicationContext
}
