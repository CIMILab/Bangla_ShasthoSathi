@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package org.shastho.app

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.shastho.core.*

/** What the person has on screen after analysis; edits and extra hiding are theirs and stay in memory only. */
class ReportState(val result: PipelineResult, val fromPhoto: Boolean) {
    val labs = mutableStateListOf<LabResult>().apply { addAll(result.labs) }
    val edited = mutableStateListOf<Int>()
    val hidden = mutableStateListOf<String>()
    var feedback by mutableStateOf<Boolean?>(null)
}

private fun Str.num(n: Int) = if (code == "bn") bnDigits(n.toString()) else n.toString()

@Composable
private fun surfaceCard() = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)

@Composable
private fun BackIcon(onBack: () -> Unit) {
    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, LocalStr.current.back) }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
}

@Composable
private fun IconBubble(painter: Painter, tint: Color, bg: Color, size: Int = 44) {
    Box(Modifier.size(size.dp).background(bg, CircleShape), contentAlignment = Alignment.Center) {
        Icon(painter, null, tint = tint, modifier = Modifier.size((size * 0.5).dp))
    }
}

// ============================================================================================ Home
@Composable
fun HomeScreen(reading: Boolean, error: String?, onScan: () -> Unit, onGallery: () -> Unit, onPaste: () -> Unit,
               onSample: () -> Unit, onSettings: () -> Unit) {
    val s = LocalStr.current
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_logo), null, Modifier.size(34.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(s.appName, style = MaterialTheme.typography.titleMedium)
                            Text(s.offline, style = MaterialTheme.typography.bodySmall, color = muted())
                        }
                    }
                },
                actions = { IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, s.settings) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(8.dp))
            Text(s.greeting, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp))

            // Primary action
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Brand.TealLight, Brand.TealDark)))
                    .clickable(enabled = !reading, onClick = onScan).padding(22.dp),
            ) {
                Column {
                    IconBubble(painterResource(R.drawable.ic_camera), Color.White, Color.White.copy(alpha = 0.18f), 52)
                    Spacer(Modifier.height(16.dp))
                    Text(s.scanTitle, style = MaterialTheme.typography.titleLarge, color = Color.White)
                    Text(s.scanBody, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.88f))
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = onScan, enabled = !reading,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Brand.TealDark),
                    ) { Text(s.scanButton) }
                }
            }
            AnimatedVisibility(reading) {
                Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp)); Text(s.reading)
                }
            }
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(Modifier.height(14.dp))
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionTile(painterResource(R.drawable.ic_image), s.gallery, s.galleryBody, !reading, onGallery,
                    Modifier.weight(1f).fillMaxHeight())
                ActionTile(painterResource(R.drawable.ic_paste), s.paste, s.pasteBody, !reading, onPaste,
                    Modifier.weight(1f).fillMaxHeight())
            }
            Spacer(Modifier.height(12.dp))
            Card(onClick = onSample, enabled = !reading, modifier = Modifier.fillMaxWidth(), colors = surfaceCard(),
                shape = RoundedCornerShape(20.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(painterResource(R.drawable.ic_doc), MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.primaryContainer)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.sample, style = MaterialTheme.typography.titleMedium)
                        Text(s.sampleBody, style = MaterialTheme.typography.bodyMedium, color = muted())
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp)) {
                    Icon(painterResource(R.drawable.ic_cloud_off), null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(s.privacyTitle, style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(s.privacyBody, style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }

            SectionTitle(s.howTitle)
            s.steps.forEachIndexed { i, (t, b) ->
                Row(Modifier.padding(vertical = 7.dp)) {
                    Box(Modifier.size(30.dp).background(MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center) {
                        Text(s.num(i + 1), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(t, style = MaterialTheme.typography.titleMedium)
                        Text(b, style = MaterialTheme.typography.bodyMedium, color = muted())
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun ActionTile(painter: Painter, title: String, body: String, enabled: Boolean, onClick: () -> Unit,
                       modifier: Modifier) {
    Card(onClick = onClick, enabled = enabled, modifier = modifier, colors = surfaceCard(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) {
            IconBubble(painter, MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primaryContainer)
            Spacer(Modifier.height(12.dp))
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = muted())
        }
    }
}

// ============================================================================================ Review (human check)
@Composable
fun ReviewScreen(text: String, onText: (String) -> Unit, photo: Bitmap?, ocr: OcrOutput?, fromPhoto: Boolean,
                 busy: Boolean, onBack: () -> Unit, onAnalyse: () -> Unit) {
    val s = LocalStr.current
    var confirmed by remember(ocr) { mutableStateOf(!fromPhoto) }
    var showPhoto by remember { mutableStateOf(true) }
    val rows = remember(text) { runCatching { Rules.parseLabLines(text).size }.getOrDefault(0) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(title = { Text(s.reviewTitle) }, navigationIcon = { BackIcon(onBack) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background))
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp, shadowElevation = 6.dp) {
                Column(Modifier.navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
                    if (fromPhoto) Row(
                        Modifier.fillMaxWidth().selectable(confirmed, onClick = { confirmed = !confirmed }, role = Role.Checkbox),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(confirmed, null)
                        Spacer(Modifier.width(8.dp)); Text(s.confirm, style = MaterialTheme.typography.bodyLarge)
                    }
                    Button(onClick = onAnalyse, enabled = confirmed && text.isNotBlank() && !busy,
                        modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        if (busy) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(Modifier.width(10.dp)); Text(s.analysing)
                        } else Text(s.analyse)
                    }
                }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            if (fromPhoto) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp)
                        .background(MaterialTheme.colorScheme.tertiaryContainer, RoundedCornerShape(16.dp)).padding(14.dp),
                ) {
                    Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.tertiary)
                    Spacer(Modifier.width(12.dp))
                    Text(s.reviewWarn, color = MaterialTheme.colorScheme.onTertiaryContainer, style = MaterialTheme.typography.bodyMedium)
                }
            } else if (text.isBlank()) {
                Text(s.clipboardEmpty, color = muted(), modifier = Modifier.padding(top = 4.dp))
            }
            photo?.let { bmp ->
                TextButton(onClick = { showPhoto = !showPhoto }) { Text(if (showPhoto) s.hidePhoto else s.showPhoto) }
                AnimatedVisibility(showPhoto) {
                    Image(bmp.asImageBitmap(), null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp).clip(RoundedCornerShape(16.dp)))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text((ocr?.let { s.readBy(it.engine, it.ms) + " · " } ?: "") + s.rowsFound(rows),
                style = MaterialTheme.typography.bodySmall, color = muted())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(text, onText, Modifier.fillMaxWidth().heightIn(min = 280.dp), label = { Text(s.textLabel) },
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp))
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ============================================================================================ Report (4 tabs)
@Composable
fun ReportScreen(rep: ReportState, onBack: () -> Unit, onNew: () -> Unit) {
    val s = LocalStr.current
    var tab by remember { mutableIntStateOf(0) }
    var filter by remember { mutableStateOf("all") }
    var detail by remember { mutableStateOf<Int?>(null) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column {
                TopAppBar(
                    title = { Text(s.reportTitle) }, navigationIcon = { BackIcon(onBack) },
                    actions = { TextButton(onClick = onNew) { Text(s.newReport) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                )
                TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                    s.tabs.forEachIndexed { i, t ->
                        Tab(selected = tab == i, onClick = { tab = i },
                            text = { Text(t, maxLines = 1, overflow = TextOverflow.Ellipsis) })
                    }
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            Crossfade(targetState = tab) { t ->
                when (t) {
                    0 -> SummaryTab(rep, onSlice = { f ->
                        filter = when (f) { "high", "low" -> "outside"; "normal" -> "normal"; else -> "all" }; tab = 1
                    }, onOpen = { detail = it })
                    1 -> ResultsTab(rep, filter, { filter = it }, { detail = it })
                    2 -> ExplainTab(rep)
                    else -> PrivacyTab(rep)
                }
            }
        }
    }
    val d = detail
    if (d != null && d in rep.labs.indices) DetailSheet(rep, d) { detail = null }
}

@Composable
private fun TabColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        content = content)
}

@Composable
private fun SummaryTab(rep: ReportState, onSlice: (String) -> Unit, onOpen: (Int) -> Unit) {
    val s = LocalStr.current
    val labs = rep.labs
    TabColumn {
        if (labs.isEmpty()) {
            Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp)) {
                    Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp)); Text(s.noLabs)
                }
            }
        } else {
            val counts = listOf("normal", "high", "low", "unknown").map { f -> f to labs.count { it.flag == f } }
            val outside = labs.count { it.flag == "high" || it.flag == "low" }
            Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusDonut(counts, s.num(outside), s.outsideShort, onSlice, Modifier.size(148.dp))
                    Spacer(Modifier.width(18.dp))
                    Column {
                        Text(s.testsChecked(labs.size), style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        counts.filter { it.second > 0 }.forEach { (f, n) -> LegendItem(f, n) { onSlice(f) } }
                    }
                }
                Text(s.tapHint, style = MaterialTheme.typography.bodySmall, color = muted(),
                    modifier = Modifier.padding(start = 18.dp, end = 18.dp, bottom = 14.dp))
            }

            SectionTitle(s.needsAttention)
            val abnormal = labs.indices.filter { labs[it].flag == "high" || labs[it].flag == "low" }
            if (abnormal.isEmpty()) {
                Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CheckCircle, null, tint = Brand.Normal)
                        Spacer(Modifier.width(12.dp)); Text(s.allNormal)
                    }
                }
            }
            abnormal.forEach { i -> CompactResult(labs[i], i in rep.edited) { onOpen(i) } }
        }

        SectionTitle(s.howMade)
        Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 6.dp)) {
                Provenance(painterResource(if (rep.fromPhoto) R.drawable.ic_camera else R.drawable.ic_paste),
                    if (rep.fromPhoto) s.provPhoto else s.provTyped)
                Provenance(painterResource(R.drawable.ic_rule), s.provRules)
                Provenance(null, s.provTemplate)
                Provenance(painterResource(R.drawable.ic_cloud_off), s.provLocal)
                if (rep.edited.isNotEmpty()) Provenance(null, "${s.editedByYou}: ${s.num(rep.edited.size)}", Icons.Filled.Edit)
            }
        }
        Spacer(Modifier.height(16.dp))
        DoctorNote()
    }
}

@Composable
private fun Provenance(painter: Painter?, text: String, vector: androidx.compose.ui.graphics.vector.ImageVector = Icons.Filled.CheckCircle) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        if (painter != null) Icon(painter, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        else Icon(vector, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun DoctorNote() {
    val s = LocalStr.current
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(16.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
        Spacer(Modifier.width(12.dp))
        Text(s.doctorNote, color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CompactResult(l: LabResult, edited: Boolean, onClick: () -> Unit) {
    val s = LocalStr.current
    val (primary, _) = s.labName(l.name)
    Card(onClick = onClick, colors = surfaceCard(), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(primary, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${Py.g(l.value)} ${l.unit}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(10.dp))
                StatusPill(l.flag)
            }
            RangeGauge(l, Modifier.padding(top = 8.dp), labels = false)
            if (edited) Text(s.editedByYou, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun ResultsTab(rep: ReportState, filter: String, onFilter: (String) -> Unit, onOpen: (Int) -> Unit) {
    val s = LocalStr.current
    val labs = rep.labs
    TabColumn {
        if (labs.isEmpty()) Text(s.noLabs, color = muted()) else ResultsList(rep, filter, onFilter, onOpen)
    }
}

@Composable
private fun ResultsList(rep: ReportState, filter: String, onFilter: (String) -> Unit, onOpen: (Int) -> Unit) {
    val s = LocalStr.current
    val labs = rep.labs
    Column {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("all" to s.filterAll, "outside" to s.filterOutside, "normal" to s.filterNormal).forEach { (k, t) ->
                FilterChip(selected = filter == k, onClick = { onFilter(k) }, label = { Text(t) })
            }
        }
        Spacer(Modifier.height(8.dp))
        labs.indices.filter { i ->
            val f = labs[i].flag
            when (filter) { "outside" -> f == "high" || f == "low"; "normal" -> f == "normal"; else -> true }
        }.forEach { i -> ResultCard(labs[i], i in rep.edited) { onOpen(i) } }
        Spacer(Modifier.height(12.dp))
        DoctorNote()
    }
}

@Composable
private fun ResultCard(l: LabResult, edited: Boolean, onClick: () -> Unit) {
    val s = LocalStr.current
    val (primary, secondary) = s.labName(l.name)
    Card(onClick = onClick, colors = surfaceCard(), shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).animateContentSize()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(primary, style = MaterialTheme.typography.titleMedium)
                    secondary?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = muted()) }
                }
                StatusPill(l.flag)
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(Py.g(l.value), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Text(l.unit, style = MaterialTheme.typography.bodyMedium, color = muted(), modifier = Modifier.padding(bottom = 3.dp))
                Spacer(Modifier.weight(1f))
                Text("${s.normalRange}: ${s.range(l.low?.let { Py.g(it) }, l.high?.let { Py.g(it) })}",
                    style = MaterialTheme.typography.bodySmall, color = muted(), modifier = Modifier.padding(bottom = 3.dp))
            }
            RangeGauge(l, Modifier.padding(top = 10.dp))
            if (edited) Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Edit, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text(s.editedByYou, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

/** Tap-for-detail sheet: what the flag means (fixed wording, no interpretation) and a way to correct a misread value. */
@Composable
private fun DetailSheet(rep: ReportState, i: Int, onDismiss: () -> Unit) {
    val s = LocalStr.current
    val l = rep.labs[i]
    val (primary, secondary) = s.labName(l.name)
    var editing by remember(i) { mutableStateOf(false) }
    var field by remember(i) { mutableStateOf(Py.g(l.value)) }
    var bad by remember(i) { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 28.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(primary, style = MaterialTheme.typography.titleLarge)
                    secondary?.let { Text(it, color = muted()) }
                }
                StatusPill(l.flag)
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    Text(s.yourValue, style = MaterialTheme.typography.bodySmall, color = muted())
                    Text("${Py.g(l.value)} ${l.unit}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(s.normalRange, style = MaterialTheme.typography.bodySmall, color = muted())
                    Text(s.range(l.low?.let { Py.g(it) }, l.high?.let { Py.g(it) }), style = MaterialTheme.typography.titleMedium)
                }
            }
            RangeGauge(l, Modifier.padding(top = 12.dp))
            Spacer(Modifier.height(8.dp))
            Text(s.meaning(l.flag), style = MaterialTheme.typography.bodyLarge)
            Text(s.askDoctor, style = MaterialTheme.typography.bodyMedium, color = muted(), modifier = Modifier.padding(top = 4.dp))
            HorizontalDivider(Modifier.padding(vertical = 16.dp))
            if (!editing) {
                OutlinedButton(onClick = { editing = true }) {
                    Icon(Icons.Filled.Edit, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(s.correct)
                }
            } else {
                Text(s.correctHint, style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    field, { field = it; bad = false }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                    suffix = { Text(l.unit) }, isError = bad,
                    supportingText = { if (bad) Text(s.invalidNumber) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { editing = false; field = Py.g(l.value); bad = false }) { Text(s.cancel) }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val v = Py.toAsciiDigits(field.trim()).replace(',', '.').toDoubleOrNull()
                        if (v == null) bad = true else {
                            rep.labs[i] = l.copy(value = v, flag = Rules.flagValue(v, l.low, l.high))
                            if (i !in rep.edited) rep.edited.add(i)
                            editing = false
                        }
                    }) { Text(s.save) }
                }
            }
        }
    }
}

@Composable
private fun ExplainTab(rep: ReportState) {
    val s = LocalStr.current
    val clip = LocalClipboardManager.current
    val labs = rep.labs.toList()
    val text = remember(labs, s.code) { Explain.template(labs, s.code) }
    val lines = text.split("\n")
    var copied by remember { mutableStateOf(false) }
    TabColumn {
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(s.explSource, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(s.explSourceBody, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp)) {
                lines.forEachIndexed { k, line ->
                    if (k < labs.size) Row(Modifier.padding(vertical = 7.dp)) {
                        Icon(statusIcon(labs[k].flag), null, tint = Brand.status(labs[k].flag),
                            modifier = Modifier.size(22.dp).padding(top = 3.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(line, style = MaterialTheme.typography.bodyLarge, fontSize = 17.sp, lineHeight = 27.sp)
                    } else Text(line, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
        Row(Modifier.padding(top = 8.dp)) {
            TextButton(onClick = { clip.setText(AnnotatedString(text)); copied = true }) { Text(if (copied) s.copied else s.copy) }
        }

        SectionTitle(s.clearQ)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(selected = rep.feedback == true, onClick = { rep.feedback = true },
                label = { Text(s.yes) }, leadingIcon = { Icon(Icons.Filled.ThumbUp, null, Modifier.size(18.dp)) })
            FilterChip(selected = rep.feedback == false, onClick = { rep.feedback = false },
                label = { Text(s.no) }, leadingIcon = { Icon(Icons.Filled.Warning, null, Modifier.size(18.dp)) })
        }
        rep.feedback?.let {
            Text(if (it) s.thanksYes else s.thanksNo, style = MaterialTheme.typography.bodyMedium, color = muted(),
                modifier = Modifier.padding(top = 8.dp))
        }
        Spacer(Modifier.height(16.dp))
        DoctorNote()
    }
}

private val TAG = Regex("""\[([A-Z][A-Z_]*)]""")

@Composable
private fun PrivacyTab(rep: ReportState) {
    val s = LocalStr.current
    val clip = LocalClipboardManager.current
    val tagBg = MaterialTheme.colorScheme.primaryContainer
    val tagFg = MaterialTheme.colorScheme.onPrimaryContainer
    val hidden = rep.hidden.toList()
    val shown = remember(hidden, s.code, tagBg) {
        var t = rep.result.redactedText
        hidden.forEach { w -> if (w.isNotBlank()) t = t.replace(w, "[HIDDEN]") }
        buildAnnotatedString {
            var last = 0
            for (m in TAG.findAll(t)) {
                append(t.substring(last, m.range.first))
                withStyle(SpanStyle(background = tagBg, color = tagFg, fontWeight = FontWeight.Bold)) {
                    append("⟨" + s.tag(m.groupValues[1]) + "⟩")
                }
                last = m.range.last + 1
            }
            append(t.substring(last))
        }
    }
    var word by remember { mutableStateOf("") }
    var copied by remember { mutableStateOf(false) }
    TabColumn {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(painterResource(R.drawable.ic_cloud_off), MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primaryContainer)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(s.privTitle, style = MaterialTheme.typography.titleMedium)
                Text(s.privBody, style = MaterialTheme.typography.bodyMedium, color = muted())
            }
        }
        val counts = rep.result.removed.toList() + (if (hidden.isNotEmpty()) listOf("HIDDEN" to hidden.size) else emptyList())
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (counts.isEmpty()) Text(s.nothingFound, color = muted())
            counts.forEach { (k, v) ->
                AssistChip(onClick = {}, label = { Text("${s.tag(k)} × ${s.num(v)}") },
                    leadingIcon = { Icon(Icons.Filled.Lock, null, Modifier.size(16.dp)) })
            }
        }
        Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            SelectionContainer {
                Text(shown, Modifier.padding(16.dp), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 20.sp)
            }
        }
        TextButton(onClick = { clip.setText(AnnotatedString(shown.text)); copied = true }) { Text(if (copied) s.copied else s.copyPrivate) }

        SectionTitle(s.hideMore)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(word, { word = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text(s.hideHint) })
            Spacer(Modifier.width(10.dp))
            Button(onClick = { if (word.isNotBlank()) { rep.hidden.add(word.trim()); word = "" } }, enabled = word.isNotBlank()) {
                Text(s.hide)
            }
        }
    }
}

// ============================================================================================ Settings
@Composable
fun SettingsScreen(lang: String, onLang: (String) -> Unit, mode: OcrMode, onMode: (OcrMode) -> Unit,
                   onResearch: () -> Unit, onBack: () -> Unit,
                   models: ModelStore, onPickModels: () -> Unit, onRemoveModels: () -> Unit) {
    val s = LocalStr.current
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(title = { Text(s.settings) }, navigationIcon = { BackIcon(onBack) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background))
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            SectionTitle(s.language)
            Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth()) {
                listOf("bn" to "বাংলা", "en" to "English").forEach { (k, t) -> RadioRow(t, lang == k) { onLang(k) } }
            }
            SectionTitle(s.reader)
            Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth()) {
                listOf(OcrMode.AUTO to s.readerAuto, OcrMode.MLKIT to s.readerLatin, OcrMode.TESS to s.readerBengali)
                    .forEach { (m, t) -> RadioRow(t, mode == m) { onMode(m) } }
            }
            SectionTitle(s.modelsTitle)
            Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    val st = models.status
                    val busy = st is ModelStore.Status.Copying || st is ModelStore.Status.Loading
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Lock, null, tint = if (st is ModelStore.Status.Ready) MaterialTheme.colorScheme.primary else muted())
                        Spacer(Modifier.width(12.dp))
                        Text(when (st) {
                            is ModelStore.Status.None -> s.modelsNone
                            is ModelStore.Status.Loading -> s.modelsLoading
                            is ModelStore.Status.Copying -> s.modelsCopying(st.file, (100 * st.done / maxOf(st.total, 1)).toInt())
                            is ModelStore.Status.Ready -> s.modelsReady(st.set.all.size, (st.set.bytes / 1048576).toInt())
                            is ModelStore.Status.Failed -> s.modelsFailed(st.message)
                        }, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    }
                    if (st is ModelStore.Status.Copying) LinearProgressIndicator(
                        progress = { st.done.toFloat() / maxOf(st.total, 1) }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    if (st is ModelStore.Status.Loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 10.dp))
                    Text(s.modelsHelp, style = MaterialTheme.typography.bodySmall, color = muted(), modifier = Modifier.padding(top = 10.dp))
                    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onPickModels, enabled = !busy) { Text(s.modelsLoad) }
                        if (st is ModelStore.Status.Ready || st is ModelStore.Status.Failed)
                            OutlinedButton(onClick = onRemoveModels, enabled = !busy) { Text(s.modelsRemove) }
                    }
                }
            }
            SectionTitle(s.research)
            Card(onClick = onResearch, colors = surfaceCard(), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(painterResource(R.drawable.ic_science), null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(14.dp))
                    Text(s.researchBody, Modifier.weight(1f))
                    Text("›", style = MaterialTheme.typography.titleLarge, color = muted())
                }
            }
            SectionTitle(s.about)
            Card(colors = surfaceCard(), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.ic_logo), null, Modifier.size(44.dp))
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(s.appName, style = MaterialTheme.typography.titleMedium)
                        Text(s.aboutBody, style = MaterialTheme.typography.bodyMedium, color = muted())
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun RadioRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().selectable(selected, onClick = onClick, role = Role.RadioButton).padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected, null)
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(vertical = 12.dp))
    }
}
