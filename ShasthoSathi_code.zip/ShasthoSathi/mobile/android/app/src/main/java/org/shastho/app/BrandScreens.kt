@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package org.shastho.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Brand intro shown right after the system splash (same teal background, so the two read as one animation):
 * the shield mark settles in and the name fades up. About one second.
 */
@Composable
fun BrandIntro(onDone: () -> Unit) {
    val scale = remember { Animatable(0.82f) }
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
        fade.animateTo(1f, tween(500, delayMillis = 250))
        delay(650)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Brand.Teal, Brand.TealDark))),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.ic_launcher_foreground), null,
                Modifier.size(200.dp).graphicsLayer { scaleX = scale.value; scaleY = scale.value })
            Column(Modifier.alpha(fade.value).offset(y = (-28).dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ShasthoSathi", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text("স্বাস্থ্যসাথী", style = MaterialTheme.typography.titleLarge, color = Color.White.copy(alpha = 0.85f))
            }
        }
        Text("On-device · Private", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 32.dp).alpha(fade.value))
    }
}

/** First launch: choose the interface language. Each option is written in its own language. */
@Composable
fun LanguageScreen(onPick: (String) -> Unit) {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.widthIn(max = 480.dp)) {
            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(84.dp))
            Spacer(Modifier.height(20.dp))
            Text("ভাষা বেছে নিন", style = MaterialTheme.typography.headlineSmall)
            Text("Choose your language", style = MaterialTheme.typography.titleMedium, color = muted(),
                fontWeight = FontWeight.Normal)
            Spacer(Modifier.height(28.dp))
            LanguageOption("বাংলা", "অ্যাপের সব লেখা ও ব্যাখ্যা বাংলায়") { onPick("bn") }
            Spacer(Modifier.height(12.dp))
            LanguageOption("English", "All screens and explanations in English") { onPick("en") }
            Spacer(Modifier.height(24.dp))
            Text("পরে সেটিংস থেকে বদলাতে পারবেন · You can change this later in Settings",
                style = MaterialTheme.typography.bodyMedium, color = muted(), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun LanguageOption(title: String, body: String, onClick: () -> Unit) {
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(body, style = MaterialTheme.typography.bodyMedium, color = muted())
            }
            Text("›", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}
