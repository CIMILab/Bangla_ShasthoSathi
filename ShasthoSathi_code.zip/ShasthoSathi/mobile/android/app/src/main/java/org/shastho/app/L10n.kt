package org.shastho.app

import androidx.compose.runtime.staticCompositionLocalOf

/**
 * The whole user interface in one language at a time. Bengali and English are two complete, separate string sets
 * (no mixed "বাংলা / English" labels); the user picks one on first launch and can switch in Settings.
 * The explanation text itself comes from the core template in the same language (Explain.template).
 */
interface Str {
    val code: String               // "bn" or "en": also the language of the explanation
    val appName: String
    val tagline: String
    val offline: String
    val greeting: String
    val scanTitle: String
    val scanBody: String
    val scanButton: String
    val gallery: String
    val galleryBody: String
    val paste: String
    val pasteBody: String
    val sample: String
    val sampleBody: String
    val privacyTitle: String
    val privacyBody: String
    val howTitle: String
    val steps: List<Pair<String, String>>
    val reading: String
    val readFailed: String
    val clipboardEmpty: String
    val reviewTitle: String
    val reviewWarn: String
    val confirm: String
    val textLabel: String
    val showPhoto: String
    val hidePhoto: String
    val analyse: String
    val analysing: String
    fun readBy(engine: String, ms: Long): String
    fun rowsFound(n: Int): String
    val reportTitle: String
    val tabs: List<String>
    fun testsChecked(n: Int): String
    val outsideShort: String
    fun flag(f: String): String
    val needsAttention: String
    val allNormal: String
    val noLabs: String
    val tapHint: String
    val howMade: String
    val provPhoto: String
    val provTyped: String
    val provRules: String
    val provTemplate: String
    val provLocal: String
    val doctorNote: String
    val filterAll: String
    val filterOutside: String
    val filterNormal: String
    val yourValue: String
    val normalRange: String
    fun range(lo: String?, hi: String?): String
    fun meaning(f: String): String
    val askDoctor: String
    val correct: String
    val correctHint: String
    val editedByYou: String
    val save: String
    val cancel: String
    val invalidNumber: String
    val explSource: String
    val explSourceBody: String
    val clearQ: String
    val yes: String
    val no: String
    val thanksYes: String
    val thanksNo: String
    val copy: String
    val copied: String
    val privTitle: String
    val privBody: String
    val nothingFound: String
    val hideMore: String
    val hideHint: String
    val hide: String
    val copyPrivate: String
    fun tag(t: String): String
    val settings: String
    val language: String
    val reader: String
    val readerAuto: String
    val readerLatin: String
    val readerBengali: String
    val research: String
    val researchBody: String
    val about: String
    val aboutBody: String
    val modelsTitle: String
    val modelsHelp: String
    val modelsNone: String
    val modelsLoading: String
    fun modelsCopying(file: String, pct: Int): String
    fun modelsReady(n: Int, mb: Int): String
    fun modelsFailed(msg: String): String
    val modelsLoad: String
    val modelsRemove: String
    val back: String
    val newReport: String
    val close: String
    val chooseSample: String
    val sampleNote: String
    fun sampleTitle(t: String): String
    fun labName(name: String): Pair<String, String?>   // primary name, secondary name
}

object En : Str {
    override val code = "en"
    override val appName = "ShasthoSathi"
    override val tagline = "Understand your health reports — privately, on your phone."
    override val offline = "Offline · works without internet"
    override val greeting = "What would you like to check today?"
    override val scanTitle = "Scan a report"
    override val scanBody = "Take a photo of a lab report or prescription."
    override val scanButton = "Open camera"
    override val gallery = "From gallery"
    override val galleryBody = "A photo you took earlier"
    override val paste = "Paste text"
    override val pasteBody = "Report text you copied"
    override val sample = "Try a sample"
    override val sampleBody = "Invented example reports"
    override val privacyTitle = "Private by design"
    override val privacyBody = "Everything happens on this phone. The app has no internet permission, and photos are deleted after reading."
    override val howTitle = "How it works"
    override val steps = listOf(
        "Read" to "Reads the text from your photo, and you check it.",
        "Protect" to "Hides personal details such as names and phone numbers.",
        "Explain" to "Explains each result in plain words, using the range printed on your report.")
    override val reading = "Reading the photo on this phone…"
    override val readFailed = "The photo could not be read. Try again with more light and the page held flat."
    override val clipboardEmpty = "There is no text on the clipboard. You can type it below."
    override val reviewTitle = "Check the text"
    override val reviewWarn = "Compare it with the photo and fix any wrong number — a single wrong digit can change a result."
    override val confirm = "I have checked the numbers"
    override val textLabel = "Report text"
    override val showPhoto = "Show photo"
    override val hidePhoto = "Hide photo"
    override val analyse = "Analyse report"
    override val analysing = "Analysing on this phone…"
    override fun readBy(engine: String, ms: Long) = "Read by $engine in $ms ms"
    override fun rowsFound(n: Int) = if (n == 1) "1 test result found" else "$n test results found"
    override val reportTitle = "Your report"
    override val tabs = listOf("Summary", "Results", "Explanation", "Privacy")
    override fun testsChecked(n: Int) = if (n == 1) "1 test checked" else "$n tests checked"
    override val outsideShort = "outside range"
    override fun flag(f: String) = when (f) { "high" -> "High"; "low" -> "Low"; "normal" -> "Normal"; else -> "No range" }
    override val needsAttention = "Needs attention"
    override val allNormal = "All results are within the normal range printed on your report."
    override val noLabs = "No test results (name, value, unit, range) were found in this report. You can still see the protected text under Privacy."
    override val tapHint = "Tap the chart or any result for details."
    override val howMade = "How this was made"
    override val provPhoto = "Text read from your photo — checked by you"
    override val provTyped = "Text entered by you"
    override val provRules = "High and low decided by fixed rules, using the range on your report"
    override val provTemplate = "Explanation written from checked facts — no AI guessing"
    override val provLocal = "Processed on this phone only"
    override val doctorNote = "This app does not diagnose. Please show your report to a doctor."
    override val filterAll = "All"
    override val filterOutside = "Outside range"
    override val filterNormal = "Normal"
    override val yourValue = "Your value"
    override val normalRange = "Normal range"
    override fun range(lo: String?, hi: String?) = when {
        lo != null && hi != null -> "$lo – $hi"; hi != null -> "below $hi"; lo != null -> "above $lo"; else -> "not given"
    }
    override fun meaning(f: String) = when (f) {
        "high" -> "Your value is above the normal range printed on the report."
        "low" -> "Your value is below the normal range printed on the report."
        "normal" -> "Your value is within the normal range printed on the report."
        else -> "The report gives no normal range for this test."
    }
    override val askDoctor = "Ask your doctor what this means for you."
    override val correct = "Correct this value"
    override val correctHint = "If it does not match the paper, type the right value"
    override val editedByYou = "Corrected by you"
    override val save = "Save"
    override val cancel = "Cancel"
    override val invalidNumber = "Please enter a number"
    override val explSource = "Checked explanation"
    override val explSourceBody = "Every number comes from your report. Written by fixed rules, not by a chatbot."
    override val clearQ = "Was this explanation clear?"
    override val yes = "Yes, clear"
    override val no = "Something is wrong"
    override val thanksYes = "Thank you. Your answer stays on this phone."
    override val thanksNo = "Thank you. If a value was read wrongly, correct it under Results."
    override val copy = "Copy"
    override val copied = "Copied"
    override val privTitle = "Personal details hidden"
    override val privBody = "These details were found and hidden on this phone. Nothing was sent anywhere."
    override val nothingFound = "No personal details were found."
    override val hideMore = "Hide something else"
    override val hideHint = "Word or number to hide"
    override val hide = "Hide"
    override val copyPrivate = "Copy protected text"
    override fun tag(t: String) = when (t) {
        "PHONE" -> "Phone number"; "NID" -> "National ID"; "ID" -> "ID number"; "FACILITY" -> "Hospital / lab"
        "ADDRESS" -> "Address"; "DATE" -> "Date"; "NAME" -> "Name"; "DOCTOR" -> "Doctor's name"
        "PII" -> "Personal detail"; "HIDDEN" -> "Hidden by you"; else -> t
    }
    override val settings = "Settings"
    override val language = "Language"
    override val reader = "Text reading"
    override val readerAuto = "Automatic (recommended)"
    override val readerLatin = "English text only"
    override val readerBengali = "Bengali and English"
    override val research = "Research tools"
    override val researchBody = "Speed test, self-test and photo evaluation (E8)"
    override val about = "About"
    override val aboutBody = "Version 0.4 · offline · no internet permission. A research prototype; not medical advice."
    override val modelsTitle = "Privacy models"
    override val modelsHelp = "Three small AI models find names and other personal details that the built-in rules miss. " +
        "Copy the ShasthoSathi model folder to this phone (for example Download/ShasthoSathi), then pick it here. " +
        "They are copied into the app once and run only on this phone."
    override val modelsNone = "Not loaded: personal details are hidden by rules only."
    override val modelsLoading = "Loading the models…"
    override fun modelsCopying(file: String, pct: Int) = "Copying $file… $pct%"
    override fun modelsReady(n: Int, mb: Int) = "Active: $n models ($mb MB), on this phone only."
    override fun modelsFailed(msg: String) = "Could not load the models: $msg"
    override val modelsLoad = "Load privacy models"
    override val modelsRemove = "Remove"
    override val back = "Back"
    override val newReport = "New report"
    override val close = "Close"
    override val chooseSample = "Choose a sample"
    override val sampleNote = "All samples are invented — no real patient data."
    override fun sampleTitle(t: String) = t.replace("বাংলা নোট", "Bengali note")
    override fun labName(name: String): Pair<String, String?> = name to null
}

object Bn : Str {
    override val code = "bn"
    override val appName = "স্বাস্থ্যসাথী"
    override val tagline = "আপনার স্বাস্থ্য রিপোর্ট বুঝুন — নিরাপদে, নিজের ফোনেই।"
    override val offline = "অফলাইন · ইন্টারনেট ছাড়াই চলে"
    override val greeting = "আজ কোন রিপোর্টটি দেখবেন?"
    override val scanTitle = "রিপোর্ট স্ক্যান করুন"
    override val scanBody = "ল্যাব রিপোর্ট বা প্রেসক্রিপশনের ছবি তুলুন।"
    override val scanButton = "ক্যামেরা খুলুন"
    override val gallery = "গ্যালারি থেকে"
    override val galleryBody = "আগে তোলা ছবি"
    override val paste = "লেখা পেস্ট করুন"
    override val pasteBody = "কপি করা রিপোর্টের লেখা"
    override val sample = "নমুনা দেখুন"
    override val sampleBody = "কাল্পনিক উদাহরণ রিপোর্ট"
    override val privacyTitle = "গোপনীয়তা সবার আগে"
    override val privacyBody = "সব কাজ এই ফোনেই হয়। অ্যাপটির ইন্টারনেট ব্যবহারের অনুমতি নেই, আর পড়া শেষ হলে ছবি মুছে ফেলা হয়।"
    override val howTitle = "কীভাবে কাজ করে"
    override val steps = listOf(
        "পড়া" to "ছবি থেকে লেখা পড়ে, আর আপনি তা মিলিয়ে নেন।",
        "সুরক্ষা" to "নাম, ফোন নম্বরের মতো ব্যক্তিগত তথ্য লুকিয়ে ফেলে।",
        "ব্যাখ্যা" to "রিপোর্টে ছাপা স্বাভাবিক সীমা ধরে প্রতিটি ফল সহজ ভাষায় বলে।")
    override val reading = "এই ফোনেই ছবিটি পড়া হচ্ছে…"
    override val readFailed = "ছবিটি পড়া যায়নি। আরও আলোতে, কাগজ সোজা রেখে আবার চেষ্টা করুন।"
    override val clipboardEmpty = "ক্লিপবোর্ডে কোনো লেখা নেই। নিচে লিখে দিতে পারেন।"
    override val reviewTitle = "লেখাটি মিলিয়ে নিন"
    override val reviewWarn = "ছবির সাথে মিলিয়ে দেখুন, কোনো সংখ্যা ভুল থাকলে ঠিক করুন — একটি অঙ্ক ভুল হলেই ফল বদলে যেতে পারে।"
    override val confirm = "আমি সংখ্যাগুলো মিলিয়ে দেখেছি"
    override val textLabel = "রিপোর্টের লেখা"
    override val showPhoto = "ছবি দেখুন"
    override val hidePhoto = "ছবি লুকান"
    override val analyse = "রিপোর্ট বিশ্লেষণ করুন"
    override val analysing = "এই ফোনেই বিশ্লেষণ হচ্ছে…"
    override fun readBy(engine: String, ms: Long) = "$engine দিয়ে পড়া হয়েছে · ${bnDigits(ms.toString())} মি.সে."
    override fun rowsFound(n: Int) = "${bnDigits(n.toString())}টি পরীক্ষার ফল পাওয়া গেছে"
    override val reportTitle = "আপনার রিপোর্ট"
    override val tabs = listOf("সারসংক্ষেপ", "ফলাফল", "ব্যাখ্যা", "গোপনীয়তা")
    override fun testsChecked(n: Int) = "${bnDigits(n.toString())}টি পরীক্ষা দেখা হয়েছে"
    override val outsideShort = "সীমার বাইরে"
    override fun flag(f: String) = when (f) { "high" -> "বেশি"; "low" -> "কম"; "normal" -> "স্বাভাবিক"; else -> "সীমা নেই" }
    override val needsAttention = "যেগুলোতে নজর দিন"
    override val allNormal = "সব ফল আপনার রিপোর্টে ছাপা স্বাভাবিক সীমার মধ্যে আছে।"
    override val noLabs = "এই রিপোর্টে কোনো পরীক্ষার ফল (নাম, মান, একক, সীমা) পাওয়া যায়নি। সুরক্ষিত লেখাটি 'গোপনীয়তা' অংশে দেখতে পারেন।"
    override val tapHint = "চার্টে বা যেকোনো ফলে চাপ দিলে বিস্তারিত দেখাবে।"
    override val howMade = "কীভাবে তৈরি হলো"
    override val provPhoto = "লেখা আপনার ছবি থেকে পড়া — আপনি মিলিয়ে দেখেছেন"
    override val provTyped = "লেখা আপনি দিয়েছেন"
    override val provRules = "বেশি/কম ঠিক হয়েছে নির্দিষ্ট নিয়মে, আপনার রিপোর্টে ছাপা সীমা ধরে"
    override val provTemplate = "ব্যাখ্যা যাচাই করা তথ্য থেকে লেখা — কোনো এআই অনুমান নেই"
    override val provLocal = "সব কাজ শুধু এই ফোনে হয়েছে"
    override val doctorNote = "এই অ্যাপ রোগ নির্ণয় করে না। রিপোর্টটি অবশ্যই ডাক্তারকে দেখান।"
    override val filterAll = "সব"
    override val filterOutside = "সীমার বাইরে"
    override val filterNormal = "স্বাভাবিক"
    override val yourValue = "আপনার মান"
    override val normalRange = "স্বাভাবিক সীমা"
    override fun range(lo: String?, hi: String?) = when {
        lo != null && hi != null -> "$lo – $hi"; hi != null -> "$hi-এর কম"; lo != null -> "$lo-এর বেশি"; else -> "দেওয়া নেই"
    }
    override fun meaning(f: String) = when (f) {
        "high" -> "আপনার মান রিপোর্টে ছাপা স্বাভাবিক সীমার চেয়ে বেশি।"
        "low" -> "আপনার মান রিপোর্টে ছাপা স্বাভাবিক সীমার চেয়ে কম।"
        "normal" -> "আপনার মান রিপোর্টে ছাপা স্বাভাবিক সীমার মধ্যে আছে।"
        else -> "রিপোর্টে এই পরীক্ষার স্বাভাবিক সীমা দেওয়া নেই।"
    }
    override val askDoctor = "এর অর্থ আপনার জন্য কী, তা ডাক্তারের কাছে জেনে নিন।"
    override val correct = "মানটি ঠিক করুন"
    override val correctHint = "কাগজের সাথে না মিললে সঠিক মানটি লিখুন"
    override val editedByYou = "আপনি ঠিক করেছেন"
    override val save = "সংরক্ষণ"
    override val cancel = "বাতিল"
    override val invalidNumber = "একটি সংখ্যা লিখুন"
    override val explSource = "যাচাই করা ব্যাখ্যা"
    override val explSourceBody = "প্রতিটি সংখ্যা আপনার রিপোর্ট থেকে নেওয়া। নির্দিষ্ট নিয়মে লেখা, চ্যাটবটের অনুমানে নয়।"
    override val clearQ = "ব্যাখ্যাটি কি বোঝা গেল?"
    override val yes = "হ্যাঁ, বুঝেছি"
    override val no = "কিছু ভুল আছে"
    override val thanksYes = "ধন্যবাদ। আপনার উত্তর এই ফোনেই থাকে।"
    override val thanksNo = "ধন্যবাদ। কোনো মান ভুল পড়া হলে 'ফলাফল' অংশে ঠিক করে দিন।"
    override val copy = "কপি করুন"
    override val copied = "কপি হয়েছে"
    override val privTitle = "ব্যক্তিগত তথ্য লুকানো হয়েছে"
    override val privBody = "এই তথ্যগুলো এই ফোনেই খুঁজে লুকানো হয়েছে। কিছুই কোথাও পাঠানো হয়নি।"
    override val nothingFound = "কোনো ব্যক্তিগত তথ্য পাওয়া যায়নি।"
    override val hideMore = "আরও কিছু লুকান"
    override val hideHint = "যে শব্দ বা সংখ্যা লুকাতে চান"
    override val hide = "লুকান"
    override val copyPrivate = "সুরক্ষিত লেখা কপি করুন"
    override fun tag(t: String) = when (t) {
        "PHONE" -> "ফোন নম্বর"; "NID" -> "জাতীয় পরিচয়পত্র"; "ID" -> "আইডি নম্বর"; "FACILITY" -> "হাসপাতাল / ল্যাব"
        "ADDRESS" -> "ঠিকানা"; "DATE" -> "তারিখ"; "NAME" -> "নাম"; "DOCTOR" -> "ডাক্তারের নাম"
        "PII" -> "ব্যক্তিগত তথ্য"; "HIDDEN" -> "আপনি লুকিয়েছেন"; else -> t
    }
    override val settings = "সেটিংস"
    override val language = "ভাষা"
    override val reader = "লেখা পড়ার পদ্ধতি"
    override val readerAuto = "স্বয়ংক্রিয় (প্রস্তাবিত)"
    override val readerLatin = "শুধু ইংরেজি লেখা"
    override val readerBengali = "বাংলা ও ইংরেজি"
    override val research = "গবেষণার টুল"
    override val researchBody = "গতি পরীক্ষা, সেলফ-টেস্ট ও ছবি মূল্যায়ন (E8, ইংরেজিতে)"
    override val about = "অ্যাপ সম্পর্কে"
    override val aboutBody = "সংস্করণ ০.৪ · অফলাইন · ইন্টারনেট অনুমতি নেই। এটি একটি গবেষণা প্রোটোটাইপ; চিকিৎসা পরামর্শ নয়।"
    override val modelsTitle = "গোপনীয়তা মডেল"
    override val modelsHelp = "তিনটি ছোট এআই মডেল নাম ও অন্যান্য ব্যক্তিগত তথ্য খুঁজে বের করে, যা নিয়মে ধরা পড়ে না। " +
        "ShasthoSathi মডেল ফোল্ডারটি এই ফোনে কপি করুন (যেমন Download/ShasthoSathi), তারপর এখানে বেছে নিন। " +
        "মডেলগুলো একবার অ্যাপে কপি হয় এবং শুধু এই ফোনেই চলে।"
    override val modelsNone = "লোড করা হয়নি: ব্যক্তিগত তথ্য শুধু নিয়ম দিয়ে লুকানো হচ্ছে।"
    override val modelsLoading = "মডেল লোড হচ্ছে…"
    override fun modelsCopying(file: String, pct: Int) = bnDigits("$file কপি হচ্ছে… $pct%")
    override fun modelsReady(n: Int, mb: Int) = bnDigits("চালু: $n টি মডেল ($mb MB), শুধু এই ফোনে।")
    override fun modelsFailed(msg: String) = "মডেল লোড করা যায়নি: $msg"
    override val modelsLoad = "গোপনীয়তা মডেল লোড করুন"
    override val modelsRemove = "মুছে ফেলুন"
    override val back = "ফিরে যান"
    override val newReport = "নতুন রিপোর্ট"
    override val close = "বন্ধ করুন"
    override val chooseSample = "একটি নমুনা বেছে নিন"
    override val sampleNote = "সব নমুনা কাল্পনিক — কোনো আসল রোগীর তথ্য নেই।"
    override fun sampleTitle(t: String) = bnDigits(t.replace("Lab report", "ল্যাব রিপোর্ট").replace("Prescription", "প্রেসক্রিপশন"))
    // Patient-facing Bengali name first, the printed (English) name second so it can be matched to the paper.
    override fun labName(name: String): Pair<String, String?> =
        org.shastho.core.Explain.bnLabel(name)?.let { it to name } ?: (name to null)
}

fun bnDigits(s: String): String = buildString { s.forEach { c -> append(if (c in '0'..'9') '০' + (c - '0') else c) } }

val LocalStr = staticCompositionLocalOf<Str> { Bn }
