package org.shastho.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.shastho.core.LabResult
import org.shastho.core.Py
import kotlin.math.abs
import kotlin.math.atan2

fun statusIcon(flag: String): ImageVector = when (flag) {
    "high" -> Icons.Filled.KeyboardArrowUp
    "low" -> Icons.Filled.KeyboardArrowDown
    "normal" -> Icons.Filled.CheckCircle
    else -> Icons.Filled.Info
}

/** Status shown as icon + word on a tinted pill: never colour alone. */
@Composable
fun StatusPill(flag: String, modifier: Modifier = Modifier) {
    val s = LocalStr.current
    val c = Brand.status(flag)
    Row(
        modifier.background(c.copy(alpha = 0.14f), RoundedCornerShape(50)).padding(start = 6.dp, end = 10.dp, top = 3.dp, bottom = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(statusIcon(flag), null, tint = c, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(s.flag(flag), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
    }
}

/**
 * Donut of result counts by status (animated sweep). Tapping a slice reports its status, so the screen can open the
 * matching filtered list: the chart is a way into the results, not just a picture.
 */
@Composable
fun StatusDonut(counts: List<Pair<String, Int>>, center: String, centerSub: String, onSlice: (String) -> Unit,
                modifier: Modifier = Modifier) {
    val total = counts.sumOf { it.second }.coerceAtLeast(1)
    val sweep = remember { Animatable(0f) }
    LaunchedEffect(counts) { sweep.snapTo(0f); sweep.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    val track = MaterialTheme.colorScheme.surfaceVariant
    val gapDeg = if (counts.count { it.second > 0 } > 1) 2.5f else 0f
    Box(
        modifier.pointerInput(counts) {
            detectTapGestures { p ->
                val cx = size.width / 2f; val cy = size.height / 2f
                val ang = ((Math.toDegrees(atan2((p.y - cy).toDouble(), (p.x - cx).toDouble())) + 90.0 + 360.0) % 360.0)
                var acc = 0.0
                for ((k, v) in counts) {
                    val sw = 360.0 * v / total
                    if (v > 0 && ang < acc + sw) { onSlice(k); break }
                    acc += sw
                }
            }
        },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = size.minDimension * 0.15f
            val d = size.minDimension - stroke
            val tl = Offset((size.width - d) / 2f, (size.height - d) / 2f)
            drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(stroke))
            var start = -90f
            counts.forEach { (k, v) ->
                if (v > 0) {
                    val sw = 360f * v / total * sweep.value
                    drawArc(Brand.status(k), start + gapDeg / 2f, (sw - gapDeg).coerceAtLeast(0.5f), false, tl, Size(d, d),
                        style = Stroke(stroke, cap = StrokeCap.Butt))
                    start += sw
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(center, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(centerSub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Legend row for the donut: dot + label + count; tappable like the slices. */
@Composable
fun LegendItem(flag: String, count: Int, onClick: () -> Unit) {
    val s = LocalStr.current
    Row(
        Modifier.clickableNoRipple(onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(10.dp).background(Brand.status(flag), CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(s.flag(flag), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.width(84.dp))
        Text(if (s.code == "bn") bnDigits(count.toString()) else count.toString(),
            style = MaterialTheme.typography.titleMedium)
    }
}

private data class Geom(val a: Float, val b: Float, val pos: Float)

/** Where the normal zone [a, b] and the value sit on a 0..1 track; null when the report gives no range. */
private fun geom(l: LabResult): Geom? {
    val lo = l.low; val hi = l.high
    if (lo == null && hi == null) return null
    var ref = when { lo != null && hi != null -> hi - lo; hi != null -> abs(hi); else -> abs(lo!!) }
    if (ref <= 0.0) ref = 1.0
    var min = if (lo != null) lo - 0.6 * ref else minOf(0.0, l.value)
    var max = if (hi != null) hi + 0.6 * ref else lo!! + 1.6 * ref
    min = minOf(min, l.value - 0.08 * ref); max = maxOf(max, l.value + 0.08 * ref)
    val f = { x: Double -> ((x - min) / (max - min)).toFloat().coerceIn(0f, 1f) }
    return Geom(if (lo != null) f(lo) else 0f, if (hi != null) f(hi) else 1f, f(l.value))
}

/** Range gauge: grey track, green normal zone from the report's own range, animated marker for the patient's value. */
@OptIn(ExperimentalTextApi::class)
@Composable
fun RangeGauge(l: LabResult, modifier: Modifier = Modifier, labels: Boolean = true) {
    val g = geom(l) ?: return
    val marker = remember(l) { Animatable(0f) }
    LaunchedEffect(l) { marker.animateTo(g.pos, tween(800, easing = FastOutSlowInEasing)) }
    val tm = rememberTextMeasurer()
    val track = MaterialTheme.colorScheme.surfaceVariant
    val ring = MaterialTheme.colorScheme.surface
    val ink = MaterialTheme.colorScheme.onSurfaceVariant
    val c = Brand.status(l.flag)
    val style = TextStyle(fontSize = 11.sp, color = ink)
    Canvas(modifier.fillMaxWidth().height(if (labels) 40.dp else 22.dp)) {
        val h = 8.dp.toPx(); val y = 11.dp.toPx() - h / 2f
        drawRoundRect(track, Offset(0f, y), Size(size.width, h), CornerRadius(h / 2f))
        val ax = g.a * size.width; val bx = g.b * size.width
        drawRoundRect(Brand.Normal.copy(alpha = 0.35f), Offset(ax, y), Size(bx - ax, h), CornerRadius(h / 2f))
        val mx = marker.value * size.width
        drawCircle(ring, radius = 9.dp.toPx(), center = Offset(mx, 11.dp.toPx()))
        drawCircle(c, radius = 7.dp.toPx(), center = Offset(mx, 11.dp.toPx()))
        if (labels) {
            fun label(x: Float, t: String) {
                val r = tm.measure(t, style)
                val left = (x - r.size.width / 2f).coerceIn(0f, maxOf(0f, size.width - r.size.width))
                drawText(r, topLeft = Offset(left, 24.dp.toPx()))
            }
            l.low?.let { label(ax, Py.g(it)) }
            l.high?.let { label(bx, Py.g(it)) }
        }
    }
}

/** A click without the ripple, for small legend rows. */
fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier =
    this.pointerInput(onClick) { detectTapGestures { onClick() } }

/** Small helper so other screens can share the same muted text colour. */
@Composable
fun muted(): Color = MaterialTheme.colorScheme.onSurfaceVariant
