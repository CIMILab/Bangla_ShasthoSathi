package org.shastho.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Brand and status colours. Status colours are reserved for HIGH / LOW / NORMAL and always come with an icon + label. */
object Brand {
    val Teal = Color(0xFF0F766E)
    val TealLight = Color(0xFF14918A)
    val TealDark = Color(0xFF0B5C57)
    val High = Color(0xFFD03B3B)
    val Low = Color(0xFFE09A00)
    val Normal = Color(0xFF0CA30C)
    val Unknown = Color(0xFF8A8F8E)

    fun status(flag: String): Color = when (flag) {
        "high" -> High; "low" -> Low; "normal" -> Normal; else -> Unknown
    }
}

private val Light = lightColorScheme(
    primary = Brand.Teal, onPrimary = Color.White,
    primaryContainer = Color(0xFFD5F2EE), onPrimaryContainer = Color(0xFF00302C),
    secondary = Color(0xFF4A6360), onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCEBE8), onSecondaryContainer = Color(0xFF05201D),
    tertiary = Color(0xFF8A5A00), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFEBC7), onTertiaryContainer = Color(0xFF2C1A00),
    background = Color(0xFFF4F7F6), onBackground = Color(0xFF161D1C),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF161D1C),
    surfaceVariant = Color(0xFFE6EEEC), onSurfaceVariant = Color(0xFF4F5957),
    outline = Color(0xFFBFCAC7), outlineVariant = Color(0xFFDDE5E3),
    error = Color(0xFFB3261E),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF5ED3C5), onPrimary = Color(0xFF003732),
    primaryContainer = Color(0xFF0B5C57), onPrimaryContainer = Color(0xFFD5F2EE),
    secondary = Color(0xFFB1CCC7), onSecondary = Color(0xFF1C3532),
    secondaryContainer = Color(0xFF334B48), onSecondaryContainer = Color(0xFFDCEBE8),
    tertiary = Color(0xFFF5C26B), onTertiary = Color(0xFF452B00),
    tertiaryContainer = Color(0xFF634000), onTertiaryContainer = Color(0xFFFFEBC7),
    background = Color(0xFF0E1514), onBackground = Color(0xFFDDE4E2),
    surface = Color(0xFF161E1D), onSurface = Color(0xFFDDE4E2),
    surfaceVariant = Color(0xFF26302E), onSurfaceVariant = Color(0xFFBEC9C6),
    outline = Color(0xFF5F6B69), outlineVariant = Color(0xFF3A4442),
)

private val Type = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 26.sp, lineHeight = 34.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 24.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 25.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
)

@Composable
fun ShasthoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, typography = Type, content = content)
}
