package org.shastho.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.suspendCancellableCoroutine
import org.shastho.core.OcrLayout
import org.shastho.core.OcrWord
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Which on-phone text reader to use. Auto = both, keep Tesseract when the page has Bengali. */
enum class OcrMode(val label: String) { AUTO("Auto"), MLKIT("ML Kit (English)"), TESS("Tesseract (বাংলা+English)") }

data class OcrOutput(val text: String, val engine: String, val ms: Long, val bengaliShare: Double, val detail: String)

/** Everything runs on the phone: ML Kit's bundled Latin model and Tesseract with the shipped 'fast' ben/eng models. */
class OcrRunner(private val ctx: Context) {
    private val mlkit by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** Decode a photo at most `maxSide` pixels long, turned upright using its EXIF orientation. */
    fun load(uri: Uri, maxSide: Int = 2000): Bitmap {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }!!
        val deg = cr.openInputStream(uri)!!.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f; ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f; else -> 0f
            }
        }
        return if (deg == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
    }

    suspend fun mlkitWords(bmp: Bitmap): List<OcrWord> = suspendCancellableCoroutine { cont ->
        mlkit.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { res ->
                var line = 0; val out = ArrayList<OcrWord>()
                for (b in res.textBlocks) for (l in b.lines) {
                    for (e in l.elements) e.boundingBox?.let { r ->
                        out.add(OcrWord(e.text, r.left.toFloat(), r.top.toFloat(), r.right.toFloat(), r.bottom.toFloat(), line))
                    }
                    line++
                }
                cont.resume(out)
            }
            .addOnFailureListener { cont.resumeWithException(it) }
    }

    private fun tessDir(): File {
        val dir = File(ctx.filesDir, "tessdata"); dir.mkdirs()
        for (lang in listOf("ben", "eng")) {
            val f = File(dir, "$lang.traineddata")
            if (!f.exists()) ctx.assets.open("tessdata/$lang.traineddata").use { i -> f.outputStream().use { i.copyTo(it) } }
        }
        return ctx.filesDir
    }

    fun tesseract(bmp: Bitmap, lang: String = "ben+eng", psm: Int = TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK): String {
        val api = TessBaseAPI()
        val timer = java.util.Timer()
        try {
            check(api.init(tessDir().absolutePath, lang)) { "Tesseract could not load $lang" }
            api.setPageSegMode(psm)
            api.setImage(bmp)
            // a dark or noisy photo can make Tesseract run for minutes: stop it after 30 s (returns what it has)
            timer.schedule(object : java.util.TimerTask() { override fun run() { api.stop() } }, 30_000)
            return api.getUTF8Text() ?: ""
        } finally { timer.cancel(); api.recycle() }
    }

    private fun bengaliShare(t: String): Double {
        val letters = t.count { it.isLetter() }
        return if (letters == 0) 0.0 else t.count { it in 'ঀ'..'৿' && it.isLetter() }.toDouble() / letters
    }

    suspend fun read(uri: Uri, mode: OcrMode): OcrOutput {
        val bmp = load(uri)
        val t0 = System.currentTimeMillis()
        return when (mode) {
            OcrMode.MLKIT -> {
                val w = mlkitWords(bmp); val t = OcrLayout.toText(w)
                OcrOutput(t, "mlkit", System.currentTimeMillis() - t0, bengaliShare(t), "${w.size} words, rows rebuilt")
            }
            OcrMode.TESS -> {
                val t = tesseract(bmp)
                OcrOutput(t, "tesseract ben+eng", System.currentTimeMillis() - t0, bengaliShare(t), "page as one block")
            }
            OcrMode.AUTO -> {
                val w = mlkitWords(bmp); val tm = OcrLayout.toText(w)
                val tt = tesseract(bmp); val share = bengaliShare(tt)
                val useTess = share >= 0.10
                OcrOutput(if (useTess) tt else tm, if (useTess) "auto→tesseract" else "auto→mlkit",
                    System.currentTimeMillis() - t0, share, "Bengali share in Tesseract text ${"%.0f".format(100 * share)}%")
            }
        }
    }
}
