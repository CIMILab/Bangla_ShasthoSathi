plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "org.shastho.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "org.shastho.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4-models"
        // arm64 = the S23 and nearly every phone since 2017; x86_64 = the Android Studio emulator
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        jniLibs { pickFirsts += setOf("**/libc++_shared.so") }
        resources {
            excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/INDEX.LIST",
                              "META-INF/versions/9/module-info.class", "META-INF/AL2.0", "META-INF/LGPL2.1",
                              "native/**")   // desktop tokenizer libraries
        }
    }
    // the golden files that test the Kotlin core also ship in the app, for the on-phone Self-test
    sourceSets["main"].assets.srcDirs("src/main/assets", "../core/src/test/resources")
}

dependencies {
    implementation(project(":core"))
    implementation(project(":models"))
    // v0.4: privacy models on the phone. Same engine and tokenizer library as the Python reference.
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.20.0")
    implementation("ai.djl.huggingface:tokenizers:0.33.0")
    implementation("ai.djl.android:tokenizer-native:0.33.0")
    // libdjl_tokenizer.so needs the shared C++ runtime (libc++_shared.so); fbjni ships the NDK's copy
    implementation("com.facebook.fbjni:fbjni:0.6.0")
    implementation("androidx.documentfile:documentfile:1.0.1")       // read the folder the user picks (no storage permission)
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // on-phone text reading (E8): ML Kit's bundled Latin model + Tesseract (ben+eng 'fast' models in assets/tessdata)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.9.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
