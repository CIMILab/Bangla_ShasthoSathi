# E8 — reading printed reports with the phone camera

Print `E8_printable.pdf` (30 A4 pages, one synthetic report each: 15 lab reports, 8 mixed prescriptions,
7 Bengali notes; invented people only). The id (E8-01 … E8-30) is in the bottom-right corner.

For each page, three photos with the S23 Ultra (90 photos):

| condition | how |
|---|---|
| flat   | page flat on a table, daylight or room light, phone held straight above, page fills the screen |
| angled | phone tilted about 20–30° (page looks like a trapezium), same light |
| dim    | one lamp or evening light, no flash |

In the app (Report tab, section "For the evaluation"):
1. Pick the reader: **Auto** (default). To compare readers, repeat a subset with ML Kit and Tesseract.
2. Pick the sheet id and the condition chips **before** pressing *Take photo*.
3. Take the photo. The app scores the raw text it read (before you correct anything) and adds one line to its E8 log.
4. At the end, press **Copy E8 log** and paste it into a text file (`e8_log.jsonl`) for the analysis.

What is measured per photo: character error rate, lab rows read exactly (name, value, unit, range),
high/low flags still correct, extra rows that are not in the report, personal details still visible after
the rules-only privacy step, and OCR time on the phone.
