"""Unit tests for the phone reference pipeline (no model files needed)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
import numpy as np
from shastho.mobile_ref import OnnxWordTagger, group, route
from shastho.pipeline import _trim


class FakeSess:  # logits favour label (token id % 3), whatever window the token is in
    def run(self, _, feed):
        ids = feed["input_ids"][0]
        z = np.zeros((1, len(ids), 3)); z[0, np.arange(len(ids)), ids % 3] = 5.0
        return [z]


def fake_tagger(L=6, stride=2):
    t = OnnxWordTagger.__new__(OnnxWordTagger)
    t.labels, t.cls, t.sep, t.L, t.stride, t.inputs, t.sess = ["O", "B-X", "I-X"], 100, 101, L, stride, {"input_ids"}, FakeSess()
    return t


def test_windows_cover_every_token():
    t = fake_tagger()
    ids = list(range(3, 40))
    probs = t.token_probs(ids)
    assert all(p is not None for p in probs)
    assert [int(np.argmax(p)) for p in probs] == [i % 3 for i in ids]


def test_empty_text():
    assert fake_tagger().token_probs([]) == []


def test_group_b_starts_new_entity_and_threshold():
    spans = [(0, 3), (4, 7), (8, 11), (12, 15)]
    labs = [("B-NAME", 0.9), ("I-NAME", 0.7), ("B-NAME", 0.2), ("O", 0.99)]
    assert group(spans, labs) == [(0, 7, "NAME", 0.8), (8, 11, "NAME", 0.2)]
    assert group(spans, labs, threshold=0.3) == [(0, 7, "NAME", 0.8)]
    assert group(spans, [("PHONE", 0.9)] * 2 + [("O", 1.0)] * 2, types={"NAME"}) == []


def test_route_by_script():
    assert route("Haemoglobin 10") == ["en"]
    assert route("রোগীর নাম") == ["bn"]
    assert route("নাম: Nusrat") == ["en", "bn"]


def test_trim_keeps_bengali_vowel_signs():
    t = "নাম: মোল্লা, \n"
    assert [t[s:e] for s, e in _trim(t, [(3, len(t))])] == ["মোল্লা"]
    assert _trim(t, [(3, 5)]) == []


def test_v2_rules_stay_on_their_line_and_skip_lab_ranges():
    from shastho.pii_rules import rule_spans
    t = ("Patient: Nusrat Mollah   Age: 70 F\nDate: 19/01/2025\nRef. by: Dr. Saiful Mollah\nTest   Result   Reference\n"
         "Haemoglobin   10.2 g/dL   12.0-15.5\nরোগীর নাম: নুসরাত মোল্লা, বয়স ৭০\nচিকিৎসক: ডা. সাইফুল খান\nনাপা ১+০+১")
    got = {(lab, t[s:e]) for s, e, lab, _ in rule_spans(t, v2=True) if lab in ("DATE", "NAME", "DOCTOR")}
    assert got == {("NAME", "Nusrat Mollah"), ("DATE", "19/01/2025"), ("DOCTOR", "Saiful Mollah"),
                   ("NAME", "নুসরাত মোল্লা"), ("DOCTOR", "সাইফুল খান")}
    assert not any(lab == "DATE" for *_, lab, _ in [(0, 0, "x", 0)] + rule_spans("range 3.9-6.1 and 4.0-11.0", v2=True))
