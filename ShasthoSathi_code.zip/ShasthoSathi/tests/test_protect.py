import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from shastho.protect import subtract


def test_subtract_cuts_hole_from_middle():
    assert subtract([(0, 20)], [(5, 10)]) == [(0, 5), (10, 20)]


def test_subtract_keeps_spans_without_overlap_and_drops_covered():
    assert subtract([(0, 4, "NAME"), (10, 14)], [(10, 14), (30, 40)]) == [(0, 4)]
