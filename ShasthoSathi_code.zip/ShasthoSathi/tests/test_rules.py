import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))

from shastho.rules import (flag_value, parse_dose_pattern, parse_food_relation, parse_duration_days,
                           parse_lab_lines, unsupported_numbers, to_ascii_digits)
from shastho.synth import generate
from shastho.metrics import pii_leakage, span_prf, bio_to_spans


def test_digits():
    assert to_ascii_digits("৯.৮ g/dL") == "9.8 g/dL"


def test_flags():
    assert flag_value(9.8, 12.0, 15.5) == "low"
    assert flag_value(12.0, 12.0, 15.5) == "normal"
    assert flag_value(7.4, 4.0, 5.6) == "high"
    assert flag_value(3.0, None, None) == "unknown"


def test_dose():
    assert parse_dose_pattern("Napa 500 mg ১+০+১ খাবার পরে") == (1, 0, 1)
    assert parse_dose_pattern("1+1+1") == (1, 1, 1)
    assert parse_dose_pattern("½+০+½") == (0.5, 0, 0.5)
    assert parse_dose_pattern("১+০+০+১") == (1, 0, 0, 1)
    assert parse_dose_pattern("Napa 500 mg") is None


def test_food_duration():
    assert parse_food_relation("খাবার আগে") == "before"
    assert parse_food_relation("after meal") == "after"
    assert parse_duration_days("৫ দিন") == 5
    assert parse_duration_days("১ মাস") == 30
    assert parse_duration_days("চলবে") == -1


def test_lab_lines():
    txt = "Haemoglobin   9.8 g/dL   12.0-15.5\nHbA1c 7.4 % 4.0–5.6\nPatient: X  Age: 46 F\nPlatelet Count   210 x10^9/L   150-400"
    rows = parse_lab_lines(txt)
    assert [(r.name, r.flag) for r in rows] == [("Haemoglobin", "low"), ("HbA1c", "high"), ("Platelet Count", "normal")]


def test_number_check():
    src = "Haemoglobin 9.8 g/dL 12.0-15.5"
    assert unsupported_numbers("আপনার হিমোগ্লোবিন ৯.৮, স্বাভাবিক ১২-১৫.৫", src) == []
    assert unsupported_numbers("Your haemoglobin is 8.9", src) == ["8.9"]
    assert unsupported_numbers("repeat in 3 months", src, allowed=["3"]) == []


def test_generator_consistency():
    docs = generate(n_lab=40, n_rx_mixed=40, n_rx_en=10, n_bn=10, seed=1)
    for d in docs:
        if d["doc_type"] == "lab_report":
            parsed = parse_lab_lines(d["text"])
            assert [(p.name, p.flag) for p in parsed] == [(l["name"], l["flag"]) for l in d["labs"]], d["doc_id"]
        for m in d["meds"]:
            s, e = m["dose_span"]
            got = parse_dose_pattern(d["text"][s:e])
            if got is not None:  # English word frequencies ("twice daily") are not '+' patterns
                assert list(got) == m["dose"], (d["doc_id"], d["text"][s:e])


def test_metrics():
    gold = [{"start": 0, "end": 5, "type": "NAME"}, {"start": 10, "end": 15, "type": "PHONE"}]
    r = pii_leakage(gold, [(0, 5), (10, 13)])
    assert r["leaked_spans"] == 1 and r["per_type"]["PHONE"]["leaked"] == 1
    assert span_prf([(0, 5, "M")], [(0, 5, "M"), (7, 9, "M")])["precision"] == 0.5
    assert bio_to_spans(["a", "bb", "c"], ["B-X", "I-X", "O"]) == [(0, 4, "X")]


def test_leakage_ignores_spaces_and_titles():
    text = "Dr. Habib Hossain, 01712-345678"
    gold = [{"start": 4, "end": 17, "type": "DOCTOR"}, {"start": 19, "end": 31, "type": "PHONE"}]
    pred = [(4, 9), (10, 17), (19, 24), (25, 31)]          # name split in two, phone split at '-'
    assert pii_leakage(gold, pred, text)["leaked_spans"] == 0
    assert pii_leakage(gold, pred)["leaked_spans"] == 2    # old strict behaviour without text


def test_doctor_span_has_no_title():
    docs = generate(n_lab=5, n_rx_mixed=5, n_rx_en=2, n_bn=5, seed=3)
    for d in docs:
        for p in d["pii"]:
            if p["type"] == "DOCTOR":
                assert not p["text"].startswith(("Dr.", "ডা.")), p


def test_compat_model_dir(tmp_path, monkeypatch):
    import json, huggingface_hub
    from shastho.openmed_adapter import compat_model_dir
    snap = tmp_path / "snap"; snap.mkdir()
    (snap / "tokenizer_config.json").write_text(json.dumps({"extra_special_tokens": ["[X]"]}))
    (snap / "model.safetensors").write_text("w")
    monkeypatch.setattr(huggingface_hub, "snapshot_download", lambda repo: str(snap))
    monkeypatch.setenv("HF_HOME", str(tmp_path / "hf"))
    out = pathlib.Path(compat_model_dir("Org/M"))
    cfg = json.loads((out / "tokenizer_config.json").read_text())
    assert cfg["extra_special_tokens"] == {} and cfg["additional_special_tokens"] == ["[X]"]
    assert (out / "model.safetensors").is_symlink()


def test_ner_offline_fallback(monkeypatch):
    """If OpenMed's Hub checksum check fails offline, the adapter loads the cached snapshot by path."""
    import types, sys as _sys
    from shastho import openmed_adapter as A
    calls = []

    def analyze_text(text, model_name, **kw):
        calls.append(model_name)
        if not model_name.startswith("/"):
            raise RuntimeError("ModelIntegrityError: Cannot reach https://huggingface.co: offline mode is enabled")
        return types.SimpleNamespace(entities=[types.SimpleNamespace(start=0, end=4, label="CHEM", confidence=0.9)])

    r = A.OpenMedRunner.__new__(A.OpenMedRunner)
    r.om = types.SimpleNamespace(analyze_text=analyze_text)
    r.loader = r.config = None
    r._local = {}
    monkeypatch.setattr(A, "local_snapshot", lambda key: "/cache/" + key)
    spans, _ = r.ner("Napa 500 mg", "pharma_detection_superclinical")
    assert spans == [(0, 4, "CHEM", 0.9)]
    assert calls == ["pharma_detection_superclinical", "/cache/pharma_detection_superclinical"]
    r.ner("Napa", "pharma_detection_superclinical")          # second call goes straight to the path
    assert calls[-1] == "/cache/pharma_detection_superclinical"


def test_pii_rules():
    from shastho.pii_rules import rule_spans
    t = ("TEESTA GENERAL HOSPITAL\nSadar Road, Barishal\nLab ID: KDX-24-57931\nMobile: ০১৭১২-৩৪৫৬৭৮, +880 1812-345678\n"
         "এনআইডি: ১৯৯০২৬৯৪৭৮১২৩৪৫৬৭\nআপনি নিকটস্থ হাসপাতালে যান। Napa 500 mg 1+0+1")
    got = {(t[s:e], lab) for s, e, lab, _ in rule_spans(t)}
    assert ("TEESTA GENERAL HOSPITAL", "FACILITY") in got
    assert ("Sadar Road, Barishal", "ADDRESS") in got
    assert ("KDX-24-57931", "ID") in got
    assert ("০১৭১২-৩৪৫৬৭৮", "PHONE") in got and ("+880 1812-345678", "PHONE") in got
    assert ("১৯৯০২৬৯৪৭৮১২৩৪৫৬৭", "NID") in got
    assert not any("হাসপাতাল" in x or "Napa" in x or "500" in x for x, _ in got)   # generic phrase and drug untouched


def test_heldout_vocab_is_disjoint():
    dev = generate(n_lab=20, n_rx_mixed=20, n_rx_en=5, n_bn=10, seed=1)
    ho = generate(n_lab=20, n_rx_mixed=20, n_rx_en=5, n_bn=10, seed=1, vocab="heldout")
    fac = lambda ds: {p["text"].lower() for d in ds for p in d["pii"] if p["type"] == "FACILITY"}
    assert fac(dev) and fac(ho) and not (fac(dev) & fac(ho))
    assert generate(n_lab=3, n_rx_mixed=0, n_rx_en=0, n_bn=0, seed=1)[0]["text"] == dev[0]["text"]  # dev unchanged after heldout
