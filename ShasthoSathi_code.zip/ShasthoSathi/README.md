# ShasthoSathi (স্বাস্থ্যসাথী) — implementation code

**Offline, privacy-first explanation of Bengali, English and code-mixed health reports with small language models.**

ShasthoSathi ("health companion") reads a lab report or prescription, hides personal identifiers on the device,
finds medicines, doses and lab values, flags results outside the printed reference range, and explains the report
in plain Bengali or English. Nothing leaves the device.

Project page and paper: <https://cimilab.github.io/Bangla_ShasthoSathi/>

> This repository holds the code, the synthetic data and the result summaries. **It contains no model weights.**
> Every model is public and is downloaded by the scripts (see [Models](#models)).

## Pipeline

```
report text / photo
   │  OCR (Tesseract ben+eng; ML Kit on the phone)
   ▼
PROTECT  rules v1+v2  ∪  script-routed PII encoders (Bengali 279M / English 44M)
         minus medicine-tagger spans and lab rows (clinical protection)
   ▼
FIND     medicine NER (BanglishBERT fine-tuned on Bangla-HealthNER) + lab-row parser
   ▼
FLAG     deterministic rules: value vs. the printed range, dose patterns such as ১+০+১, Bengali digits
   ▼
EXPLAIN  fact sheet → checked template (default) or an optional small LLM,
         accepted only if it passes the number gate and the coverage gate
```

Rules, not the language model, decide whether a value is abnormal. Any generated explanation that contains a number
missing from the report, or omits a flagged result, is rejected and the template is shown instead.

## Repository layout

| Path | Contents |
|---|---|
| `src/shastho/` | Python reference implementation: `rules.py` (flags, dose parser, number gate), `pii_rules.py`, `protect.py` (clinical protection), `synth.py` (synthetic reports with surrogate identifiers), `explain.py` (fact sheet, templates, gates), `metrics.py` (leakage, over-redaction, span F1, bootstrap CIs), `mobile_ref.py` (on-device pipeline reference), `ocr_eval.py`, `pipeline.py`, `openmed_adapter.py` |
| `scripts/` | One script per experiment, numbered in run order (table below) |
| `slurm/`, `run/` | Batch job templates (written for the Hellbender cluster; edit partition/memory for yours) |
| `notebooks/` | `03_make_figures.ipynb` regenerates all figures into `results/figures/` (fonts and colours editable at the top) |
| `mobile/android/` | Kotlin app: `core/` (pure-Kotlin port of the pipeline, golden-tested against Python), `models/` (ONNX Runtime + tokenizer glue), `app/` (Jetpack Compose UI) |
| `mobile/eval/` | Printable OCR test sheets (E8) and instructions |
| `web/` | Browser version of the same pipeline (plain JS, golden-tested) |
| `data/synthetic/` | Synthetic development and held-out sets (invented people only) |
| `results/` | Small result summaries used by the figures |
| `docs/` | `DATA.md` (datasets), `RUNNING.md` (batch jobs), `RESULTS.md` (all numbers) |
| `tools/` | Code generators: `gen_kotlin.py` and `gen_js.py` port the shared constants and rules from Python |
| `tests/` | `pytest` tests for the rules, protection and the mobile reference |

### Experiments

| Script | Question |
|---|---|
| `01_make_synthetic.py` | Build the synthetic sets with gold identifiers, medicines and lab flags |
| `02_pii_baseline.py`, `05_pii_hybrid.py` | E1/E3: identifier leakage of PII encoders, rules and the hybrid (RQ1) |
| `03_ner_baseline.py`, `04_healthner_profile.py`, `06_healthner_finetune.py` | E2/E0/E4: code-mixed medicine NER (RQ2) |
| `07_onnx_int8.py` | E5: accuracy cost of INT8 ONNX export (RQ4) |
| `08_llm_explain.py`, `09_llm_judge.py`, `10_bn_native_rating.py` | E6: small-LLM explanations, validated judge, native-speaker check (RQ3) |
| `12_mobile_export.py` … `15_core_golden.py`, `20_web_golden.py` | E7: phone/web asset export and golden files |
| `23_phone_bundle.py`, `24_phone_leak_set.py`, `25_phone_config.py` | E7c–e: on-phone leak test and the ARM/x86 INT8 fix |
| `16_ocr_eval_set.py`, `17_ocr_proxy.py`, `18_ner_confusion.py` | E8 OCR test sheets, OCR proxy, NER confusion matrix |
| `19_paper_figures.py`, `21_radar.py`, `22_run_figures_notebook.py` | Figures |

## Quick start

```bash
git clone https://github.com/<org>/<repo>.git && cd <repo>
python -m venv .venv && source .venv/bin/activate      # or conda
pip install numpy pytest
python -m pytest -q tests                               # rules, protection, mobile reference: no models needed
python scripts/01_make_synthetic.py                     # rebuilds data/synthetic/
```

Full environment for the experiments (GPU recommended for E4 and E6):

```bash
pip install torch --index-url https://download.pytorch.org/whl/cu121   # match your CUDA
pip install -r requirements.txt
bash scripts/00_download_data.sh                        # open datasets into data/raw/
```

On a Slurm cluster, `environment/install_all.sh` sets up everything in one step and `docs/RUNNING.md` lists the
batch jobs (`sbatch slurm/<job>.sbatch`). Set `DATA` to a folder with space for caches before running it.

## Models

None are stored in this repository. All are public on Hugging Face and downloaded on first use
(`environment/install_all.sh`, `run/download_models.sh`).

| Role | Model |
|---|---|
| PII, Bengali | `OpenMed/OpenMed-PII-Bengali-mSuperClinical-Large-279M-v1` |
| PII, English | `OpenMed/OpenMed-PII-SuperClinical-Small-44M-v1` |
| Medicine NER backbone | `csebuetnlp/banglishbert` (fine-tuned here by `06_healthner_finetune.py`; also `banglabert`, `xlm-roberta-base`) |
| Baseline clinical NER | `OpenMed/OpenMed-NER-PharmaDetect-*`, `OpenMed/OpenMed-NER-DiseaseDetect-*` |
| Small LLMs (explanation) | `Qwen/Qwen2.5-0.5B-Instruct`, `Qwen/Qwen2.5-1.5B-Instruct`, `Qwen/Qwen3-1.7B`, `microsoft/Phi-3.5-mini-instruct` |
| Judge | `Qwen/Qwen2.5-14B-Instruct` |

The phone and web apps load the exported INT8 ONNX models from a folder the user picks. Build that folder with
`sbatch slurm/phone_models.sbatch` (runs `12_mobile_export.py`, `20_web_golden.py`, `23_phone_bundle.py`);
the shipped configuration is `mobile/android/app/src/main/assets/pipeline_config.json`.

## Mobile and web apps

```bash
bash scripts/fetch_assets.sh     # Tesseract ben/eng data + browser libraries (not stored in git)
```

* **Mobile app**: open `mobile/android` in Android Studio and run. `./gradlew :core:test` checks the Kotlin core
  against the Python golden files. Details: `mobile/android/README.md`.
* **Web app**: `cd web && npm test` (golden test), then `python -m http.server 8080` inside `web/`.
  Details: `web/README.md`.

Without models both apps run the rules-only privacy step, the flags and the template explanations.

## Data

Only open datasets are used (`docs/DATA.md`): Bangla-HealthNER (CC BY-NC-SA 4.0), PMC-Patients (CC BY-NC-SA 4.0)
and ADE Corpus v2. Raw data is not redistributed; `scripts/00_download_data.sh` fetches it. All people, phone
numbers, IDs and facilities in `data/synthetic/` are invented; real texts are evaluated with inserted surrogate
identifiers.

## Main results (details in `docs/RESULTS.md`)

* **Privacy (RQ1)**: identifier leakage 0 / 0 / 0.75 % on the held-out synthetic, real-text-with-surrogates and
  free-text sets, with the phone matching the server on 1,097 of 1,100 documents.
* **Hardware dependence (RQ4)**: INT8 attention MatMuls behave differently on ARM and x86 (15.5 % vs 1.0 % missed
  names); quantizing only the embeddings removed the gap.
* **On a Samsung S23 Ultra**: median 262 ms per report (p90 524 ms), 900 MB model folder.

## Citation

See `CITATION.cff`. Code is released under the MIT License (`LICENSE`); datasets keep their own licenses.

This software is a research prototype. It is not a medical device and does not give medical advice.
