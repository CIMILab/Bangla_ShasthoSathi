#!/usr/bin/env bash
# E4 fine-tuning. Runs every line of configs/e4.txt (or only line N: bash run/e4.sh N).
# Resumable: a config whose runs/<tag>/metrics.json already exists is skipped.
set -uo pipefail
source "$(dirname "$0")/../environment/env.sh"
SEEDS=${SEEDS:-42}
mapfile -t CFGS < <(grep -v '^\s*#' configs/e4.txt | grep -v '^\s*$')
if [ $# -ge 1 ]; then CFGS=("${CFGS[$(( $1 - 1 ))]}"); fi
for cfg in "${CFGS[@]}"; do
  for seed in $SEEDS; do
    model=$(echo "$cfg" | awk '{print $2}'); name=${model##*/}
    mode=$([[ "$cfg" == *--lora* ]] && echo lora || echo full)
    tag="${name}-${mode}-s${seed}"
    if [ -f "runs/$tag/metrics.json" ]; then echo "[skip] $tag already done"; continue; fi
    echo "=== $(date '+%F %T') start $tag"
    python scripts/06_healthner_finetune.py $cfg --seed "$seed" --save-model > "logs/e4_${tag}.log" 2>&1 \
      && echo "=== $(date '+%F %T') done  $tag: $(grep 'test micro F1' logs/e4_${tag}.log)" \
      || echo "=== $(date '+%F %T') FAILED $tag (see logs/e4_${tag}.log)"
  done
done
python scripts/99_summarize.py
