#!/usr/bin/env bash
# Everything for Week 7 in one go: tests -> E3 -> E4 -> summary.
set -uo pipefail
HERE="$(dirname "$0")"
source "$HERE/../environment/env.sh"
python -m pytest -q tests || exit 1
bash "$HERE/e3.sh"
bash "$HERE/e4.sh"
