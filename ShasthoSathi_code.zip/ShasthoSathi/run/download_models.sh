#!/usr/bin/env bash
# Download E4 backbones once (needs internet; run on a login node or online GPU node).
set -euo pipefail
source "$(dirname "$0")/../environment/env.sh"
python - <<'PY'
from huggingface_hub import snapshot_download
for m in ["csebuetnlp/banglishbert", "csebuetnlp/banglabert", "xlm-roberta-base"]:
    print("download", m, flush=True)
    snapshot_download(m, allow_patterns=["*.json", "*.txt", "*.model", "*.safetensors", "*.bin"])
PY
