#!/usr/bin/env bash
# E3 hybrid de-identification (≈10 min on H100). Log: logs/e3_<date>.log
set -euo pipefail
source "$(dirname "$0")/../environment/env.sh"
DEVICE=$(python -c "import torch;print('cuda' if torch.cuda.is_available() else 'cpu')")
python scripts/01_make_synthetic.py --vocab heldout --seed 7 --out data/synthetic/synth_heldout.jsonl
python scripts/05_pii_hybrid.py --device "$DEVICE" --out results/exp3_pii_hybrid.json
