"""Metrics: PII leakage, span P/R/F1, clinical over-redaction, bootstrap CIs."""
from __future__ import annotations

import random
import unicodedata
from collections import defaultdict
from typing import Callable, Iterable, Sequence


def _covered(spans: Iterable[tuple]) -> set:
    cov = set()
    for s, e in spans:
        cov.update(range(s, e))
    return cov


def _content(ch: str) -> bool:
    """Letters, digits and combining marks count; spaces and punctuation do not."""
    return unicodedata.category(ch)[0] not in ("Z", "P", "C")


def pii_leakage(gold: Sequence[dict], pred: Sequence[tuple], text: str | None = None) -> dict:
    """Character-level view of what a redactor let through.

    gold: [{"start","end","type"}], pred: [(start, end)].
    A gold span 'leaks' if any of its content characters (letters/digits) is
    left uncovered. Spaces and punctuation are ignored when `text` is given, so
    'Habib' + 'Hossain' predicted as two spans still fully covers 'Habib Hossain'.
    """
    cov = _covered(pred)
    per_type = defaultdict(lambda: [0, 0])  # type -> [leaked spans, total spans]
    leaked_chars = total_chars = 0
    for g in gold:
        chars = [i for i in range(g["start"], g["end"]) if text is None or _content(text[i])]
        miss = [i for i in chars if i not in cov]
        total_chars += len(chars)
        leaked_chars += len(miss)
        per_type[g["type"]][1] += 1
        if miss:
            per_type[g["type"]][0] += 1
    n_spans = sum(v[1] for v in per_type.values())
    n_leak = sum(v[0] for v in per_type.values())
    return {
        "spans": n_spans,
        "leaked_spans": n_leak,
        "span_leak_rate": n_leak / n_spans if n_spans else 0.0,
        "char_leak_rate": leaked_chars / total_chars if total_chars else 0.0,
        "doc_any_leak": int(n_leak > 0),
        "per_type": {k: {"leaked": v[0], "total": v[1]} for k, v in per_type.items()},
    }


def over_redaction(protected: Sequence[tuple], pred: Sequence[tuple]) -> dict:
    """How much clinically needed text (drug names, lab values) the redactor destroyed."""
    cov = _covered(pred)
    hit = sum(1 for s, e in protected if any(i in cov for i in range(s, e)))
    return {"protected": len(protected), "redacted": hit}


def span_prf(gold: Sequence[tuple], pred: Sequence[tuple], mode: str = "exact") -> dict:
    """gold/pred: [(start, end, label)]. mode 'exact' or 'overlap' (same label, any overlap)."""
    def match(a, b):
        if a[2] != b[2]:
            return False
        return (a[0], a[1]) == (b[0], b[1]) if mode == "exact" else (a[0] < b[1] and b[0] < a[1])

    used = set()
    tp = 0
    for g in gold:
        for j, p in enumerate(pred):
            if j not in used and match(g, p):
                used.add(j)
                tp += 1
                break
    fp, fn = len(pred) - tp, len(gold) - tp
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    return {"tp": tp, "fp": fp, "fn": fn, "precision": p, "recall": r, "f1": 2 * p * r / (p + r) if p + r else 0.0}


def bio_to_spans(tokens: Sequence[str], labels: Sequence[str]) -> list[tuple]:
    """Token-level BIO -> character spans over ' '.join(tokens)."""
    spans, start, cur, pos = [], None, None, 0
    offs = []
    for t in tokens:
        offs.append((pos, pos + len(t)))
        pos += len(t) + 1
    for (s, e), lab in zip(offs, labels):
        if lab.startswith("B-") or (lab.startswith("I-") and cur != lab[2:]):
            if cur:
                spans.append((start, end, cur))
            start, end, cur = s, e, lab[2:]
        elif lab.startswith("I-"):
            end = e
        else:
            if cur:
                spans.append((start, end, cur))
            cur = None
    if cur:
        spans.append((start, end, cur))
    return spans


def bootstrap_ci(values: Sequence[float], stat: Callable = None, n: int = 2000, seed: int = 0, alpha=0.05):
    """Percentile bootstrap CI over documents."""
    stat = stat or (lambda xs: sum(xs) / len(xs))
    r = random.Random(seed)
    vals = list(values)
    boots = sorted(stat([vals[r.randrange(len(vals))] for _ in vals]) for _ in range(n))
    return stat(vals), boots[int(n * alpha / 2)], boots[int(n * (1 - alpha / 2)) - 1]
