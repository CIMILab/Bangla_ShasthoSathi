"""Clinical-entity protection (E3b).

Problem found in E3: on real Bangla posts the OpenMed PII models also erase 37% of
medicine and dosage mentions, which the app needs to explain a prescription.

Fix: run the fine-tuned Bangla-HealthNER tagger (E4) on the same text and cut its
Medicine / Dosage spans out of the MODEL's PII spans. Rule spans (phone, NID, IDs,
facilities, addresses) are format-based and are never cut.

    prot = ClinicalProtector("runs/banglishbert-full-s42/model", device="cuda")
    keep = prot.spans(text)                     # [(start, end, type)]
    pii  = subtract(model_spans, keep) + rule_spans
"""
from __future__ import annotations

import re

WORD = re.compile(r"\S+")


def subtract(spans, holes):
    """Remove every (s, e) in `holes` from each (s, e) in `spans`. Returns a list of (s, e)."""
    out = []
    holes = sorted((h[0], h[1]) for h in holes)
    for s, e, *_ in spans:
        pieces = [(s, e)]
        for hs, he in holes:
            nxt = []
            for ps, pe in pieces:
                if he <= ps or hs >= pe:
                    nxt.append((ps, pe)); continue
                if ps < hs:
                    nxt.append((ps, hs))
                if he < pe:
                    nxt.append((he, pe))
            pieces = nxt
        out.extend(p for p in pieces if p[1] > p[0])
    return out


class ClinicalProtector:
    """Word-level tagger (same labelling as E4 training: first sub-token of each word)."""

    def __init__(self, model_dir, device="cpu", types=("Medicine", "Dosage"), max_len=256, stride=64):
        import torch
        from transformers import AutoModelForTokenClassification, AutoTokenizer
        self.torch, self.device, self.types = torch, device, set(types)
        self.tok = AutoTokenizer.from_pretrained(model_dir, use_fast=True)
        self.model = AutoModelForTokenClassification.from_pretrained(model_dir).to(device).eval()
        self.id2label = self.model.config.id2label
        self.max_len, self.stride = max_len, stride

    def word_tags(self, words):
        if not words:
            return []
        enc = self.tok(words, is_split_into_words=True, truncation=True, max_length=self.max_len,
                       stride=self.stride, return_overflowing_tokens=True, padding=True, return_tensors="pt")
        with self.torch.inference_mode():
            logits = self.model(input_ids=enc["input_ids"].to(self.device),
                                attention_mask=enc["attention_mask"].to(self.device)).logits
        pred = logits.argmax(-1).cpu().tolist()
        tags = [None] * len(words)
        for i in range(len(pred)):                 # windows overlap: the first window that sees a word wins
            prev = None
            for j, w in enumerate(enc.word_ids(i)):
                if w is not None and w != prev and tags[w] is None:
                    tags[w] = self.id2label[pred[i][j]]
                prev = w
        return [t or "O" for t in tags]

    def spans(self, text):
        """[(start, end, type)] for protected entity types, in character offsets of `text`."""
        ms = list(WORD.finditer(text))
        tags = self.word_tags([m.group() for m in ms])
        out, cur = [], None
        for m, t in zip(ms, tags):
            typ = t[2:] if t != "O" else None
            if typ in self.types and (t.startswith("B-") or cur is None or cur[2] != typ):
                if cur:
                    out.append(tuple(cur))
                cur = [m.start(), m.end(), typ]
            elif typ in self.types:
                cur[1] = m.end()
            else:
                if cur:
                    out.append(tuple(cur))
                cur = None
        if cur:
            out.append(tuple(cur))
        return out
