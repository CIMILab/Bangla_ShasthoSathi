"""Synthetic Bangladeshi lab reports and prescriptions with gold labels.

Every document comes with exact character offsets for:
  * PII spans (name, phone, date, ID, address, doctor, facility, NID, email)
  * medicine mentions (brand, generic, strength, dose pattern, food relation, duration)
  * lab rows (value, unit, reference range, flag computed by rules.flag_value)

All people, IDs, phone numbers and facilities are invented. Brand->generic pairs
are common Bangladeshi brands and must be checked against the DGDA register
(see scripts/05_check_lexicon.py) before any claim is made about them.
"""
from __future__ import annotations

import json
import random
from dataclasses import dataclass, field

from .rules import flag_value, to_bangla_digits

# ---------------------------------------------------------------- vocab
FIRST_F = ["Rahima", "Nasrin", "Farzana", "Sultana", "Taslima", "Ayesha", "Shirin", "Rokeya", "Mitu", "Jannatul", "Sabina", "Moushumi"]
FIRST_M = ["Kamal", "Rafiq", "Abdul", "Mizanur", "Habib", "Sohel", "Tanvir", "Arif", "Jahangir", "Shahidul", "Nurul", "Imran"]
LAST = ["Begum", "Akter", "Khatun", "Hossain", "Rahman", "Islam", "Ahmed", "Uddin", "Chowdhury", "Sarkar", "Mia", "Das"]
BN_FIRST_F = ["রহিমা", "নাসরিন", "ফারজানা", "সুলতানা", "তাসলিমা", "আয়েশা"]
BN_FIRST_M = ["কামাল", "রফিক", "আব্দুল", "হাবিব", "সোহেল", "আরিফ"]
BN_LAST = ["বেগম", "আক্তার", "খাতুন", "হোসেন", "রহমান", "ইসলাম"]
AREAS = ["Mirpur-10, Dhaka", "Dhanmondi, Dhaka", "Agrabad, Chattogram", "Zindabazar, Sylhet", "Shaheb Bazar, Rajshahi", "Sonadanga, Khulna"]
BN_AREAS = ["মিরপুর-১০, ঢাকা", "ধানমন্ডি, ঢাকা", "আগ্রাবাদ, চট্টগ্রাম", "জিন্দাবাজার, সিলেট"]
FACILITIES = ["Shapla Diagnostic Centre", "Padma Medical Services", "Meghna Health Point", "Jamuna Clinic & Lab", "Karnaphuli Diagnostics"]

# Held-out vocabulary: no name, area or facility overlaps with the lists above.
# Used to build a test set that rule lists were never tuned on.
HELDOUT = dict(
    FIRST_F=["Nusrat", "Tahmina", "Shamima", "Parvin", "Sharmin", "Lipi", "Rumana", "Selina", "Afroza", "Maksuda"],
    FIRST_M=["Mahbub", "Rezaul", "Anwar", "Saiful", "Kamrul", "Delwar", "Mostafa", "Belal", "Faruk", "Jashim"],
    LAST=["Talukder", "Mollah", "Bhuiyan", "Sheikh", "Pramanik", "Howlader", "Khan", "Siddique", "Karim", "Roy"],
    BN_FIRST_F=["নুসরাত", "তাহমিনা", "শামীমা", "পারভীন", "শারমিন"],
    BN_FIRST_M=["মাহবুব", "রেজাউল", "আনোয়ার", "সাইফুল", "কামরুল"],
    BN_LAST=["তালুকদার", "মোল্লা", "ভূঁইয়া", "শেখ", "খান"],
    AREAS=["Uttara Sector-7, Dhaka", "Mohammadpur, Dhaka", "Nasirabad, Chattogram", "Amberkhana, Sylhet",
           "Kazla, Rajshahi", "Boyra, Khulna", "Sadar Road, Barishal", "Jahaj Company Mor, Rangpur"],
    BN_AREAS=["উত্তরা সেক্টর-৭, ঢাকা", "মোহাম্মদপুর, ঢাকা", "নাসিরাবাদ, চট্টগ্রাম", "আম্বরখানা, সিলেট", "বয়রা, খুলনা"],
    FACILITIES=["Surma Diagnostic Center", "Teesta General Hospital", "Rupsha Medical Centre", "Madhumati Clinic",
                "Brahmaputra Pathology Lab", "Dhaleshwari Specialized Hospital"],
)
_DEV = dict(FIRST_F=FIRST_F, FIRST_M=FIRST_M, LAST=LAST, BN_FIRST_F=BN_FIRST_F, BN_FIRST_M=BN_FIRST_M,
            BN_LAST=BN_LAST, AREAS=AREAS, BN_AREAS=BN_AREAS, FACILITIES=FACILITIES)


def use_vocab(name: str = "dev"):
    """Switch the name/area/facility lists: 'dev' (default) or 'heldout'."""
    g = globals()
    for k, v in (HELDOUT if name == "heldout" else _DEV).items():
        g[k] = v
DEGREES = ["MBBS", "MBBS, FCPS (Medicine)", "MBBS, MD (Cardiology)", "MBBS, DDV", "MBBS, FCPS (Paediatrics)"]

# (test, unit, low, high, typical sd-ish spread, decimals)
LAB_TESTS = [
    ("Haemoglobin", "g/dL", 12.0, 15.5, 2.2, 1),
    ("Fasting Blood Sugar", "mmol/L", 3.9, 6.1, 2.0, 1),
    ("HbA1c", "%", 4.0, 5.6, 1.4, 1),
    ("S. Creatinine", "mg/dL", 0.6, 1.1, 0.35, 2),
    ("SGPT (ALT)", "U/L", 7.0, 45.0, 25.0, 0),
    ("Total Cholesterol", "mg/dL", 125.0, 200.0, 45.0, 0),
    ("Triglyceride", "mg/dL", 40.0, 150.0, 70.0, 0),
    ("TSH", "mIU/L", 0.4, 4.0, 2.0, 2),
    ("Platelet Count", "x10^9/L", 150.0, 400.0, 110.0, 0),
    ("WBC Count", "x10^9/L", 4.0, 11.0, 3.5, 1),
    ("Serum Uric Acid", "mg/dL", 2.4, 6.0, 1.8, 1),
    ("Vitamin D (25-OH)", "ng/mL", 30.0, 100.0, 15.0, 1),
]

# brand, generic, strengths, form
DRUGS = [
    ("Napa", "Paracetamol", ["500 mg", "665 mg"], "Tab."),
    ("Ace", "Paracetamol", ["500 mg"], "Tab."),
    ("Seclo", "Omeprazole", ["20 mg", "40 mg"], "Cap."),
    ("Maxpro", "Esomeprazole", ["20 mg", "40 mg"], "Tab."),
    ("Sergel", "Esomeprazole", ["20 mg", "40 mg"], "Cap."),
    ("Pantonix", "Pantoprazole", ["20 mg", "40 mg"], "Tab."),
    ("Fexo", "Fexofenadine", ["120 mg", "180 mg"], "Tab."),
    ("Monas", "Montelukast", ["10 mg"], "Tab."),
    ("Comet", "Metformin", ["500 mg", "850 mg"], "Tab."),
    ("Amdocal", "Amlodipine", ["5 mg", "10 mg"], "Tab."),
    ("Angilock", "Losartan Potassium", ["25 mg", "50 mg"], "Tab."),
    ("Atova", "Atorvastatin", ["10 mg", "20 mg"], "Tab."),
    ("Zimax", "Azithromycin", ["500 mg"], "Tab."),
    ("Tofen", "Ketotifen", ["1 mg"], "Tab."),
]
DOSE_PATTERNS = [(1, 0, 1), (1, 1, 1), (1, 0, 0), (0, 0, 1), (1, 1, 0), (0, 1, 0)]
DURATIONS_BN = [("৫ দিন", 5), ("৭ দিন", 7), ("১০ দিন", 10), ("১৪ দিন", 14), ("১ মাস", 30), ("৩ মাস", 90), ("চলবে", -1)]
DURATIONS_EN = [("5 days", 5), ("7 days", 7), ("10 days", 10), ("14 days", 14), ("1 month", 30), ("3 months", 90), ("continue", -1)]
EN_FREQ = {(1, 0, 1): "twice daily", (1, 1, 1): "three times daily", (1, 0, 0): "once daily in the morning",
           (0, 0, 1): "once daily at night", (1, 1, 0): "morning and noon", (0, 1, 0): "once daily at noon"}
ADVICE_BN = ["নিয়মিত হাঁটবেন।", "মিষ্টি ও তেলযুক্ত খাবার কম খাবেন।", "পর্যাপ্ত পানি পান করবেন।", "১ মাস পর আবার দেখা করবেন।", "ধূমপান করবেন না।"]


@dataclass
class Doc:
    doc_id: str
    doc_type: str
    lang: str
    text: str = ""
    pii: list = field(default_factory=list)
    meds: list = field(default_factory=list)
    labs: list = field(default_factory=list)

    # builder helpers -----------------------------------------------------
    def add(self, s: str):
        self.text += s

    def add_pii(self, s: str, kind: str):
        start = len(self.text)
        self.text += s
        self.pii.append({"start": start, "end": len(self.text), "type": kind, "text": s})

    def span(self, s: str) -> tuple:
        start = len(self.text)
        self.text += s
        return start, len(self.text)

    def to_dict(self):
        return {k: getattr(self, k) for k in ("doc_id", "doc_type", "lang", "text", "pii", "meds", "labs")}


# ---------------------------------------------------------------- PII makers
def _phone(r):
    return f"01{r.choice('3456789')}{r.randint(10, 99)}-{r.randint(100000, 999999)}"


def _date(r, bangla=False):
    d, m, y = r.randint(1, 28), r.randint(1, 12), r.choice([2025, 2026])
    s = r.choice([f"{d:02d}/{m:02d}/{y}", f"{d:02d}-{m:02d}-{y % 100:02d}", f"{d:02d}.{m:02d}.{y}"])
    return to_bangla_digits(s) if bangla else s


def _name(r, sex, bangla=False):
    if bangla:
        return f"{r.choice(BN_FIRST_F if sex == 'F' else BN_FIRST_M)} {r.choice(BN_LAST)}"
    return f"{r.choice(FIRST_F if sex == 'F' else FIRST_M)} {r.choice(LAST)}"


def _doctor(r, bangla=False):
    return _name(r, r.choice("MF"), bangla)


def _add_doctor(doc, r, bangla=False):
    """Title stays outside the PII span: 'Dr.' identifies no one."""
    doc.add("ডা. " if bangla else "Dr. ")
    doc.add_pii(_doctor(r, bangla), "DOCTOR")


def _labid(r):
    return f"{r.choice(['SDC', 'PMS', 'MHP', 'JCL', 'KDX'])}-{r.randint(24, 26)}-{r.randint(10000, 99999)}"


def _nid(r):
    return str(r.randint(10**9, 10**10 - 1)) if r.random() < 0.5 else str(r.randint(10**16, 10**17 - 1))


# ---------------------------------------------------------------- lab report
def _lab_value(r, lo, hi, spread, dec):
    u = r.random()
    if u < 0.55:
        v = r.uniform(lo, hi)
    elif u < 0.78:
        v = lo - abs(r.gauss(spread * 0.6, spread * 0.3))
    else:
        v = hi + abs(r.gauss(spread * 0.6, spread * 0.3))
    v = max(v, 0.01 if dec else 1)
    return round(v, dec)


def _fmt(v, dec):
    return f"{v:.{dec}f}"


def make_lab(r: random.Random, i: int) -> Doc:
    doc = Doc(f"lab_{i:04d}", "lab_report", "en")
    sex = r.choice("MF")
    doc.add_pii(r.choice(FACILITIES).upper(), "FACILITY")
    doc.add("\n")
    doc.add_pii(r.choice(AREAS), "ADDRESS")
    doc.add("\nPatient: ")
    doc.add_pii(_name(r, sex), "NAME")
    doc.add(f"   Age: {r.randint(18, 80)} {sex}\nLab ID: ")
    doc.add_pii(_labid(r), "ID")
    doc.add("   Date: ")
    doc.add_pii(_date(r), "DATE")
    doc.add("\nMobile: ")
    doc.add_pii(_phone(r), "PHONE")
    doc.add("\nRef. by: ")
    _add_doctor(doc, r)
    doc.add("\nTest   Result   Reference\n")
    for name, unit, lo, hi, spread, dec in r.sample(LAB_TESTS, r.randint(3, 6)):
        v = _lab_value(r, lo, hi, spread, dec)
        line_no = doc.text.count("\n") + 1
        doc.add(f"{name}   ")
        vs, ve = doc.span(_fmt(v, dec))
        doc.add(f" {unit}   {_fmt(lo, dec)}-{_fmt(hi, dec)}\n")
        doc.labs.append({"name": name, "value": v, "unit": unit, "low": lo, "high": hi,
                         "flag": flag_value(v, lo, hi), "line": line_no, "value_span": [vs, ve]})
    doc.add("Reported by: ")
    _add_doctor(doc, r)
    doc.add(", Consultant Pathologist\n")
    return doc


# ---------------------------------------------------------------- prescription
def make_prescription(r: random.Random, i: int, style: str) -> Doc:
    """style: 'mixed' (English drugs, Bangla dosing — the usual BD format) or 'en'."""
    doc = Doc(f"rx_{style}_{i:04d}", "prescription", "mixed" if style == "mixed" else "en")
    sex = r.choice("MF")
    _add_doctor(doc, r)
    doc.add(f", {r.choice(DEGREES)}\nChamber: ")
    doc.add_pii(r.choice(FACILITIES), "FACILITY")
    doc.add(", ")
    doc.add_pii(r.choice(AREAS), "ADDRESS")
    doc.add("\nPt: ")
    doc.add_pii(_name(r, sex), "NAME")
    doc.add(f"   {r.randint(18, 80)} {sex}   Date: ")
    doc.add_pii(_date(r, bangla=(style == "mixed" and r.random() < 0.3)), "DATE")
    if r.random() < 0.5:
        doc.add("   Mob: ")
        doc.add_pii(_phone(r), "PHONE")
    doc.add("\nRx\n")
    for k, (brand, generic, strengths, form) in enumerate(r.sample(DRUGS, r.randint(2, 5)), start=1):
        strength = r.choice(strengths)
        pat = r.choice(DOSE_PATTERNS)
        food = r.choice(["after", "after", "before"]) if generic not in ("Omeprazole", "Esomeprazole", "Pantoprazole") else "before"
        doc.add(f"{k}. {form} ")
        bs, be = doc.span(brand)
        doc.add(" ")
        ss, se = doc.span(strength)
        doc.add("   ")
        if style == "mixed":
            ps, pe = doc.span(to_bangla_digits("+".join(map(str, pat))) if r.random() < 0.8 else "+".join(map(str, pat)))
            doc.add(" — ")
            doc.add("খাবার পরে" if food == "after" else "খাবার আগে")
            dur_s, dur = r.choice(DURATIONS_BN)
        else:
            ps, pe = doc.span("+".join(map(str, pat)) if r.random() < 0.5 else EN_FREQ[pat])
            doc.add(" — ")
            doc.add("after meal" if food == "after" else "before meal")
            dur_s, dur = r.choice(DURATIONS_EN)
        doc.add(" — ")
        ds, de = doc.span(dur_s)
        doc.add("\n")
        doc.meds.append({"brand": brand, "generic": generic, "strength": strength, "form": form,
                         "dose": list(pat), "food": food, "duration_days": dur,
                         "brand_span": [bs, be], "strength_span": [ss, se], "dose_span": [ps, pe], "duration_span": [ds, de]})
    if style == "mixed":
        doc.add("পরামর্শ: " + " ".join(r.sample(ADVICE_BN, 2)) + "\n")
    else:
        doc.add("Advice: walk daily, reduce sugar, follow up after 1 month.\n")
    return doc


# ---------------------------------------------------------------- Bangla note
def make_bn_note(r: random.Random, i: int) -> Doc:
    """Short Bangla discharge/follow-up note with Bangla-script PII."""
    doc = Doc(f"bn_{i:04d}", "bn_note", "bn")
    sex = r.choice("MF")
    doc.add("রোগীর নাম: ")
    doc.add_pii(_name(r, sex, bangla=True), "NAME")
    doc.add(f", বয়স: {to_bangla_digits(str(r.randint(18, 80)))} বছর\nঠিকানা: ")
    doc.add_pii(r.choice(BN_AREAS), "ADDRESS")
    doc.add("\nমোবাইল: ")
    doc.add_pii(to_bangla_digits(_phone(r)), "PHONE")
    if r.random() < 0.4:
        doc.add("\nএনআইডি: ")
        doc.add_pii(to_bangla_digits(_nid(r)), "NID")
    doc.add("\nভর্তির তারিখ: ")
    doc.add_pii(_date(r, bangla=True), "DATE")
    brand, generic, strengths, form = r.choice(DRUGS)
    pat = r.choice(DOSE_PATTERNS)
    doc.add("\nরোগীকে ")
    bs, be = doc.span(brand)
    doc.add(" ")
    ss, se = doc.span(to_bangla_digits(r.choice(strengths).replace(" mg", "")) + " মি.গ্রা.")
    doc.add(" দেওয়া হয়েছে, ")
    ps, pe = doc.span(to_bangla_digits("+".join(map(str, pat))))
    doc.add(" খাবার পরে। চিকিৎসক: ")
    _add_doctor(doc, r, bangla=True)
    doc.add("।\n")
    doc.meds.append({"brand": brand, "generic": generic, "strength": None, "form": form, "dose": list(pat),
                     "food": "after", "duration_days": None, "brand_span": [bs, be], "strength_span": [ss, se],
                     "dose_span": [ps, pe], "duration_span": None})
    return doc


# ---------------------------------------------------------------- PII injection into real text
def inject_pii(text: str, lang: str, r: random.Random, doc_id: str) -> Doc:
    """Wrap a real (already de-identified) text with fake identifiers at known offsets.

    Used on PMC-Patients (English) and Bangla-HealthNER (Bangla) to measure PII
    leakage on real clinical language without touching real patient identities.
    """
    bangla = lang == "bn"
    doc = Doc(doc_id, "injected", lang)
    doc.add("রোগী: " if bangla else "Patient: ")
    doc.add_pii(_name(r, r.choice("MF"), bangla), "NAME")
    doc.add(", মোবাইল " if bangla else ", phone ")
    ph = _phone(r)
    doc.add_pii(to_bangla_digits(ph) if bangla and r.random() < 0.5 else ph, "PHONE")
    doc.add(", তারিখ " if bangla else ", seen on ")
    doc.add_pii(_date(r, bangla=bangla and r.random() < 0.5), "DATE")
    doc.add("।\n" if bangla else ".\n")
    doc.add(text.strip())
    doc.add("\n")
    doc.add("যোগাযোগ: " if bangla else "Follow-up with ")
    _add_doctor(doc, r, bangla)
    doc.add(", " if bangla else " at ")
    doc.add_pii(r.choice(FACILITIES), "FACILITY")
    doc.add("।\n" if bangla else ".\n")
    return doc


def generate(n_lab=100, n_rx_mixed=100, n_rx_en=40, n_bn=60, seed=42, vocab="dev") -> list[dict]:
    use_vocab(vocab)
    r = random.Random(seed)
    docs = [make_lab(r, i) for i in range(n_lab)]
    docs += [make_prescription(r, i, "mixed") for i in range(n_rx_mixed)]
    docs += [make_prescription(r, i, "en") for i in range(n_rx_en)]
    docs += [make_bn_note(r, i) for i in range(n_bn)]
    use_vocab("dev")
    out = [d.to_dict() for d in docs]
    if vocab != "dev":
        for d in out:
            d["doc_id"] = f"{vocab}_{d['doc_id']}"
    for d in out:  # self-check: every gold span must match its text
        for p in d["pii"]:
            assert d["text"][p["start"]:p["end"]] == p["text"], p
    return out


def write_jsonl(rows, path):
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
