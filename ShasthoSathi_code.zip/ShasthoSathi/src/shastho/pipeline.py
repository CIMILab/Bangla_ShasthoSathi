"""End-to-end, on-device pipeline (the system evaluated in E1–E6c).

    report text
      -> 1. privacy   : rule spans (+ OpenMed PII models) ; medicine/dosage spans protected (E3b)
      -> 2. medicines : fine-tuned Bangla-HealthNER tagger (E4/E5)            [optional]
      -> 3. lab flags : parse "test value unit range" rows ; rules decide high/low/normal
      -> 4. explain   : English = strict LLM (E6c) behind the number check ; Bengali = template
    The LLM never sees the report: it only receives the rule-computed fact sheet.

Every stage degrades gracefully: without OpenMed, the tagger or an LLM, the pipeline still runs with
rules + template (what a first app release would ship).
"""
from __future__ import annotations

import time

from .explain import SYSTEM, gate, strict_prompt, template
from .pii_rules import rule_spans
from .protect import subtract
from .rules import parse_lab_lines


def _merge(spans):
    out = []
    for s, e, lab in sorted(spans):
        if out and s <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], e), out[-1][2])
        else:
            out.append((s, e, lab))
    return out


_PUNCT = set(",;:.।()[]{}-/|\"'")


def _trim(text, spans):
    """Strip surrounding whitespace / punctuation from each span; drop pieces that are only whitespace or
    punctuation (left over when protected words are cut out of a model span). Letters and Bengali vowel
    signs are never trimmed, so no part of a name can be left visible."""
    out = []
    for s, e in spans:
        while s < e and (text[s].isspace() or text[s] in _PUNCT):
            s += 1
        while e > s and (text[e - 1].isspace() or text[e - 1] in _PUNCT):
            e -= 1
        if e > s:
            out.append((s, e))
    return out


class Pipeline:
    def __init__(self, device="cpu", openmed=False, pii_threshold=0.3, protect_model=None, llm=None, llm_quant="4bit"):
        self.device, self.th = device, pii_threshold
        self.om = None
        if openmed:
            from .openmed_adapter import OpenMedRunner
            self.om = OpenMedRunner(device)
        self.prot = None
        if protect_model:
            from .protect import ClinicalProtector
            self.prot = ClinicalProtector(protect_model, device)
        self.llm = self.tok = None
        if llm:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
            kw = dict(dtype=torch.bfloat16, device_map="auto")
            if llm_quant == "4bit":
                try:
                    import bitsandbytes  # noqa: F401
                    from transformers import BitsAndBytesConfig
                    kw["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                                                    bnb_4bit_compute_dtype=torch.bfloat16)
                except Exception:
                    pass
            self.tok = AutoTokenizer.from_pretrained(llm)
            self.llm = AutoModelForCausalLM.from_pretrained(llm, **kw).eval()
            self.torch = torch

    # ------------------------------------------------------------ stages
    @staticmethod
    def lab_rows(text):
        """Character spans of lines that parse as 'test value unit range' rows: they hold no personal
        details, so model spans inside them are dropped (fixes e.g. 'U/L 7-45' being redacted)."""
        rows, pos = [], 0
        lines = text.splitlines(keepends=True)
        wanted = {l.line for l in parse_lab_lines(text)}
        for i, ln in enumerate(lines, start=1):
            if i in wanted:
                rows.append((pos, pos + len(ln.rstrip("\n"))))
            pos += len(ln)
        return rows

    def privacy(self, text):
        rs = [(s, e, lab) for s, e, lab, _ in rule_spans(text)]
        kept, ms = [], []
        if self.prot:
            kept = self.prot.spans(text)
        if self.om:
            spans, _, _ = self.om.pii_auto(text, self.th, "script")
            ms = [(s, e, "PII") for s, e, *_ in spans]
            ms = [(s, e, "PII") for s, e in _trim(text, subtract(ms, kept + self.lab_rows(text)))]
        merged = _merge(rs + ms)
        red, last = [], 0
        for s, e, lab in merged:
            red.append(text[last:s]); red.append(f"[{lab}]"); last = e
        red.append(text[last:])
        return "".join(red), merged, kept

    def explain(self, labs, lang):
        if lang == "bn" or self.llm is None or not labs:
            return {"source": "template", "text": template(labs, lang), "blocked_numbers": []}
        msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": strict_prompt(labs, lang)}]
        try:
            prompt = self.tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True, enable_thinking=False)
        except Exception:
            prompt = self.tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        enc = self.tok(prompt, return_tensors="pt", add_special_tokens=False).to(self.llm.device)
        with self.torch.inference_mode():
            out = self.llm.generate(**enc, max_new_tokens=400, do_sample=False)
        text = self.tok.decode(out[0, enc["input_ids"].shape[1]:], skip_special_tokens=True)
        import re
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
        return gate(text, labs, lang)

    def run(self, text: str, lang: str = "bn") -> dict:
        t, T = time.perf_counter(), {}
        redacted, pii, kept = self.privacy(text); T["privacy_ms"] = 1000 * (time.perf_counter() - t)
        t = time.perf_counter()
        labs = [l.to_dict() for l in parse_lab_lines(text)]           # lab rows contain no personal details
        T["labs_ms"] = 1000 * (time.perf_counter() - t)
        t = time.perf_counter()
        exp = self.explain(labs, lang); T["explain_ms"] = 1000 * (time.perf_counter() - t)
        counts = {}
        for _, _, lab in pii:
            counts[lab] = counts.get(lab, 0) + 1
        return {"lang": lang, "redacted_text": redacted, "personal_details_removed": counts,
                "medicines": [{"text": text[s:e], "type": typ} for s, e, typ in kept],
                "labs": labs, "abnormal": [l["name"] for l in labs if l["flag"] in ("high", "low")],
                "explanation": exp, "timing_ms": {k: round(v, 1) for k, v in T.items()},
                "stages": {"openmed": self.om is not None, "medicine_tagger": self.prot is not None,
                           "llm": self.llm is not None}}
