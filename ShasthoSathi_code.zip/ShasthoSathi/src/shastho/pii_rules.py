"""Deterministic PII rules for Bangladeshi health documents.

These rules are generic: they use formats (phone numbering plan, ID shapes,
facility-name suffixes, a gazetteer of Bangladesh's 64 districts, field labels)
and never the specific names in the synthetic generator. E3 checks that on a
held-out vocabulary.
"""
from __future__ import annotations

import re

D = "[0-9০-৯]"          # ASCII or Bangla digit

# ---- phone: Bangladesh mobile numbers 01[3-9]XXXXXXXX, optional +880 / 880 prefix
PHONE = re.compile(rf"(?<!{D})(?:\+?(?:880|৮৮০|88|৮৮)[-\s]?(?:0|০)?|(?:0|০))(?:1|১)[3-9৩-৯]{D}{{2}}[-\s]?{D}{{6}}(?!{D})")

# ---- national ID: 10, 13 or 17 digits standing alone
NID = re.compile(rf"(?<!{D})(?:{D}{{17}}|{D}{{13}}|{D}{{10}})(?!{D})")

# ---- record / lab IDs: letters + digit groups joined by - or /  (SDC-24-08817, REG/2026/1182)
REC_ID = re.compile(r"\b[A-Z]{2,6}[-/]\d{2,4}(?:[-/]\d{2,8})+\b")
LABELLED_ID = re.compile(r"(?i)\b(?:lab\s*id|patient\s*id|reg(?:istration)?\.?\s*no|mrn|invoice\s*no)\s*[:#.]?\s*([A-Za-z0-9][A-Za-z0-9/\-]{3,})")

# ---- facilities: 1–4 name words + a facility suffix (Title Case or ALL CAPS)
_WORD = r"(?:[A-Z][a-z'.]+|[A-Z]{2,}|&)"
_SUFFIX = (r"(?i:diagnostic\s+cent(?:er|re)|diagnostics?|clinic(?:\s*&\s*lab)?|(?:general\s+|specialized\s+)?hospital|"
           r"medical\s+(?:cent(?:er|re)|services|college(?:\s+hospital)?)|health\s+(?:point|care|cent(?:er|re))|"
           r"pathology(?:\s+lab)?|laborator(?:y|ies)|nursing\s+home)\b")
FACILITY = re.compile(rf"\b(?:{_WORD}\s+){{1,4}}{_SUFFIX}")
# Bangla: one or two name words + suffix, the suffix not inflected (হাসপাতালে = "to a hospital" is generic),
# and the name word not a generic modifier ("nearby", "any", "good" ...).
_BN_GENERIC = ("নিকটস্থ|নিকটবর্তী|কাছের|কোন|কোনো|যেকোনো|ও|এবং|ভালো|ভাল|বড়|সরকারি|বেসরকারি|একটি|আপনি|আপনার|"
               "ডাক্তার|বিশেষজ্ঞ|জেলা|উপজেলা|হবে|যান|করুন|নিয়ে|থেকে|কিংবা|অথবা|বা")
BN_FACILITY = re.compile(rf"(?<![^\s,।:])(?:(?!(?:{_BN_GENERIC})\s)[^\s,।:]+\s+){{1}}"
                         r"(?:হাসপাতাল|ক্লিনিক|ডায়াগনস্টিক\s+সেন্টার|মেডিকেল\s+কলেজ(?:\s+হাসপাতাল)?)(?=[\s,।]|$)")

# ---- addresses: "<place words>, <district>" with a gazetteer of the 64 districts (+ old spellings)
DISTRICTS_EN = """Bagerhat Bandarban Barguna Barishal Barisal Bhola Bogura Bogra Brahmanbaria Chandpur Chapai\\s+Nawabganj
Chattogram Chittagong Chuadanga Cox's\\s+Bazar Cumilla Comilla Dhaka Dinajpur Faridpur Feni Gaibandha Gazipur Gopalganj
Habiganj Jamalpur Jashore Jessore Jhalokati Jhenaidah Joypurhat Khagrachhari Khulna Kishoreganj Kurigram Kushtia
Lakshmipur Lalmonirhat Madaripur Magura Manikganj Meherpur Moulvibazar Munshiganj Mymensingh Naogaon Narail
Narayanganj Narsingdi Natore Netrokona Nilphamari Noakhali Pabna Panchagarh Patuakhali Pirojpur Rajbari Rajshahi
Rangamati Rangpur Satkhira Shariatpur Sherpur Sirajganj Sunamganj Sylhet Tangail Thakurgaon""".split()
DISTRICTS_BN = ("ঢাকা চট্টগ্রাম সিলেট রাজশাহী খুলনা বরিশাল রংপুর ময়মনসিংহ কুমিল্লা গাজীপুর নারায়ণগঞ্জ "
                "বগুড়া যশোর দিনাজপুর ফরিদপুর নোয়াখালী টাঙ্গাইল পাবনা কুষ্টিয়া কক্সবাজার").split()
_DIST = "|".join(DISTRICTS_EN + DISTRICTS_BN)
ADDRESS = re.compile(rf"(?:[^\s,:।]+[ \t]+){{0,3}}[^\s,:।]+,[ \t]*(?:{_DIST})(?![^\s,।])")

# ---- labelled fields: the rest of the line after "Address:" / "ঠিকানা:"
LABELLED_ADDR = re.compile(r"(?:Address|ঠিকানা)\s*[:：]\s*([^\n]+)")

RULES = [
    ("PHONE", PHONE, 0), ("NID", NID, 0), ("ID", REC_ID, 0), ("ID", LABELLED_ID, 1),
    ("FACILITY", FACILITY, 0), ("FACILITY", BN_FACILITY, 0),
    ("ADDRESS", ADDRESS, 0), ("ADDRESS", LABELLED_ADDR, 1),
]


# ---- v2 (E7b): field-label rules for the header of a report, so privacy does not rest on the model alone.
# Generic formats only: numeric dates, "Name:/Patient:/রোগীর নাম:" fields and the "Dr./ডা./ডাঃ" title.
_NB = r"(?<![0-9০-৯.])"; _NA = r"(?![0-9০-৯.])"
DATE = re.compile(rf"{_NB}{D}{{1,2}}([./-]){D}{{1,2}}\1(?:{D}{{4}}|{D}{{2}}){_NA}")
_MON = r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?"
DATE_TEXT = re.compile(rf"(?i)\b(?:\d{{1,2}}(?:st|nd|rd|th)?\s+{_MON},?\s+\d{{4}}|{_MON}\s+\d{{1,2}},?\s+\d{{4}})\b")
_STOP = r"(?:Age|Sex|Date|Mob|Mobile|Phone|ID|বয়স|লিঙ্গ|তারিখ|মোবাইল)(?=[\s:.]|$)"
_NW = rf"(?:(?!{_STOP})[^\s0-9০-৯:,;।()\[\]]+)"          # one name word
LABELLED_NAME = re.compile(rf"(?i:\b(?:patient(?:'s)?\s+name|patient|pt|name)\b\.?|রোগীর\s+নাম|রোগী|নাম)[ \t]*[:：][ \t]*({_NW}(?: {_NW}){{0,3}})")
DOCTOR = re.compile(r"\b(?:Dr|DR)\.?[ \t]+((?:[A-Z][A-Za-z'-]+|[A-Z]\.)(?: (?:[A-Z][A-Za-z'-]+|[A-Z]\.)){0,3})")
BN_DOCTOR = re.compile(rf"(?:ডাঃ|ডা\.)[ \t]*({_NW}(?: {_NW}){{0,2}})")
RULES_V2 = [("DATE", DATE, 0), ("DATE", DATE_TEXT, 0), ("NAME", LABELLED_NAME, 1),
            ("DOCTOR", DOCTOR, 1), ("DOCTOR", BN_DOCTOR, 1)]


def rule_spans(text: str, v2: bool = False) -> list[tuple]:
    """Return (start, end, label, 1.0) for every rule match. v2 adds the E7b header rules."""
    out = []
    for label, rx, group in RULES + (RULES_V2 if v2 else []):
        for m in rx.finditer(text):
            s, e = m.span(group)
            if e > s:
                out.append((s, e, label, 1.0))
    return out
