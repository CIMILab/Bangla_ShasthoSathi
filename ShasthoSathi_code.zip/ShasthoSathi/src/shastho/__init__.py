"""ShasthoSathi: offline, privacy-first health report explainer for low-cost mobile devices."""
__version__ = "0.1.0"
