"""Deterministic rule layer for ShasthoSathi.

These rules run after the models. They do the jobs that must never be left to an
LLM: deciding whether a lab value is abnormal, reading Bangladeshi dose patterns
such as "১+০+১", and blocking any explanation that mentions a number the report
does not contain.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Iterable, Optional

# ---------------------------------------------------------------- digits
BN_DIGITS = "০১২৩৪৫৬৭৮৯"
_BN2EN = str.maketrans({b: str(i) for i, b in enumerate(BN_DIGITS)})
_EN2BN = str.maketrans({str(i): b for i, b in enumerate(BN_DIGITS)})


def to_ascii_digits(s: str) -> str:
    """'১২.৫' -> '12.5'. Leaves every other character unchanged (same length)."""
    return s.translate(_BN2EN)


def to_bangla_digits(s: str) -> str:
    return s.translate(_EN2BN)


# ---------------------------------------------------------------- lab flags
@dataclass
class LabResult:
    name: str
    value: float
    unit: str
    low: Optional[float]
    high: Optional[float]
    flag: str  # "low" | "normal" | "high" | "unknown"
    line: Optional[int] = None

    def to_dict(self):
        return asdict(self)


def flag_value(value: float, low: Optional[float], high: Optional[float]) -> str:
    """Compare a value with its reference range. Ends of the range count as normal."""
    if low is None and high is None:
        return "unknown"
    if low is not None and value < low:
        return "low"
    if high is not None and value > high:
        return "high"
    return "normal"


_NUM = r"[0-9০-৯]+(?:[.,][0-9০-৯]+)?"
# "Haemoglobin   9.8 g/dL   12.0–15.5"  or  "HbA1c 7.4 % 4.0-5.6"  or "... < 5.6"
_LAB_LINE = re.compile(
    rf"^\s*(?P<name>[A-Za-z][A-Za-z0-9 .()/+\-]*?)\s+(?P<val>{_NUM})\s*(?P<unit>\S*?)\s+"
    rf"(?:(?P<lo>{_NUM})\s*[–\-—to]+\s*(?P<hi>{_NUM})|<\s*(?P<lt>{_NUM})|>\s*(?P<gt>{_NUM}))\s*$"
)


def _f(x: Optional[str]) -> Optional[float]:
    return None if x is None else float(to_ascii_digits(x).replace(",", "."))


def parse_lab_lines(text: str) -> list[LabResult]:
    """Pull 'test value unit range' rows out of a report and flag each one."""
    out = []
    for i, raw in enumerate(text.splitlines(), start=1):
        m = _LAB_LINE.match(raw)
        if not m:
            continue
        lo, hi = _f(m["lo"]), _f(m["hi"])
        if m["lt"]:
            lo, hi = None, _f(m["lt"])
        if m["gt"]:
            lo, hi = _f(m["gt"]), None
        val = _f(m["val"])
        out.append(LabResult(m["name"].strip(), val, m["unit"], lo, hi, flag_value(val, lo, hi), i))
    return out


# ---------------------------------------------------------------- dose patterns
_FRACTIONS = {"½": 0.5, "১/২": 0.5, "1/2": 0.5, "¼": 0.25}
_DOSE = re.compile(r"(?<![0-9০-৯])((?:½|¼|[0-9০-৯](?:/[0-9০-৯])?)(?:\s*\+\s*(?:½|¼|[0-9০-৯](?:/[0-9০-৯])?)){2,3})(?![0-9০-৯])")


def _slot(tok: str) -> float:
    tok = tok.strip()
    if tok in _FRACTIONS:
        return _FRACTIONS[tok]
    tok = to_ascii_digits(tok)
    if "/" in tok:
        a, b = tok.split("/")
        return float(a) / float(b)
    return float(tok)


def parse_dose_pattern(s: str) -> Optional[tuple]:
    """'১+০+১' -> (1, 0, 1). Returns morning/noon/night (or 4 slots) or None."""
    m = _DOSE.search(s)
    if not m:
        return None
    vals = tuple(_slot(t) for t in m.group(1).split("+"))
    return tuple(int(v) if float(v).is_integer() else v for v in vals)


_BEFORE = ("খাবার আগে", "খাবারের আগে", "খালি পেটে", "before meal", "before food", "a.c.", "ac ")
_AFTER = ("খাবার পরে", "খাবারের পরে", "খাবার পর", "after meal", "after food", "p.c.", "pc ")


def parse_food_relation(s: str) -> Optional[str]:
    low = s.lower()
    if any(k in low for k in _BEFORE):
        return "before"
    if any(k in low for k in _AFTER):
        return "after"
    return None


_DUR = re.compile(r"([0-9০-৯]+)\s*(দিন|সপ্তাহ|মাস|days?|weeks?|months?)", re.I)
_UNIT_DAYS = {"দিন": 1, "day": 1, "days": 1, "সপ্তাহ": 7, "week": 7, "weeks": 7, "মাস": 30, "month": 30, "months": 30}


def parse_duration_days(s: str) -> Optional[int]:
    """'৫ দিন' -> 5, '১ মাস' -> 30, 'চলবে'/'continue' -> -1 (ongoing), else None."""
    if re.search(r"চলবে|continue|ongoing", s, re.I):
        return -1
    m = _DUR.search(s)
    if not m:
        return None
    return int(to_ascii_digits(m.group(1))) * _UNIT_DAYS[m.group(2).lower()]


# ---------------------------------------------------------------- number check
_ANY_NUM = re.compile(r"(?<![\w.])[0-9০-৯]+(?:[.,][0-9০-৯]+)?")


def numbers_in(text: str) -> list[str]:
    return [to_ascii_digits(n).replace(",", ".") for n in _ANY_NUM.findall(text)]


def _canon(n: str) -> str:
    try:
        return repr(float(n))
    except ValueError:
        return n


def unsupported_numbers(generated: str, source: str, allowed: Iterable[str] = ()) -> list[str]:
    """Numbers in `generated` that never appear in `source` (or in `allowed`).

    An empty list means the explanation passes. Formatting differences
    (9.8 vs 9.80, ৯.৮ vs 9.8) are treated as the same number.
    """
    ok = {_canon(n) for n in numbers_in(source)} | {_canon(to_ascii_digits(a)) for a in allowed}
    return [n for n in numbers_in(generated) if _canon(n) not in ok]
