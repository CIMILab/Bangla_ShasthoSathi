"""Reference implementation of the on-phone pipeline (E7).

It uses only onnxruntime, the `tokenizers` library (the same tokenizer.json the app loads) and plain
loops, so the Kotlin app can follow it line by line. Its outputs on the held-out reports
(mobile/golden/golden.jsonl) are the app's unit tests: the phone must give the same spans and text.

Differences from the research pipeline (src/shastho/pipeline.py), measured in E7a:
  * models are the INT8 ONNX files, not PyTorch / the openmed package;
  * both taggers work on whitespace words (each word tokenized on its own, then windows of
    max_len tokens that overlap by `stride`), so a whole word is redacted or kept;
  * the explanation is always the template (no LLM in the first app release).
"""
from __future__ import annotations

import json
import pathlib
import re
import time

import numpy as np

from .explain import template
from .pii_rules import rule_spans
from .pipeline import Pipeline, _merge, _trim
from .protect import subtract
from .rules import parse_lab_lines

WORD = re.compile(r"\S+")
BN_RE, LAT_RE = re.compile(r"[ঀ-৿]"), re.compile(r"[A-Za-z]")


def route(text: str) -> list[str]:
    """Which PII model(s) to run: English for Latin-only text, Bengali for Bangla-only, both if mixed."""
    b, l = bool(BN_RE.search(text)), bool(LAT_RE.search(text))
    return ["en", "bn"] if b and l else ["bn"] if b else ["en"]


class OnnxWordTagger:
    """Token-classification model in ONNX, applied to whitespace words."""

    def __init__(self, folder, threads: int = 4, variant: str = "int8"):
        import onnxruntime as ort
        from tokenizers import Tokenizer

        folder = pathlib.Path(folder)
        meta = json.load(open(folder / "meta.json", encoding="utf-8"))
        self.labels = meta["labels"]
        self.cls, self.sep = meta["cls_id"], meta["sep_id"]
        self.L, self.stride = meta["max_len"] - 2, meta["stride"]
        self.tok = Tokenizer.from_file(str(folder / "tokenizer.json"))
        self.tok.no_truncation(); self.tok.no_padding()
        so = ort.SessionOptions(); so.intra_op_num_threads = threads; so.inter_op_num_threads = 1
        self.sess = ort.InferenceSession(str(folder / f"model_{variant}.onnx"), so, providers=["CPUExecutionProvider"])
        self.inputs = {i.name for i in self.sess.get_inputs()}

    def word_pieces(self, words):
        """Each word tokenized on its own (no special tokens). Returns token ids and their word index."""
        ids, wid = [], []
        for i, w in enumerate(words):
            e = self.tok.encode(w, add_special_tokens=False)
            ids += e.ids; wid += [i] * len(e.ids)
        return ids, wid

    def token_probs(self, ids):
        """Softmax per token. Windows of L tokens overlapping by `stride`; the first window that sees a token wins."""
        n, out, start = len(ids), [None] * len(ids), 0
        while n:
            chunk = ids[start:start + self.L]
            x = np.array([[self.cls] + chunk + [self.sep]], dtype=np.int64)
            feed = {"input_ids": x}
            if "attention_mask" in self.inputs:
                feed["attention_mask"] = np.ones_like(x)
            if "token_type_ids" in self.inputs:
                feed["token_type_ids"] = np.zeros_like(x)
            z = self.sess.run(None, feed)[0][0][1:-1].astype(np.float64)
            p = np.exp(z - z.max(-1, keepdims=True)); p /= p.sum(-1, keepdims=True)
            for j in range(len(chunk)):
                if out[start + j] is None:
                    out[start + j] = p[j]
            if start + self.L >= n:
                break
            start += self.L - self.stride
        return out

    def word_labels(self, words, mode: str):
        """[(label, score)] per word.
        'first' = first sub-token (how the E4 tagger was trained);
        'mean'  = average of the word's token probabilities;
        'max'   = the token most likely to be personal (highest 1 - P(O)) decides; score = 1 - P(O).
                  Recall-first: one confident sub-token is enough to hide the whole word."""
        return self.word_labels_all(words, (mode,))[mode]

    def word_labels_all(self, words, modes=("mean", "max")):
        ids, wid = self.word_pieces(words)
        probs = self.token_probs(ids)
        per = [[] for _ in words]
        for p, w in zip(probs, wid):
            per[w].append(p)
        o = self.labels.index("O") if "O" in self.labels else None
        out = {m: [] for m in modes}
        for ps in per:
            for m in modes:
                if not ps:
                    out[m].append(("O", 1.0)); continue
                if m == "max" and o is not None:
                    ent = [1.0 - p[o] for p in ps]
                    p = ps[int(np.argmax(ent))].copy(); score = float(max(ent)); p[o] = -1.0
                    out[m].append((self.labels[int(np.argmax(p))], score))
                    continue
                v = ps[0] if m == "first" else np.mean(ps, axis=0)
                k = int(np.argmax(v)); out[m].append((self.labels[k], float(v[k])))
        return out


def group(spans, labels, types=None, threshold: float = 0.0):
    """Consecutive words with the same entity type -> (start, end, type, mean score).
    A 'B-' tag starts a new entity; spans below `threshold` are dropped."""
    out, cur = [], None

    def flush():
        if cur and float(np.mean(cur[3])) >= threshold:
            out.append((cur[0], cur[1], cur[2], round(float(np.mean(cur[3])), 4)))

    for (s, e), (lab, sc) in zip(spans, labels):
        typ = None if lab == "O" else re.sub(r"^[BIES]-", "", lab)
        if typ and (types is None or typ in types):
            if cur and cur[2] == typ and not lab.startswith("B-"):
                cur[1] = e; cur[3].append(sc)
            else:
                flush(); cur = [s, e, typ, [sc]]
        else:
            flush(); cur = None
    flush()
    return out


class MobilePipeline:
    def __init__(self, assets="mobile/assets", threads: int = 4, pii_threshold: float | None = None,
                 variant: str | None = None, agg: str | None = None, rules_v2: bool | None = None,
                 use_models: bool = True):
        """Settings not given here come from assets/pipeline_config.json (written by E7b), else the E7a defaults."""
        a = pathlib.Path(assets)
        cfg = {"ner_variant": "int8", "pii_variant": "int8", "agg": "mean", "threshold": 0.3, "rules_v2": False}
        if (a / "pipeline_config.json").exists():
            cfg.update(json.load(open(a / "pipeline_config.json", encoding="utf-8")))
        if variant:                                       # force one variant for every model (e.g. fp32 reference)
            cfg["ner_variant"] = cfg["pii_variant"] = variant
        self.th = cfg["threshold"] if pii_threshold is None else pii_threshold
        self.agg = cfg["agg"] if agg is None else agg
        self.rules_v2 = cfg["rules_v2"] if rules_v2 is None else rules_v2
        self.config = {**cfg, "threshold": self.th, "agg": self.agg, "rules_v2": self.rules_v2}
        self.tagger = OnnxWordTagger(a / "ner", threads, cfg["ner_variant"]) if use_models and (a / "ner").exists() else None
        pv = cfg["pii_variant"]                           # one variant for both, or {"bn": ..., "en": ...} (E7b)
        pv = pv if isinstance(pv, dict) else {"bn": pv, "en": pv}
        self.pii = {lg: OnnxWordTagger(a / f"pii_{lg}", threads, pv[lg])
                    for lg in ("bn", "en") if use_models and (a / f"pii_{lg}").exists()}

    def analyse(self, text: str) -> dict:
        """Everything the privacy step needs, computed once (lets E7a sweep thresholds cheaply)."""
        ms = list(WORD.finditer(text))
        words, spans = [m.group() for m in ms], [m.span() for m in ms]
        kept = group(spans, self.tagger.word_labels(words, "first"), types={"Medicine", "Dosage"}) if self.tagger else []
        pii_words = {lg: self.pii[lg].word_labels(words, self.agg) for lg in route(text) if lg in self.pii}
        return {"spans": spans, "kept": kept, "pii_words": pii_words}

    def privacy(self, text: str, an: dict | None = None, threshold: float | None = None):
        an = an or self.analyse(text)
        th = self.th if threshold is None else threshold
        rs = [(s, e, lab) for s, e, lab, _ in rule_spans(text, self.rules_v2)]
        model = []
        for lg, labs in an["pii_words"].items():
            model += [(s, e) for s, e, _, _ in group(an["spans"], labs, threshold=th)]
        model = [(s, e, "PII") for s, e in _trim(text, subtract(model, [k[:2] for k in an["kept"]] + Pipeline.lab_rows(text)))]
        merged = _merge(rs + model)
        red, last = [], 0
        for s, e, lab in merged:
            red.append(text[last:s]); red.append(f"[{lab}]"); last = e
        red.append(text[last:])
        return "".join(red), merged

    def run(self, text: str, lang: str = "bn") -> dict:
        t0 = time.perf_counter(); an = self.analyse(text); t1 = time.perf_counter()
        redacted, merged = self.privacy(text, an); t2 = time.perf_counter()
        labs = [l.to_dict() for l in parse_lab_lines(text)]
        exp = template(labs, lang); t3 = time.perf_counter()
        counts = {}
        for _, _, lab in merged:
            counts[lab] = counts.get(lab, 0) + 1
        return {"lang": lang, "redacted_text": redacted, "spans": [list(m) for m in merged],
                "personal_details_removed": counts,
                "medicines": [{"text": text[s:e], "type": t} for s, e, t, _ in an["kept"]],
                "labs": labs, "abnormal": [l["name"] for l in labs if l["flag"] in ("high", "low")],
                "explanation": {"source": "template", "text": exp},
                "timing_ms": {"models_ms": round(1000 * (t1 - t0), 1), "rules_ms": round(1000 * (t2 - t1), 1),
                              "labs_explain_ms": round(1000 * (t3 - t2), 1)}}
