"""Explanation layer used by the app: rule-computed fact sheet, deterministic templates (EN / BN),
the strict LLM prompt chosen in E6c, and the number-check gate."""
from __future__ import annotations

import re

from .rules import unsupported_numbers

BN_LABEL = {  # patient-facing Bengali test names (no digits, so the number check stays exact)
    "haemoglobin": "হিমোগ্লোবিন", "hemoglobin": "হিমোগ্লোবিন", "wbc count": "শ্বেত রক্তকণিকা",
    "platelet count": "প্লাটিলেট (অণুচক্রিকা)", "fasting blood sugar": "খালি পেটে রক্তের শর্করা",
    "hba1c": "গড় রক্তের শর্করা (HbA1c)", "s. creatinine": "ক্রিয়েটিনিন (কিডনির পরীক্ষা)",
    "serum creatinine": "ক্রিয়েটিনিন (কিডনির পরীক্ষা)", "sgpt (alt)": "এসজিপিটি (লিভারের এনজাইম)",
    "serum uric acid": "ইউরিক অ্যাসিড", "tsh": "টিএসএইচ (থাইরয়েড হরমোন)", "total cholesterol": "মোট কোলেস্টেরল",
    "triglyceride": "ট্রাইগ্লিসারাইড", "vitamin d (25-oh)": "ভিটামিন ডি",
}
STATUS = {
    "en": {"high": "higher than normal", "low": "lower than normal", "normal": "within the normal range",
           "unknown": "has no reference range on the report"},
    "bn": {"high": "স্বাভাবিকের চেয়ে বেশি", "low": "স্বাভাবিকের চেয়ে কম", "normal": "স্বাভাবিক সীমার মধ্যে",
           "unknown": "রিপোর্টে স্বাভাবিক সীমা দেওয়া নেই"},
}
DOCTOR = {"en": "Please show this report to your doctor.", "bn": "এই রিপোর্টটি আপনার ডাক্তারকে দেখান।"}
fmt = lambda x: "" if x is None else f"{x:g}"


def _range(l, lang):
    if l["low"] is None and l["high"] is None:
        return ""
    r = f"{fmt(l['low'])}-{fmt(l['high'])}" if l["low"] is not None and l["high"] is not None else (
        f"< {fmt(l['high'])}" if l["low"] is None else f"> {fmt(l['low'])}")
    return f" (স্বাভাবিক সীমা {r})" if lang == "bn" else f" (normal range {r})"


def bn_label(name: str) -> str | None:
    return BN_LABEL.get(re.sub(r"\s+", " ", name.strip().lower()))


def facts(labs: list[dict]) -> str:
    return "\n".join(f"- {l['name']}: {fmt(l['value'])} {l['unit']}{_range(l, 'en')} -> {l['flag'].upper()}"
                     for l in labs)


def template(labs: list[dict], lang: str) -> str:
    rows = []
    for l in labs:
        st = STATUS[lang][l["flag"]]
        if lang == "bn":
            lab = bn_label(l["name"])
            head = f"{lab} — {l['name']}" if lab else l["name"]
            rows.append(f"{head}: {fmt(l['value'])} {l['unit']} — {st}{_range(l, 'bn')}।")
        else:
            rows.append(f"{l['name']}: {fmt(l['value'])} {l['unit']} is {st}{_range(l, 'en')}.")
    return "\n".join(rows + [DOCTOR[lang]])


STRICT = ("Rules: write exactly one short sentence per test, in the order given, with the test name, the value and "
          "whether it is high, low or normal, exactly as in the facts. Do not explain causes. Do not say what a result "
          "means for health or whether it is good or bad. Do not name any disease. Do not suggest food, lifestyle, "
          "medicines, supplements or more tests. Do not add any number that is not in the facts. After the sentences, "
          "write one final sentence telling the patient to show this report to their doctor.")
SYSTEM = ("You are a careful health assistant. You explain lab reports in plain, friendly language. You never give a "
          "diagnosis, never suggest medicines and never invent numbers.")


def strict_prompt(labs: list[dict], lang: str) -> str:
    name = {"en": "English", "bn": "Bangla (Bengali script)"}[lang]
    return f"These facts were checked by the app:\n{facts(labs)}\n\nRewrite them for the patient in simple {name}.\n{STRICT}"


def gate(text: str, labs: list[dict], lang: str) -> dict:
    """Number check: an LLM text with any number not in the facts is replaced by the template."""
    clean = re.sub(r"(?m)^\s*(?:[-*•]|\(?[0-9০-৯]{1,2}[.)])\s+", "", text.replace("**", ""))
    bad = unsupported_numbers(clean, facts(labs))
    # coverage check: every abnormal test must be named, and its value must appear (cheap guard against omissions)
    low = clean.lower()
    missing = [l["name"] for l in labs if l["flag"] in ("high", "low")
               and (re.sub(r"\s*\(.*?\)", "", l["name"]).lower().replace("s. ", "") not in low or fmt(l["value"]) not in clean)]
    if bad or missing:
        return {"source": "template", "text": template(labs, lang), "blocked_numbers": bad, "missing_tests": missing}
    return {"source": "llm", "text": text, "blocked_numbers": [], "missing_tests": []}
