"""E8 metrics for text read from a photo (OCR). Mirrored in Kotlin (core/.../Ocr.kt) and golden-tested.

  cer          character error rate after collapsing whitespace (layout differences are not counted as errors)
  lab rows     a gold row counts as recovered when a parsed OCR row has the same name, value, unit and range
  flags        a gold row's flag counts as correct when the OCR row with the same name has the same flag
  spurious     parsed OCR rows whose name is not in the gold report
  leak         rules-only privacy (v1 + v2) run on the OCR text; a gold personal detail leaks when any of its
               words (3+ letters/digits) is still visible in the redacted text. Conservative for exact copies,
               lenient for garbled ones (a misread name is not counted as visible).
"""
from __future__ import annotations

import re

from .rules import parse_lab_lines

_WS = re.compile(r"\s+")
_ID_LINE = re.compile(r"(?m)^\s*E8-\d+\s*$")
_TOKEN = re.compile(r"[^\s,.:;()\[\]/|\-।]+")


def norm(t: str) -> str:
    return _WS.sub(" ", _ID_LINE.sub("", t)).strip()


def levenshtein(a: str, b: str) -> int:
    if len(a) < len(b):
        a, b = b, a
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb))
        prev = cur
    return prev[-1]


def cer(ref: str, hyp: str) -> float:
    r, h = norm(ref), norm(hyp)
    return levenshtein(r, h) / max(1, len(r))


def lab_scores(gold: list[dict], hyp_text: str) -> dict:
    got = [l.to_dict() for l in parse_lab_lines(hyp_text)]
    key = lambda n: _WS.sub(" ", n.strip()).lower()
    used, exact, flags = set(), 0, 0
    for g in gold:
        j = next((k for k, h in enumerate(got) if k not in used and key(h["name"]) == key(g["name"])), None)
        if j is None:
            continue
        used.add(j); h = got[j]
        exact += all(h[f] == g[f] for f in ("value", "unit", "low", "high"))
        flags += h["flag"] == g["flag"]
    return {"gold_rows": len(gold), "rows_exact": exact, "flags_correct": flags, "spurious": len(got) - len(used)}


def leak_scores(pii: list[str], redacted: str) -> dict:
    visible = set(_TOKEN.findall(redacted))
    leaked = [p for p in pii if any(len(w) >= 3 and w in visible for w in _TOKEN.findall(p))]
    return {"pii": len(pii), "leaked": len(leaked), "leaked_items": leaked}
