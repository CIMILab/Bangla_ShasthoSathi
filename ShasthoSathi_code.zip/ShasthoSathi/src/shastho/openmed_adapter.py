"""Thin wrapper around the `openmed` package (tested against openmed 2.5.0).

Keeps every OpenMed call in one place so the experiment scripts only see
plain (start, end, label, score) tuples.
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Iterable

BN_PII_MODEL = "OpenMed/OpenMed-PII-Bengali-mSuperClinical-Large-279M-v1"
EN_PII_MODEL = "OpenMed/OpenMed-PII-SuperClinical-Small-44M-v1"


def compat_model_dir(repo_id: str) -> str:
    """Return a local copy of `repo_id` that loads under transformers 4.x.

    Some OpenMed checkpoints were saved with transformers 5, which writes
    `extra_special_tokens` as a list; transformers 4.57 expects a dict and
    crashes ("'list' object has no attribute 'keys'"). We build a folder of
    symlinks to the cached files and rewrite only tokenizer_config.json.
    """
    if os.environ.get("SHASTHO_SKIP_COMPAT"):  # tests without model files
        return repo_id
    from huggingface_hub import snapshot_download

    src = Path(snapshot_download(repo_id))
    cfg = json.loads((src / "tokenizer_config.json").read_text(encoding="utf-8"))
    extra = cfg.get("extra_special_tokens")
    if not isinstance(extra, list):
        return repo_id  # nothing to fix
    root = Path(os.environ.get("HF_HOME", Path.home() / ".cache/huggingface"))
    dst = root / "compat" / repo_id.replace("/", "__")
    dst.mkdir(parents=True, exist_ok=True)
    for f in src.iterdir():
        link = dst / f.name
        if f.name != "tokenizer_config.json" and not link.exists():
            link.symlink_to(f.resolve())
    add = list(dict.fromkeys((cfg.get("additional_special_tokens") or []) + extra))
    cfg["extra_special_tokens"] = {}
    if add:
        cfg["additional_special_tokens"] = add
    (dst / "tokenizer_config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")
    return str(dst)

def local_snapshot(model_key: str) -> str:
    """Registry key or repo id -> path of the already-downloaded snapshot (no network).

    OpenMed verifies a model's checksum against the Hub before loading it by
    name. On an offline compute node (HF_HUB_OFFLINE=1) that check fails, so we
    load the cached files by path instead. The files are the same ones
    `install_all.sh` downloaded from the official OpenMed repos.
    """
    from huggingface_hub import snapshot_download
    from openmed.core.model_registry import get_model_info

    info = get_model_info(model_key)
    repo = info.model_id if info else model_key
    return snapshot_download(repo, local_files_only=True)


def _is_offline_integrity_error(exc: Exception) -> bool:
    msg = f"{type(exc).__name__}: {exc}"
    return "ntegrity" in msg and ("offline" in msg.lower() or "Cannot reach" in msg)


BN_RE = re.compile(r"[ঀ-৿]")
LAT_RE = re.compile(r"[A-Za-z]")


def text_script(text: str) -> str:
    b, l = bool(BN_RE.search(text)), bool(LAT_RE.search(text))
    return "mixed" if b and l else "bn" if b else "en"


def _entities(result) -> Iterable:
    ents = getattr(result, "entities", None)
    if ents is None and isinstance(result, dict):
        ents = result.get("entities", [])
    return ents or []


def _tuple(e):
    g = e.get if isinstance(e, dict) else (lambda k, d=None: getattr(e, k, d))
    label = g("entity_type") or g("label") or g("entity_group")
    return int(g("start")), int(g("end")), str(label), float(g("confidence", 0.0) or g("score", 0.0) or 0.0)


class OpenMedRunner:
    """Loads OpenMed once and reuses the warmed pipelines."""

    def __init__(self, device: str = "cpu"):
        import openmed
        from openmed.core import ModelLoader, OpenMedConfig

        self.om = openmed
        self.config = OpenMedConfig(device=device)
        self.loader = ModelLoader(self.config)
        self.lang_models = {"bn": compat_model_dir(BN_PII_MODEL)}
        self._local = {}  # model key -> local path, filled when the Hub check cannot run

    # ---------------------------------------------------------- PII
    def pii(self, text: str, lang: str, threshold: float = 0.5, model_name: str | None = None):
        kw = dict(lang=lang, confidence_threshold=threshold, config=self.config, loader=self.loader)
        model_name = model_name or self.lang_models.get(lang) or (EN_PII_MODEL if lang == "en" else None)
        if model_name:
            kw["model_name"] = self._local.get(model_name, model_name)
        t0 = time.perf_counter()
        try:
            res = self.om.extract_pii(text, **kw)
        except Exception as exc:  # offline node: load the cached snapshot by path
            if not model_name or not _is_offline_integrity_error(exc) or model_name in self._local:
                raise
            self._local[model_name] = local_snapshot(model_name)
            print(f"[offline] {model_name}: loading cached files from {self._local[model_name]}", flush=True)
            return self.pii(text, lang, threshold, model_name)
        dt = time.perf_counter() - t0
        return [_tuple(e) for e in _entities(res)], dt

    def pii_auto(self, text: str, threshold: float = 0.5, route: str = "script"):
        """route='script': English model for Latin-only text, Bengali model for Bangla-only,
        and both (union of spans) for mixed text. route='en' or 'bn' forces one model."""
        langs = {"script": {"en": ["en"], "bn": ["bn"], "mixed": ["en", "bn"]}[text_script(text)],
                 "en": ["en"], "bn": ["bn"]}[route]
        spans, total = [], 0.0
        for lg in langs:
            s, dt = self.pii(text, lg, threshold)
            spans += s
            total += dt
        return spans, total, langs

    # ---------------------------------------------------------- clinical NER
    def ner(self, text: str, model_name: str, threshold: float = 0.0):
        name = self._local.get(model_name, model_name)
        t0 = time.perf_counter()
        try:
            res = self.om.analyze_text(text, model_name=name, loader=self.loader, config=self.config,
                                       confidence_threshold=threshold, sentence_detection=False)
        except Exception as exc:  # offline node: load the cached snapshot by path
            if not _is_offline_integrity_error(exc) or model_name in self._local:
                raise
            self._local[model_name] = local_snapshot(model_name)
            print(f"[offline] {model_name}: Hub checksum check unavailable, loading cached files from "
                  f"{self._local[model_name]}", flush=True)
            return self.ner(text, model_name, threshold)
        dt = time.perf_counter() - t0
        return [_tuple(e) for e in _entities(res)], dt
