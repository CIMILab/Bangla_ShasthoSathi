#!/usr/bin/env bash
# ShasthoSathi — one-shot install on Hellbender + Jupyter kernel registration.
# Safe to re-run: every step skips work that is already done.
#
#   cd ShasthoSathi        # repository root
#   bash environment/install_all.sh 2>&1 | tee logs/install.log
set -euo pipefail

DATA=${DATA:-/cluster/pixstor/data/$USER}
ENV_NAME=${ENV_NAME:-openmed}
TORCH_CUDA=${TORCH_CUDA:-cu130}          # driver reports CUDA 13.3 on g018
KERNEL_NAME=shasthosathi

# ---- 1. keep every cache/temp file on pixstor, never in $HOME -------------
export PIP_CACHE_DIR=$DATA/.cache/pip TMPDIR=$DATA/tmp HF_HOME=$DATA/hf_cache \
       CONDA_PKGS_DIRS=$DATA/conda_pkgs PYTHONNOUSERSITE=1
mkdir -p "$PIP_CACHE_DIR" "$TMPDIR" "$HF_HOME" "$CONDA_PKGS_DIRS" logs
for v in PIP_CACHE_DIR TMPDIR HF_HOME CONDA_PKGS_DIRS PYTHONNOUSERSITE; do
  grep -q "export $v=" ~/.bashrc || echo "export $v=${!v}" >> ~/.bashrc
done
echo "== free space in $DATA:"; df -h "$DATA" | tail -1

source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$ENV_NAME"
echo "== python: $(which python)"

# ---- 2. PyTorch (CUDA build matched to the driver) ------------------------
if ! python -c "import torch" 2>/dev/null; then
  pip install --no-cache-dir torch --index-url "https://download.pytorch.org/whl/${TORCH_CUDA}"
fi

# ---- 3. project packages --------------------------------------------------
pip install --no-cache-dir "openmed>=2.5" "transformers>=4.45,<5" "optimum[onnxruntime]" onnxruntime \
    peft datasets seqeval scikit-learn statsmodels pandas matplotlib faker pytesseract pytest \
    ipykernel huggingface_hub

# ---- 4. Tesseract + Bangla language data ---------------------------------
command -v tesseract >/dev/null || conda install -y -c conda-forge tesseract
TESSDIR="$CONDA_PREFIX/share/tessdata"; mkdir -p "$TESSDIR"
for lang in ben eng; do
  [ -s "$TESSDIR/$lang.traineddata" ] || wget -q -O "$TESSDIR/$lang.traineddata" \
    "https://github.com/tesseract-ocr/tessdata_best/raw/main/$lang.traineddata"
done

# ---- 5. OpenMed models (~2.5 GB) -----------------------------------------
python - <<'PY'
from huggingface_hub import snapshot_download
for m in ["OpenMed/OpenMed-PII-SuperClinical-Small-44M-v1",
          "OpenMed/OpenMed-PII-Bengali-mSuperClinical-Large-279M-v1",
          "OpenMed/OpenMed-NER-PharmaDetect-SuperMedical-125M",
          "OpenMed/OpenMed-NER-PharmaDetect-SuperClinical-434M",
          "OpenMed/OpenMed-NER-DiseaseDetect-SuperClinical-434M"]:
    print("model:", m, flush=True); snapshot_download(m)
PY

# ---- 6. Jupyter kernel that carries the same environment variables --------
python -m ipykernel install --user --name "$KERNEL_NAME" --display-name "ShasthoSathi (openmed)"
python - <<PY
import json, os, pathlib
from jupyter_client.kernelspec import KernelSpecManager
p = pathlib.Path(KernelSpecManager().get_kernel_spec("$KERNEL_NAME").resource_dir) / "kernel.json"
k = json.loads(p.read_text())
k["env"] = {"HF_HOME": "$HF_HOME", "TMPDIR": "$TMPDIR", "PIP_CACHE_DIR": "$PIP_CACHE_DIR",
            "PYTHONNOUSERSITE": "1", "TOKENIZERS_PARALLELISM": "false"}
p.write_text(json.dumps(k, indent=1)); print("kernel:", p)
PY

# ---- 7. checks -------------------------------------------------------------
python - <<'PY'
import torch, transformers, openmed, onnxruntime, peft
print("torch", torch.__version__, "| CUDA available:", torch.cuda.is_available(),
      "|", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "no GPU on this node")
print("transformers", transformers.__version__, "| openmed", openmed.__version__,
      "| onnxruntime", onnxruntime.__version__, "| peft", peft.__version__)
PY
tesseract --list-langs 2>/dev/null | grep -E "^(ben|eng)$"
python -m pytest -q tests
echo "== DONE. In Jupyter, pick the kernel 'ShasthoSathi (openmed)' and open notebooks/01_run_baselines.ipynb"
