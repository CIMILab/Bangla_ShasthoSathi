#!/usr/bin/env bash
# One-time setup on Hellbender. Run from the repo root on a node with internet.
# Keeps every cache and temp file on /cluster/pixstor (large quota), not $HOME (small quota).
set -euo pipefail

DATA=${DATA:-/cluster/pixstor/data/$USER}
export PIP_CACHE_DIR=$DATA/.cache/pip
export TMPDIR=$DATA/tmp
export HF_HOME=$DATA/hf_cache
export CONDA_PKGS_DIRS=$DATA/.conda_pkgs
mkdir -p "$PIP_CACHE_DIR" "$TMPDIR" "$HF_HOME" "$CONDA_PKGS_DIRS"

# Make these permanent for future logins and Slurm jobs
for v in PIP_CACHE_DIR TMPDIR HF_HOME CONDA_PKGS_DIRS; do
  grep -q "export $v=" ~/.bashrc || echo "export $v=${!v}" >> ~/.bashrc
done

source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate openmed

# 1) PyTorch must come first, from the CUDA index that matches the node's driver.
#    Check the "CUDA Version" in the top-right of `nvidia-smi` and set TORCH_CUDA:
#    cu126 (driver CUDA 12.6+), cu128 (12.8+), cu130 (13.0+).
TORCH_CUDA=${TORCH_CUDA:-cu128}
if ! python -c "import torch" 2>/dev/null; then
  pip install torch --index-url "https://download.pytorch.org/whl/${TORCH_CUDA}"
fi
python -c "import torch; print('torch', torch.__version__, 'cuda build', torch.version.cuda, 'gpu visible', torch.cuda.is_available())"

# 2) Project packages. transformers<5 matches what optimum resolves and what openmed 2.5 was tested on.
pip install "openmed>=2.5" "transformers>=4.45,<5" "optimum[onnxruntime]" onnxruntime peft datasets \
            seqeval scikit-learn statsmodels pandas matplotlib faker pytesseract pytest

# llama-cpp-python is only needed for Experiment 6. Install later from the prebuilt CPU wheel
# (avoids a long source build):
#   pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu

# 3) Bangla OCR data for Tesseract (the conda package may not include it)
TESSDIR="$CONDA_PREFIX/share/tessdata"
mkdir -p "$TESSDIR"
[ -f "$TESSDIR/ben.traineddata" ] || wget -q -O "$TESSDIR/ben.traineddata" \
  https://github.com/tesseract-ocr/tessdata_best/raw/main/ben.traineddata
tesseract --list-langs 2>/dev/null | grep -E "^(ben|eng)$" || echo "WARNING: check tesseract languages"

# 4) Pre-download the OpenMed models (compute jobs run offline)
python - <<'PY'
from huggingface_hub import snapshot_download
for m in ["OpenMed/OpenMed-PII-SuperClinical-Small-44M-v1",
          "OpenMed/OpenMed-PII-Bengali-mSuperClinical-Large-279M-v1",
          "OpenMed/OpenMed-NER-PharmaDetect-SuperMedical-125M",
          "OpenMed/OpenMed-NER-PharmaDetect-SuperClinical-434M",
          "OpenMed/OpenMed-NER-DiseaseDetect-SuperClinical-434M"]:
    print("downloading", m, flush=True); snapshot_download(m)
PY
python -c "import openmed, transformers; print('openmed', openmed.__version__, 'transformers', transformers.__version__)"
echo "Setup finished. Caches live under $DATA."
