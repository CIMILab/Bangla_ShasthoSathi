# Source this in every terminal / Slurm job:   source environment/env.sh
# Activates the project env, keeps caches under $DATA (default: Hellbender pixstor; set DATA elsewhere), and goes online when Hugging Face is reachable.
DATA=${DATA:-/cluster/pixstor/data/$USER}
export PROJECT_ROOT=${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}
export PIP_CACHE_DIR=$DATA/.cache/pip TMPDIR=$DATA/tmp HF_HOME=$DATA/hf_cache
export PYTHONNOUSERSITE=1 TOKENIZERS_PARALLELISM=false PYTHONUNBUFFERED=1
mkdir -p "$TMPDIR" "$HF_HOME"
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "${ENV_NAME:-openmed}"
cd "$PROJECT_ROOT" || return 1
mkdir -p logs results runs
if curl -s -m 8 -o /dev/null https://huggingface.co/api/models/xlm-roberta-base; then
  unset HF_HUB_OFFLINE TRANSFORMERS_OFFLINE; echo "[env] Hugging Face reachable: online mode"
else
  export HF_HUB_OFFLINE=1; echo "[env] Hugging Face not reachable: offline mode (cached models only)"
fi
echo "[env] $(python -c 'import torch;print("torch",torch.__version__,"| GPU:",torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none")')"
