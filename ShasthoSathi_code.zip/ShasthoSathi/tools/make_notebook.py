"""Regenerate notebooks/01_run_baselines.ipynb  (python tools/make_notebook.py)."""
import nbformat as nbf

C = []
md = lambda s: C.append(nbf.v4.new_markdown_cell(s))
code = lambda s: C.append(nbf.v4.new_code_cell(s))

md("""# ShasthoSathi — Week 6 baselines

Run top to bottom with the kernel **ShasthoSathi (openmed)** on a **GPU** OnDemand session.

| Section | What it does | Time (GPU) |
|---|---|---|
| 0 | Environment check | seconds |
| 1 | Unit tests, data, synthetic set | 1–2 min |
| 2 | E0: script profile of Bangla-HealthNER | seconds |
| 3 | E1: PII leakage (OpenMed EN + BN models) | ~10–20 min |
| 4 | E2: medicine / condition recall (OpenMed NER) | ~10–20 min |
| 5 | Bundle results to send back | seconds |

Every step writes to `results/`. Re-running a cell overwrites only its own output.""")

md("## 0. Environment check")
code("""import os, sys, json, subprocess, pathlib, time
ROOT = pathlib.Path('/path/to/ShasthoSathi')   # change if you moved the repo
os.chdir(ROOT); sys.path.insert(0, str(ROOT / 'src'))
(ROOT / 'results').mkdir(exist_ok=True); (ROOT / 'logs').mkdir(exist_ok=True)

import torch, transformers, openmed
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
print('python      ', sys.executable)
print('torch       ', torch.__version__, '| device:', DEVICE, '|', torch.cuda.get_device_name(0) if DEVICE == 'cuda' else '')
print('transformers', transformers.__version__, '| openmed', openmed.__version__)
print('HF_HOME     ', os.environ.get('HF_HOME'))
print('user site off', os.environ.get('PYTHONNOUSERSITE') == '1')

def run(cmd):
    \"\"\"Run a project script with this kernel's python and show its output.\"\"\"
    t0 = time.time()
    p = subprocess.run([sys.executable] + cmd, cwd=ROOT, text=True, capture_output=True)
    print(p.stdout[-6000:])
    if p.returncode:
        print('STDERR:\\n', p.stderr[-6000:])
        raise RuntimeError(f'failed: {cmd}')
    print(f'[{time.time() - t0:.0f}s]')""")

md("## 1. Tests, data, synthetic set")
code("run(['-m', 'pytest', '-q', 'tests'])")
code("""# Bangla-HealthNER (GitHub) — needed for E0 and E2
hn = ROOT / 'data/raw/Bangla-HealthNER'
if not hn.exists():
    subprocess.run(['git', 'clone', '--depth', '1', 'https://github.com/alvi-khan/Bangla-HealthNER.git', str(hn)], check=True)
print(sorted(p.name for p in (hn / 'Dataset').iterdir()))""")
code("""# PMC-Patients sample + ADE drug-dosage (Hugging Face) — used in Week 7 (PII injection, dosage check)
from datasets import load_dataset
raw = ROOT / 'data/raw'
if not (raw / 'pmc_patients_sample2000.jsonl').exists():
    pmc = load_dataset('zhengyun21/PMC-Patients', split='train')
    pmc.shuffle(seed=42).select(range(2000)).to_json(str(raw / 'pmc_patients_sample2000.jsonl'), force_ascii=False)
    print('PMC-Patients rows:', len(pmc))
if not (raw / 'ade_drug_dosage.jsonl').exists():
    ade = load_dataset('ade-benchmark-corpus/ade_corpus_v2', 'Ade_corpus_v2_drug_dosage_relation', split='train')
    ade.to_json(str(raw / 'ade_drug_dosage.jsonl'), force_ascii=False)
    print('ADE drug-dosage rows:', len(ade))
for f in sorted(raw.iterdir()):
    print(f.name)""")
code("""run(['scripts/01_make_synthetic.py', '--out', 'data/synthetic/synth_v1.jsonl'])
docs = [json.loads(l) for l in open('data/synthetic/synth_v1.jsonl', encoding='utf-8')]
print(docs[100]['text'])""")

md("## 2. E0 — what script are medical terms written in? (no model needed)")
code("run(['scripts/04_healthner_profile.py'])")

md("""## 3. E1 — PII leakage

First a two-document check that prints what OpenMed returns (label names, offsets).
If this cell fails, stop and send the error.""")
code("""from shastho.openmed_adapter import OpenMedRunner
runner = OpenMedRunner(DEVICE)
for d in [docs[0], docs[260]]:            # one English lab report, one Bangla note
    lang = 'bn' if d['lang'] == 'bn' else 'en'
    spans, sec = runner.pii(d['text'], lang, 0.5)
    print(f"--- {d['doc_id']} (lang={lang}, {sec * 1000:.0f} ms)")
    for s, e, lab, sc in spans:
        print(f"  {lab:18s} {sc:.2f}  {d['text'][s:e]!r}")
    print('  gold:', [(p['type'], p['text']) for p in d['pii']])""")
code("""# Full run: 300 docs x 3 routes x 3 thresholds
run(['scripts/02_pii_baseline.py', '--device', DEVICE, '--out', 'results/exp1_pii.json'])""")
code("""import pandas as pd
e1 = json.load(open('results/exp1_pii.json'))['summary']
t = pd.DataFrame({k: {'span leak': v['span_leak_rate'], 'CI low': v['ci95'][0], 'CI high': v['ci95'][1],
                      'docs with any leak': v['docs_with_any_leak'],
                      'clinical over-redaction': v['clinical_over_redaction'],
                      'ms/doc': 1000 * v['median_sec_per_doc']} for k, v in e1.items()}).T
display(t.round(3))
display(pd.DataFrame({k: v['per_type_leak'] for k, v in e1.items()}).round(3))
display(pd.DataFrame({k: v['per_group_leak'] for k, v in e1.items()}).round(3))""")

md("## 4. E2 — can English clinical NER find Bangladeshi medicines?")
code("""for model in ['pharma_detection_supermedical', 'disease_detection_superclinical']:
    spans, sec = runner.ner(docs[100]['text'], model)
    print(f'--- {model} ({sec * 1000:.0f} ms)')
    for s, e, lab, sc in spans:
        print(f"  {lab:14s} {sc:.2f}  {docs[100]['text'][s:e]!r}")""")
code("run(['scripts/03_ner_baseline.py', '--device', DEVICE, '--out', 'results/exp2_ner.json'])")
code("""e2 = json.load(open('results/exp2_ner.json'))
rows = {k: {g: v['recall'] for g, v in r['recall'].items()} for k, r in e2.items() if isinstance(r, dict) and 'recall' in r}
display(pd.DataFrame(rows).T.round(3))""")

md("## 5. Bundle for Claude\nCopy the printed JSON (or download `results/bundle_week6.json`) and paste it into the chat.")
code("""bundle = {
  'env': {'torch': torch.__version__, 'transformers': transformers.__version__, 'openmed': openmed.__version__,
          'device': DEVICE, 'gpu': torch.cuda.get_device_name(0) if DEVICE == 'cuda' else None},
  'e0': json.load(open('results/healthner_profile.json'))['test']['entity_script'],
  'e1': json.load(open('results/exp1_pii.json'))['summary'],
  'e2': {k: v for k, v in json.load(open('results/exp2_ner.json')).items() if k != 'args'},
}
json.dump(bundle, open('results/bundle_week6.json', 'w'), indent=1, ensure_ascii=False)
print(json.dumps(bundle, ensure_ascii=False)[:20000])""")

nb = nbf.v4.new_notebook()
nb.cells = C
nb.metadata["kernelspec"] = {"name": "shasthosathi", "display_name": "ShasthoSathi (openmed)", "language": "python"}
nbf.write(nb, "notebooks/01_run_baselines.ipynb")
print(len(C), "cells written")
