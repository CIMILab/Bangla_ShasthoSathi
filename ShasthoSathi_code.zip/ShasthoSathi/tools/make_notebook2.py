"""Regenerate notebooks/02_hybrid_and_finetune.ipynb  (python tools/make_notebook2.py)."""
import nbformat as nbf

C = []
md = lambda s: C.append(nbf.v4.new_markdown_cell(s))
code = lambda s: C.append(nbf.v4.new_code_cell(s))

md("""# ShasthoSathi — Week 7: E3 hybrid de-identification, E4 fine-tuning on Bangla-HealthNER

Kernel **ShasthoSathi (openmed)**, **GPU** session (H100). Run top to bottom.

| Section | What it does | Time (H100) |
|---|---|---|
| 0 | Setup, internet check, model downloads | 2–5 min |
| 1 | E3: OpenMed vs rules vs hybrid; threshold chosen on dev, reported on held-out + real text | ~10 min |
| 2 | E4: fine-tune 6 encoder configs on Bangla-HealthNER (25k train docs) | ~30–45 min |
| 3 | Bundle results | seconds |

Each E4 config runs in its own process; if one fails, the loop records the error and continues.""")

md("## 0. Setup")
code("""import os, sys, json, subprocess, pathlib, time
ROOT = pathlib.Path('/path/to/ShasthoSathi')
os.chdir(ROOT); sys.path.insert(0, str(ROOT / 'src'))
import torch, pandas as pd
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device', DEVICE, torch.cuda.get_device_name(0) if DEVICE == 'cuda' else '')

# Is Hugging Face reachable from this node? If yes, run jobs online (OpenMed can verify checksums).
import urllib.request
try:
    urllib.request.urlopen('https://huggingface.co/api/models/OpenMed/OpenMed-PII-SuperClinical-Small-44M-v1', timeout=8)
    ONLINE = True
except Exception as e:
    ONLINE = False
print('HF reachable:', ONLINE, '| HF_HUB_OFFLINE in env:', os.environ.get('HF_HUB_OFFLINE'))
ENV = os.environ.copy()
if ONLINE:
    ENV.pop('HF_HUB_OFFLINE', None); ENV.pop('TRANSFORMERS_OFFLINE', None)

def run(cmd, check=True):
    t0 = time.time()
    p = subprocess.run([sys.executable] + cmd, cwd=ROOT, text=True, capture_output=True, env=ENV)
    print(p.stdout[-5000:])
    if p.returncode:
        print('STDERR (last lines):\\n', p.stderr[-4000:])
        if check:
            raise RuntimeError(f'failed: {cmd}')
    print(f'[{time.time() - t0:.0f}s]')
    return p.returncode

run(['-m', 'pytest', '-q', 'tests'])""")
code("""# Download the E4 backbones once (skipped if already cached)
BACKBONES = ['csebuetnlp/banglishbert', 'csebuetnlp/banglabert', 'xlm-roberta-base']
if ONLINE:
    from huggingface_hub import snapshot_download
    for m in BACKBONES:
        print('download', m, flush=True)
        snapshot_download(m, allow_patterns=['*.json', '*.txt', '*.model', '*.safetensors', '*.bin'])
else:
    print('Offline node: make sure these are already in', os.environ.get('HF_HOME'), BACKBONES)""")

md("""## 1. E3 — hybrid de-identification

* **dev** = synthetic v1 → choose the threshold (lowest leak with clinical over-redaction ≤ 10%)
* **test** = synthetic set with a **held-out vocabulary** (no name, area or clinic shared with dev)
* **real** = fake identifiers inserted into 200 real PMC-Patients summaries + 200 real Bangla-HealthNER posts""")
code("""run(['scripts/01_make_synthetic.py', '--vocab', 'heldout', '--seed', '7', '--out', 'data/synthetic/synth_heldout.jsonl'])
run(['scripts/05_pii_hybrid.py', '--device', DEVICE, '--out', 'results/exp3_pii_hybrid.json'])""")
code("""e3 = json.load(open('results/exp3_pii_hybrid.json'))['summary']
print('thresholds chosen on dev:', e3['chosen_threshold'])
for split, rep in e3['report'].items():
    rows = {m: {'leak': v['span_leak_rate'], 'CI low': v['ci95'][0], 'CI high': v['ci95'][1],
                'leak w/o facility': v['leak_without_facility'], 'docs any leak': v['docs_with_any_leak'],
                'over-redaction': v['clinical_over_redaction']} for m, v in rep.items() if m != 'hybrid_minus_model'}
    print(f'\\n=== {split}'); display(pd.DataFrame(rows).T.round(3))
    display(pd.DataFrame({m: v['per_type_leak'] for m, v in rep.items() if m != 'hybrid_minus_model'}).round(3))
    print('hybrid - model:', rep.get('hybrid_minus_model'))
print('median ms/doc:', {k: round(v, 1) for k, v in e3['median_ms_per_doc'].items()})""")

md("""## 2. E4 — fine-tuning on Bangla-HealthNER

Published reference: **BanglishBERT micro F1 56.13 ± 0.75** (Khan et al., Findings of EMNLP 2023).
Config 1 replicates it; the others ask whether a multilingual or OpenMed backbone, or LoRA, does better
— and whether Bangla-script medicines (0–9% recall in E2) become findable.""")
code("""CONFIGS = [
    ['--model', 'csebuetnlp/banglishbert'],
    ['--model', 'csebuetnlp/banglabert'],
    ['--model', 'xlm-roberta-base'],
    ['--model', 'xlm-roberta-base', '--lora'],
    ['--model', 'openmed-bn-pii'],
    ['--model', 'openmed-bn-pii', '--lora'],
]
SEEDS = [42]          # add 13, 7 later for mean ± sd on the best configs
status = {}
for cfg in CONFIGS:
    for seed in SEEDS:
        key = ' '.join(cfg) + f' seed={seed}'
        print('=' * 80, '\\n', key, flush=True)
        status[key] = run(['scripts/06_healthner_finetune.py', *cfg, '--seed', str(seed), '--save-model'], check=False)
print(status)""")
code("""rows = {}
for f in sorted(pathlib.Path('runs').glob('*/metrics.json')):
    m = json.load(open(f)); t = m['test']; rs = t.get('recall_by_script', {})
    rows[f.parent.name] = {
        'micro F1': t['micro']['f1'], 'P': t['micro']['precision'], 'R': t['micro']['recall'], 'macro F1': t['macro_f1'],
        'Medicine F1': t['per_type'].get('Medicine', {}).get('f1'),
        'Medicine R (Bangla script)': rs.get('Medicine|bn', {}).get('recall'),
        'Medicine R (Latin script)': rs.get('Medicine|en', {}).get('recall'),
        'Dosage F1': t['per_type'].get('Dosage', {}).get('f1'),
        'trainable M': m['params_trainable_M'], 'total M': m['params_total_M'], 'train min': m['train_minutes'],
        'test ms/doc': m['test_ms_per_doc']}
e4 = pd.DataFrame(rows).T.sort_values('micro F1', ascending=False)
display(e4.round(3))""")

md("## 3. Bundle for Claude")
code("""bundle = {
  'env': {'torch': torch.__version__, 'gpu': torch.cuda.get_device_name(0) if DEVICE == 'cuda' else None, 'online': ONLINE},
  'e3': json.load(open('results/exp3_pii_hybrid.json'))['summary'],
  'e3_all': json.load(open('results/exp3_pii_hybrid.json'))['all'],
  'e4': {f.parent.name: {k: v for k, v in json.load(open(f)).items() if k != 'labels'}
         for f in sorted(pathlib.Path('runs').glob('*/metrics.json'))},
  'e4_status': status,
}
json.dump(bundle, open('results/bundle_week7.json', 'w'), indent=1, ensure_ascii=False)
print('wrote results/bundle_week7.json', round(os.path.getsize('results/bundle_week7.json') / 1024), 'KB')""")

nb = nbf.v4.new_notebook()
nb.cells = C
nb.metadata["kernelspec"] = {"name": "shasthosathi", "display_name": "ShasthoSathi (openmed)", "language": "python"}
nbf.write(nb, "notebooks/02_hybrid_and_finetune.ipynb")
print(len(C), "cells written")
